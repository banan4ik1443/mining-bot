from PIL import Image, ImageDraw, ImageFont
import io
from typing import Optional


# ─── Pixel-art palette ────────────────────────────────────────────────────────
C = {
    "sky":      (135, 206, 235),
    "sky2":     (100, 180, 220),
    "ground":   (101, 155, 65),
    "earth":    (139, 100, 60),
    "stone":    (140, 140, 150),
    "stone2":   (110, 110, 120),
    "dark":     (40,  40,  50),
    "brown":    (139, 90,  43),
    "brown2":   (100, 65,  30),
    "wood":     (205, 133, 63),
    "wood2":    (165, 100, 40),
    "roof":     (180, 60,  30),
    "roof2":    (140, 40,  20),
    "roof3":    (100, 30,  10),
    "gold":     (255, 200, 50),
    "gold2":    (200, 150, 20),
    "white":    (255, 255, 255),
    "gray":     (180, 180, 190),
    "gray2":    (130, 130, 140),
    "green":    (50,  140, 50),
    "green2":   (30,  100, 30),
    "yellow":   (255, 230, 80),
    "orange":   (230, 120, 30),
    "blue":     (60,  120, 200),
    "red":      (200, 50,  50),
    "ember":    (255, 120, 20),
    "shadow":   (20,  20,  30, 120),
    "transparent": (0, 0, 0, 0),
    "flag_r":   (200, 50,  50),
    "flag_b":   (50,  80, 200),
    "window":   (140, 200, 240),
    "window2":  (80, 140, 200),
    "anvil":    (60,  60,  80),
    "chain":    (190, 190, 200),
    "mine_wall":(80,  80,  90),
    "coal":     (40,  40,  50),
    "ore":      (180, 100, 40),
    "iron":     (150, 160, 170),
    "copper":   (180, 100, 60),
    "glow":     (255, 240, 100, 180),
}

SCALE = 6  # Each "pixel" is 6x6 real pixels
IMG_W = 40
IMG_H = 40


def _canvas(w=IMG_W, h=IMG_H, bg=None):
    img = Image.new("RGBA", (w * SCALE, h * SCALE), bg or (0, 0, 0, 0))
    return img


def _p(draw, x, y, color, s=SCALE):
    """Draw one pixel-art 'pixel'."""
    rx, ry = x * s, y * s
    r, g, b = color[:3]
    a = color[3] if len(color) == 4 else 255
    draw.rectangle([rx, ry, rx + s - 1, ry + s - 1], fill=(r, g, b, a))


def _rect(draw, x1, y1, x2, y2, color):
    for x in range(x1, x2 + 1):
        for y in range(y1, y2 + 1):
            _p(draw, x, y, color)


def _gradient_sky(draw, h=IMG_H, w=IMG_W):
    for y in range(h):
        ratio = y / h
        r = int(135 + (180 - 135) * ratio)
        g = int(206 + (230 - 206) * ratio)
        b = int(235 + (255 - 235) * ratio)
        for x in range(w):
            _p(draw, x, y, (r, g, b))


def _ground_strip(draw, y_start=30, h=40, w=40):
    for y in range(y_start, h):
        ratio = (y - y_start) / max(1, h - y_start)
        r = int(101 - 30 * ratio)
        g = int(155 - 60 * ratio)
        b = int(65 - 30 * ratio)
        for x in range(w):
            _p(draw, x, y, (r, g, b))


def draw_town_hall(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw)

    w = IMG_W
    if level == 0:
        # Blueprint / foundation
        _rect(draw, 8, 25, 32, 30, (100, 120, 200, 160))
        _rect(draw, 10, 22, 30, 25, (80, 100, 180, 160))
        for x in range(10, 30, 4):
            _p(draw, x, 27, C["white"])
        return img

    # Base walls - get bigger with level
    base_w = min(28, 16 + level * 2)
    x0 = (w - base_w) // 2
    x1 = x0 + base_w - 1
    y_wall_top = max(8, 26 - level * 2)

    # Stone wall
    for y in range(y_wall_top, 30):
        for x in range(x0, x1 + 1):
            col = C["stone"] if (x + y) % 3 != 0 else C["stone2"]
            _p(draw, x, y, col)

    # Windows
    if level >= 2:
        for wx in [x0 + 3, x1 - 5]:
            _rect(draw, wx, y_wall_top + 2, wx + 2, y_wall_top + 4, C["window"])
            _p(draw, wx + 1, y_wall_top + 3, C["window2"])

    # Gate
    gate_x = (x0 + x1) // 2 - 1
    _rect(draw, gate_x, 26, gate_x + 3, 30, C["dark"])
    _p(draw, gate_x + 1, 28, C["gold"])

    # Roof / towers
    roof_color = [C["roof3"], C["roof2"], C["roof"], C["orange"], C["gold"]][min(level - 1, 4)]
    # Main roof triangle
    for i in range(base_w // 2 + 1):
        roof_y = y_wall_top - 1 - i // 2
        if 0 <= roof_y < y_wall_top:
            for x in range(x0 + i, x1 - i + 1):
                _p(draw, x, roof_y, roof_color)

    # Towers (level 3+)
    if level >= 3:
        for tx in [x0 - 2, x1 - 1]:
            _rect(draw, tx, y_wall_top - 2, tx + 3, y_wall_top + 6, C["stone2"])
            # Battlements
            for bx in range(tx, tx + 4, 2):
                _p(draw, bx, y_wall_top - 4, C["stone"])
                _p(draw, bx, y_wall_top - 3, C["stone"])

    # Flag pole (level 4+)
    if level >= 4:
        pole_x = (x0 + x1) // 2
        for py in range(2, y_wall_top - 2):
            _p(draw, pole_x, py, C["brown"])
        _rect(draw, pole_x + 1, 2, pole_x + 4, 5, C["flag_r"])

    # Glowing windows at night (level 5+)
    if level >= 5:
        for wx in [x0 + 3, x1 - 5]:
            _p(draw, wx, y_wall_top + 2, C["yellow"])
            _p(draw, wx + 1, y_wall_top + 2, C["yellow"])

    return img


def draw_farm(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=28)

    if level == 0:
        _rect(draw, 12, 20, 28, 28, (180, 180, 100, 150))
        return img

    # Barn
    bx, bw = 24, 10
    by = 18
    _rect(draw, bx, by, bx + bw, 28, C["brown"])
    # Roof
    for i in range(7):
        _rect(draw, bx - i, by - i, bx + bw + i, by - i, C["roof"])
    # Door
    _rect(draw, bx + 3, 23, bx + 6, 28, C["brown2"])
    _p(draw, bx + 2, 24, C["wood2"])

    # Fields — more rows per level
    rows = min(level, 5)
    for row in range(rows):
        fy = 20 + row * 2 if row < 3 else 20 + row * 2 - 1
        fx_start = 4
        fx_end = 22
        col_a = C["earth"] if row % 2 == 0 else C["green"]
        col_b = C["green"] if row % 2 == 0 else C["earth"]
        for fx in range(fx_start, fx_end):
            _p(draw, fx, fy, col_a if (fx % 2 == 0) else col_b)
        # Crops
        if level >= 2 and row < 3:
            for fx in range(fx_start + 1, fx_end, 3):
                _p(draw, fx, fy - 1, C["green2"])
                if level >= 4:
                    _p(draw, fx, fy - 2, C["yellow"])

    # Windmill (level 4+)
    if level >= 4:
        _rect(draw, 6, 14, 9, 28, C["stone"])
        for angle in [(5, 12), (3, 17), (7, 17), (5, 22)]:
            _p(draw, angle[0], angle[1], C["wood"])
            _p(draw, angle[0] + 1, angle[1] + 1, C["wood"])

    return img


def draw_sawmill(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=27)

    if level == 0:
        _rect(draw, 10, 20, 30, 27, (150, 120, 80, 150))
        return img

    # Wooden shed
    _rect(draw, 8, 16, 28, 27, C["wood"])
    # Planks texture
    for y in range(16, 27, 3):
        for x in range(8, 28):
            if x % 2 == 0:
                _p(draw, x, y, C["wood2"])
    # Roof
    for i in range(12):
        _rect(draw, 8 + i, 16 - i // 2, 28 - i, 16 - i // 2, C["roof"])

    # Windows
    for wx in [11, 22]:
        _rect(draw, wx, 18, wx + 3, 21, C["window"])
        _p(draw, wx + 1, 19, C["sky2"])

    # Saw blade (level 2+)
    if level >= 2:
        cx, cy = 34, 22
        _rect(draw, cx, cy - 3, cx + 4, cy + 3, C["gray"])
        for i in range(-2, 3):
            _p(draw, cx - 1, cy + i, C["gray2"])
            _p(draw, cx + 5, cy + i, C["gray2"])

    # Log pile (level 3+)
    if level >= 3:
        for lx in range(4, 8):
            for ln in range(3):
                _p(draw, lx, 27 - ln, C["brown"] if ln % 2 == 0 else C["wood2"])

    # Chimney with smoke (level 4+)
    if level >= 4:
        _rect(draw, 24, 8, 26, 16, C["stone"])
        for sy in range(3, 8):
            alpha = 200 - sy * 20
            _p(draw, 25, sy, (200, 200, 200, max(0, alpha)))

    return img


def draw_mine(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw, h=20)
    # Rock/mountain backdrop
    for y in range(10, IMG_H):
        ratio = (y - 10) / (IMG_H - 10)
        r = int(80 - 20 * ratio)
        g = int(80 - 20 * ratio)
        b = int(90 - 20 * ratio)
        for x in range(IMG_W):
            _p(draw, x, y, (r, g, b))

    if level == 0:
        # Just rocks
        _rect(draw, 5, 20, 35, 35, C["stone"])
        for rx in [10, 20, 30]:
            _p(draw, rx, 19, C["stone2"])
        return img

    # Mine entrance
    entrance_w = min(10 + level * 2, 22)
    ex = (IMG_W - entrance_w) // 2
    ey = 16
    # Rock arch
    _rect(draw, ex - 2, ey - 2, ex + entrance_w + 1, ey + 14, C["stone"])
    for sx in range(5):
        _p(draw, ex - 2 + sx, ey - 2 - sx, C["stone2"])
        _p(draw, ex + entrance_w + 1 - sx, ey - 2 - sx, C["stone2"])

    # Tunnel opening (dark)
    _rect(draw, ex, ey, ex + entrance_w - 1, ey + 12, C["dark"])
    # Mine tracks
    for ty in range(ey + 2, ey + 12, 2):
        _rect(draw, ex + 1, ty, ex + entrance_w - 2, ty, C["coal"])
    _p(draw, ex + entrance_w // 2, ey + 6, C["wood"])

    # Wooden supports
    _p(draw, ex, ey, C["brown"])
    _p(draw, ex, ey + 6, C["brown"])
    _p(draw, ex + entrance_w - 1, ey, C["brown"])
    _p(draw, ex + entrance_w - 1, ey + 6, C["brown"])
    _rect(draw, ex, ey, ex + entrance_w - 1, ey, C["brown"])
    _rect(draw, ex, ey + 6, ex + entrance_w - 1, ey + 6, C["brown"])

    # Ore veins in rock wall (level 2+)
    if level >= 2:
        for vy, vx, col in [(18, 5, C["ore"]), (22, 32, C["iron"]), (26, 8, C["copper"])]:
            _p(draw, vx, vy, col)
            _p(draw, vx + 1, vy, col)

    # Cart outside (level 3+)
    if level >= 3:
        cx = ex + entrance_w + 2
        _rect(draw, cx, ey + 9, cx + 4, ey + 11, C["brown2"])
        _p(draw, cx, ey + 12, C["dark"])
        _p(draw, cx + 4, ey + 12, C["dark"])
        if level >= 4:
            _p(draw, cx + 1, ey + 10, C["ore"])
            _p(draw, cx + 2, ey + 10, C["iron"])

    # Glowing rare ore veins (level 4+)
    if level >= 4:
        glow_cols = [(255, 200, 50), (200, 50, 200), (50, 200, 255)]
        for i, (gx, gy) in enumerate([(12, 15), (28, 17), (20, 14)]):
            if i < level - 3:
                col = glow_cols[i % len(glow_cols)]
                _p(draw, gx, gy, col)
                _p(draw, gx + 1, gy, (col[0], col[1], col[2], 180))

    # Torch lights (level 5+)
    if level >= 5:
        for tx, ty in [(ex + 2, ey + 3), (ex + entrance_w - 4, ey + 3)]:
            _p(draw, tx, ty, C["brown"])
            _p(draw, tx, ty - 1, C["ember"])
            _p(draw, tx, ty - 2, (255, 200, 50, 200))

    return img


def draw_smithy(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=27)

    if level == 0:
        _rect(draw, 8, 20, 28, 27, (100, 100, 110, 150))
        return img

    # Stone building
    _rect(draw, 6, 14, 30, 27, C["stone"])
    for y in range(14, 27, 3):
        for x in range(6, 30, 5):
            _p(draw, x, y, C["stone2"])

    # Roof
    for i in range(14):
        _rect(draw, 6 + i, 14 - i // 2, 30 - i, 14 - i // 2, C["stone2"])

    # Chimney
    _rect(draw, 22, 4, 25, 14, C["stone2"])

    # Forge glow in window
    glow_intensity = min(level, 5)
    glow_col = (255, max(0, 200 - glow_intensity * 20), 0)
    _rect(draw, 14, 17, 18, 21, glow_col)
    _p(draw, 16, 19, C["white"])

    # Anvil (level 2+)
    if level >= 2:
        _rect(draw, 10, 22, 16, 25, C["anvil"])
        _rect(draw, 11, 21, 15, 22, C["anvil"])
        _p(draw, 13, 20, C["gray"])

    # Smoke from chimney
    smoke_rows = min(level, 6)
    for i in range(1, smoke_rows + 1):
        alpha = 200 - i * 25
        col = (190, 190, 200, max(0, alpha))
        sx = 23 + (i % 3 - 1)
        _p(draw, sx, 4 - i, col)

    # Barrel (level 3+)
    if level >= 3:
        _rect(draw, 26, 21, 29, 26, C["brown"])
        for by in range(22, 27, 2):
            _p(draw, 26, by, C["wood2"])
            _p(draw, 29, by, C["wood2"])

    return img


def draw_barracks(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=28)

    if level == 0:
        _rect(draw, 8, 20, 30, 28, (150, 100, 80, 150))
        return img

    # Main barracks building
    bx, bw = 6, 24
    by = 15
    _rect(draw, bx, by, bx + bw, 28, C["brown"])
    # Wood planks
    for y in range(by, 28, 3):
        _rect(draw, bx, y, bx + bw, y, C["brown2"])

    # Roof
    for i in range(14):
        _rect(draw, bx + i, by - i // 2, bx + bw - i, by - i // 2, C["roof"])

    # Flag
    _rect(draw, (bx + bx + bw) // 2, 4, (bx + bx + bw) // 2, by, C["brown"])
    _rect(draw, (bx + bx + bw) // 2 + 1, 4, (bx + bx + bw) // 2 + 5, 8, C["flag_b"])

    # Weapons rack (level 2+)
    if level >= 2:
        for wx in [10, 13, 16]:
            _rect(draw, wx, 21, wx, 26, C["gray"])
            _p(draw, wx, 20, C["gray2"])

    # Guard house (level 3+)
    if level >= 3:
        _rect(draw, 32, 20, 37, 28, C["stone"])
        _p(draw, 34, 22, C["red"])

    # Training field (level 4+)
    if level >= 4:
        for fx in range(4, 8):
            _p(draw, fx, 26, C["earth"])
        # Dummy target
        _p(draw, 3, 22, C["orange"])
        _rect(draw, 3, 23, 3, 25, C["brown"])

    return img


def draw_market(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=28)

    if level == 0:
        _rect(draw, 5, 20, 35, 28, (200, 180, 140, 150))
        return img

    # Market stalls
    stalls = min(level + 1, 4)
    stall_w = 7
    total_w = stalls * stall_w + (stalls - 1) * 2
    sx_start = (IMG_W - total_w) // 2

    for s in range(stalls):
        sx = sx_start + s * (stall_w + 2)
        # Counter
        _rect(draw, sx, 22, sx + stall_w - 1, 28, C["wood"])
        _p(draw, sx, 21, C["wood2"])
        _p(draw, sx + stall_w - 1, 21, C["wood2"])
        # Awning
        awning_cols = [C["red"], C["blue"], C["green"], C["orange"]]
        _rect(draw, sx - 1, 17, sx + stall_w, 19, awning_cols[s % len(awning_cols)])
        # Support poles
        _rect(draw, sx, 19, sx, 22, C["brown"])
        _rect(draw, sx + stall_w - 1, 19, sx + stall_w - 1, 22, C["brown"])
        # Goods on counter
        if level >= 2:
            goods = [(C["gold"], s + 1), (C["ore"], s + 2), (C["wood"], s + 3)]
            for gi, (gc, gx_off) in enumerate(goods[:2]):
                if sx + gx_off < sx + stall_w - 1:
                    _p(draw, sx + gx_off, 21, gc)

    # Sign (level 3+)
    if level >= 3:
        sign_x = IMG_W // 2 - 3
        _rect(draw, sign_x, 12, sign_x + 6, 16, C["wood"])
        _p(draw, sign_x + 3, 13, C["gold"])
        _rect(draw, sign_x + 2, 16, sign_x + 4, 22, C["brown"])

    return img


def draw_storage(level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=28)

    if level == 0:
        _rect(draw, 8, 22, 32, 28, (180, 160, 120, 150))
        return img

    # Warehouse building - gets taller with level
    height = min(8 + level * 2, 22)
    _rect(draw, 5, IMG_H - height - 2, 35, IMG_H - 2, C["wood"])
    # Planks
    for y in range(IMG_H - height - 2, IMG_H - 2, 3):
        _rect(draw, 5, y, 35, y, C["wood2"])
    # Roof
    for i in range(16):
        _rect(draw, 5 + i, IMG_H - height - 3 - i // 2, 35 - i, IMG_H - height - 3 - i // 2, C["roof"])

    # Crates / barrels outside (more with higher levels)
    crate_count = min(level, 5)
    for ci in range(crate_count):
        cx = 2 + ci * 3
        if cx + 2 < 5:
            _rect(draw, cx, 25, cx + 2, 28, C["brown"])
            _p(draw, cx + 1, 25, C["wood"])
        # Right side barrels
        cx2 = 36 + ci % 3 * 2
        if cx2 + 1 < IMG_W:
            _rect(draw, cx2, 24, cx2 + 1, 27, C["brown2"])

    # Big doors (always)
    door_x = IMG_W // 2 - 3
    _rect(draw, door_x, 22, door_x + 5, 28, C["dark"])
    _p(draw, door_x + 2, 25, C["brown"])
    # Door frame
    for dfy in range(22, 28):
        _p(draw, door_x, dfy, C["wood2"])
        _p(draw, door_x + 5, dfy, C["wood2"])

    return img


def draw_trader(market_level: int) -> Image.Image:
    img = _canvas()
    draw = ImageDraw.Draw(img, "RGBA")
    _gradient_sky(draw)
    _ground_strip(draw, y_start=29)

    # Caravan cart
    # Wheels
    _rect(draw, 8,  25, 13, 30, C["dark"])
    _rect(draw, 26, 25, 31, 30, C["dark"])
    for wx, wy in [(10, 27), (28, 27)]:
        _p(draw, wx, wy, C["gray"])
    # Cart body
    _rect(draw, 5, 16, 34, 26, C["wood"])
    # Wooden planks
    for y in range(16, 26, 4):
        _rect(draw, 5, y, 34, y, C["brown2"])
    # Roof/cover
    for i in range(15):
        _rect(draw, 5 + i, 16 - i // 3, 34 - i, 16 - i // 3, C["orange"])
    # Window / opening
    _rect(draw, 14, 19, 25, 25, C["dark"])
    # Merchant inside
    _p(draw, 18, 18, C["window"])
    _p(draw, 19, 18, C["window"])
    _p(draw, 18, 19, C["gray"])
    _p(draw, 19, 19, C["gray"])
    _p(draw, 18, 20, C["brown"])
    _p(draw, 19, 20, C["brown"])
    # Goods displayed
    _p(draw, 15, 22, C["gold"])
    _p(draw, 17, 21, C["ore"])
    _p(draw, 20, 22, C["green"])
    _p(draw, 23, 21, C["wood"])
    # Sign
    _rect(draw, 14, 14, 25, 17, C["wood2"])
    _p(draw, 19, 15, C["gold"])
    # Horse (simple)
    _rect(draw, 36, 21, 39, 26, C["brown"])
    _rect(draw, 35, 19, 37, 21, C["brown"])
    _p(draw, 35, 18, C["dark"])
    _rect(draw, 36, 26, 36, 29, C["brown2"])
    _rect(draw, 38, 26, 38, 29, C["brown2"])

    return img


def draw_villager(tier: int) -> Image.Image:
    """Draw a simple villager/hero figure."""
    img = _canvas(20, 30, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img, "RGBA")

    colors = [
        C["gray"], C["stone"], C["brown"], C["gold"], C["blue"]
    ]
    armor_col = colors[min(tier, len(colors) - 1)]

    # Head
    _rect(draw, 7, 2, 13, 8, (220, 190, 150))
    # Eyes
    _p(draw, 9, 4, C["dark"])
    _p(draw, 12, 4, C["dark"])
    # Body
    _rect(draw, 6, 9, 14, 18, armor_col)
    # Arms
    _rect(draw, 3, 9, 6, 15, armor_col)
    _rect(draw, 14, 9, 17, 15, armor_col)
    # Legs
    _rect(draw, 7, 19, 10, 25, C["dark"])
    _rect(draw, 11, 19, 14, 25, C["dark"])
    # Sword
    _rect(draw, 16, 8, 17, 20, C["gray"])
    _p(draw, 15, 9, C["gray"])

    return img


# ─── Main Entry Points ────────────────────────────────────────────────────────

_BUILDING_DRAW_FNS = {
    "town_hall":       draw_town_hall,
    "farm":            draw_farm,
    "sawmill":         draw_sawmill,
    "mine":            draw_mine,
    "quarry":          draw_mine,
    "smithy":          draw_smithy,
    "barracks":        draw_barracks,
    "market_building": draw_market,
    "storage":         draw_storage,
}


def generate_building_image(building_key: str, level: int) -> io.BytesIO:
    draw_fn = _BUILDING_DRAW_FNS.get(building_key)
    if draw_fn:
        img = draw_fn(level)
    else:
        img = _canvas()
        d = ImageDraw.Draw(img, "RGBA")
        _gradient_sky(d)
        _ground_strip(d)

    # Add level badge
    if level > 0:
        badge_img = Image.new("RGBA", (4 * SCALE, 4 * SCALE), (0, 0, 0, 0))
        bd = ImageDraw.Draw(badge_img)
        bd.rounded_rectangle([0, 0, 4 * SCALE - 1, 4 * SCALE - 1], radius=6, fill=(30, 30, 60, 200))
        try:
            fnt = ImageFont.load_default()
            bd.text((4, 4), f"{level}", fill=(255, 220, 50), font=fnt)
        except Exception:
            pass
        img.paste(badge_img, (2 * SCALE, 2 * SCALE), badge_img)

    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG", optimize=True)
    buf.seek(0)
    return buf


def generate_trader_image(market_level: int) -> io.BytesIO:
    img = draw_trader(market_level)
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG", optimize=True)
    buf.seek(0)
    return buf
