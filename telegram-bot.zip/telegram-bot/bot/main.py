import asyncio
import logging
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, BotCommandScopeDefault, MenuButtonWebApp, WebAppInfo

from config import BOT_TOKEN
from database import init_db
from middlewares.ban_check import BanCheckMiddleware

from handlers import start, buildings, market, top, profile, admin, donate
from handlers import army, war, dungeons, quests, trader, referral, crafting


async def set_commands(bot: Bot):
    commands = [
        BotCommand(command="start",    description="» Главное меню"),
        BotCommand(command="war",      description="» Битва деревень"),
        BotCommand(command="profile",  description="» Профиль"),
        BotCommand(command="dungeons", description="» Подземелья"),
        BotCommand(command="market",   description="» Рынок"),
        BotCommand(command="smithy",   description="» Кузница"),
        BotCommand(command="barracks", description="» Казармы"),
        BotCommand(command="mine",     description="» Шахта"),
        BotCommand(command="farm",     description="» Ферма"),
        BotCommand(command="storage",  description="» Склад"),
        BotCommand(command="top",      description="» Топ игроков"),
        BotCommand(command="sawmill",  description="» Лесопилка"),
    ]
    await bot.set_my_commands(commands, scope=BotCommandScopeDefault())


async def set_menu_button(bot: Bot):
    webapp_url = os.getenv("WEBAPP_URL", "")
    if not webapp_url:
        domains = os.getenv("REPLIT_DOMAINS", "")
        if domains:
            domain = domains.split(",")[0].strip()
            webapp_url = f"https://{domain}/game"
    if webapp_url:
        try:
            await bot.set_chat_menu_button(
                menu_button=MenuButtonWebApp(
                    text="🏘️ Деревня",
                    web_app=WebAppInfo(url=webapp_url),
                )
            )
            logging.getLogger(__name__).info(f"Menu button set to: {webapp_url}")
        except Exception as e:
            logging.getLogger(__name__).warning(f"Could not set menu button: {e}")


async def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)

    if not BOT_TOKEN:
        logger.error("BOT_TOKEN не установлен!")
        return

    logger.info("Инициализация базы данных...")
    await init_db()
    logger.info("База данных готова.")

    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    dp.message.middleware(BanCheckMiddleware())
    dp.callback_query.middleware(BanCheckMiddleware())

    dp.include_router(start.router)
    dp.include_router(buildings.router)
    dp.include_router(market.router)
    dp.include_router(top.router)
    dp.include_router(profile.router)
    dp.include_router(admin.router)
    dp.include_router(donate.router)
    dp.include_router(army.router)
    dp.include_router(war.router)
    dp.include_router(dungeons.router)
    dp.include_router(quests.router)
    dp.include_router(trader.router)
    dp.include_router(referral.router)
    dp.include_router(crafting.router)

    await set_commands(bot)
    await set_menu_button(bot)
    logger.info("Бот запускается...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
