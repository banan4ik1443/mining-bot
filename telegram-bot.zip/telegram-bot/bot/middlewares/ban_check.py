from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery, TelegramObject
from typing import Any, Awaitable, Callable
from database import check_ban, get_player, register_player


class BanCheckMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        if isinstance(event, (Message, CallbackQuery)):
            user = event.from_user
            if user:
                player = await get_player(user.id)
                if not player:
                    await register_player(user.id, user.first_name or "Игрок", user.username)
                is_banned, reason = await check_ban(user.id)
                if is_banned:
                    text = f"🚫 Вы заблокированы.\n{reason}"
                    if isinstance(event, Message):
                        await event.answer(text)
                    elif isinstance(event, CallbackQuery):
                        await event.answer(text, show_alert=True)
                    return
        return await handler(event, data)
