import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "village_game.db")
BOT_VERSION = "4.0"

ADMIN_IDS: set[int] = set()
_admin_env = os.getenv("ADMIN_IDS", "")
if _admin_env:
    for _aid in _admin_env.split(","):
        if _aid.strip():
            ADMIN_IDS.add(int(_aid.strip()))

# ── Game settings ────────────────────────────────────────────────────────
GAME_SETTINGS = {
    "base_storage": 800,
    "storage_bonus_per_level": 500,
    "market_fee": 0.05,
    "auto_collect_on_view": True,
}
BASE_STORAGE = GAME_SETTINGS["base_storage"]
STORAGE_BONUS_PER_LEVEL = GAME_SETTINGS["storage_bonus_per_level"]
MARKET_FEE = GAME_SETTINGS["market_fee"]

MARKET_FEE_BY_LEVEL = [0.10, 0.09, 0.08, 0.07, 0.06, 0.05, 0.04, 0.03, 0.02, 0.01, 0.005]
TRADER_BONUS_BY_LEVEL = [1.0, 1.0, 1.05, 1.10, 1.15, 1.20, 1.25, 1.30, 1.40, 1.50, 1.60]

def get_market_fee(market_level: int) -> float:
    idx = max(0, min(market_level, len(MARKET_FEE_BY_LEVEL) - 1))
    return MARKET_FEE_BY_LEVEL[idx]

def get_trader_bonus(market_level: int) -> float:
    idx = max(0, min(market_level, len(TRADER_BONUS_BY_LEVEL) - 1))
    return TRADER_BONUS_BY_LEVEL[idx]

# ── Resources ────────────────────────────────────────────────────────────
RESOURCE_EMOJIS = {
    "wood": "🪵", "ore": "⛏️", "stone": "🪨", "food": "🌾", "gold": "💰",
    "iron_ore": "🔩", "silver_ore": "🥈", "gold_ore": "🏅", "mithril": "💠",
}
RESOURCE_NAMES = {
    "wood": "Дерево", "ore": "Руда", "stone": "Камень", "food": "Еда", "gold": "Золото",
    "iron_ore": "Железная руда", "silver_ore": "Серебряная руда",
    "gold_ore": "Золотая руда", "mithril": "Митрил",
}

# Стартовые ресурсы — хватит на первые 2-3 постройки
START_RESOURCES = {"wood": 350, "ore": 0, "stone": 200, "food": 300, "gold": 100}

# ── Food consumption ─────────────────────────────────────────────────────
# Еда пассивно тратится каждый час:
# Лесопилка: level * 2 ед/ч
# Шахта: level * 2 ед/ч
# Каждый воин: 0.5 ед/ч
FOOD_CONSUMPTION_SAWMILL = 2.0
FOOD_CONSUMPTION_MINE    = 2.0
FOOD_CONSUMPTION_SOLDIER = 0.5

# ── Ore Clusters ────────────────────────────────────────────────────────
CLUSTER_CHANCES_BY_LEVEL = {
    4:  {"iron_cluster": 0.18},
    5:  {"iron_cluster": 0.22, "silver_cluster": 0.05},
    6:  {"iron_cluster": 0.28, "silver_cluster": 0.09},
    7:  {"iron_cluster": 0.33, "silver_cluster": 0.13, "gold_cluster": 0.03},
    8:  {"iron_cluster": 0.38, "silver_cluster": 0.16, "gold_cluster": 0.06},
    9:  {"iron_cluster": 0.42, "silver_cluster": 0.20, "gold_cluster": 0.09, "mithril_cluster": 0.015},
    10: {"iron_cluster": 0.50, "silver_cluster": 0.25, "gold_cluster": 0.12, "mithril_cluster": 0.03},
}

ORE_CLUSTER_CONTENTS = {
    "iron_cluster":    {"name": "Железный кластер",     "emoji": "📦", "drops": [
        ("iron_ore",   (15, 40), 0.90),
        ("silver_ore", (3,  10), 0.25),
    ]},
    "silver_cluster":  {"name": "Серебряный кластер",   "emoji": "🌟", "drops": [
        ("iron_ore",   (5,  15), 0.70),
        ("silver_ore", (8,  20), 0.90),
        ("gold_ore",   (1,  4),  0.15),
    ]},
    "gold_cluster":    {"name": "Золотой кластер",      "emoji": "✨", "drops": [
        ("silver_ore", (5,  12), 0.70),
        ("gold_ore",   (4,  10), 0.90),
        ("mithril",    (1,  2),  0.10),
    ]},
    "mithril_cluster": {"name": "Митриловый кластер",   "emoji": "💠", "drops": [
        ("gold_ore",   (3,  8),  0.70),
        ("mithril",    (2,  5),  0.95),
    ]},
}

CLUSTER_EMOJIS = {
    "iron_cluster": "📦", "silver_cluster": "🌟",
    "gold_cluster": "✨", "mithril_cluster": "💠",
}

# ── Buildings ────────────────────────────────────────────────────────────
# Баланс на ~1 месяц прохождения при активной игре 2-3 раза в день.
# Уровни 1-3: несколько дней | 4-6: ~2 недели | 7-10: 3-4 неделя
BUILDINGS_CONFIG: dict = {
    "town_hall":       {
        "name": "Ратуша",     "emoji": "🏛️", "command": "townhall",
        "description": "Главное здание деревни. Задаёт максимальный уровень всех построек.",
        # ур.2: 600w 360s | ур.5: 1500w 900s | ур.10: 3000w 1800s
        "upgrade_cost": lambda lvl: {"wood": lvl*300, "stone": lvl*180},
        "production": None, "max_level": 10, "start_level": 1, "hidden": False,
    },
    "farm":            {
        "name": "Ферма",      "emoji": "🌾", "command": "farm",
        "description": "Производит еду. Еда нужна лесопилке, шахте и воинам.",
        # ур.1: 80w 50s | ур.5: 340w 170s | ур.10: 640w 320s
        "upgrade_cost": lambda lvl: {"wood": lvl*60+20, "stone": lvl*30+20},
        "production": ("food", 25), "max_level": 10, "start_level": 0, "hidden": False,
    },
    "sawmill":         {
        "name": "Лесопилка",  "emoji": "🪵", "command": "sawmill",
        "description": "Заготавливает дерево. Каждый уровень тратит 2 еды/ч.",
        # ур.1: 65o 50s | ур.5: 225o 170s | ур.10: 425o 320s
        "upgrade_cost": lambda lvl: {"ore": lvl*40+25, "stone": lvl*30+20},
        "production": ("wood", 15), "max_level": 10, "start_level": 1, "hidden": False,
    },
    "mine":            {
        "name": "Шахта",      "emoji": "⛏️", "command": "mine",
        "description": "Добывает камень и руду. С ур.2 — руда. С ур.4 — кластеры редких руд.",
        # ур.1: 125w 75s | ур.5: 345w 165s | ур.10: 620w 290s
        "upgrade_cost": lambda lvl: {"wood": lvl*55+70, "stone": lvl*25+50},
        "production": ("stone", 10), "max_level": 10, "start_level": 0, "hidden": False,
    },
    "quarry":          {
        "name": "Каменоломня", "emoji": "🪨", "command": "quarry",
        "description": "Устаревшее здание — объединено с Шахтой.",
        "upgrade_cost": lambda lvl: {"wood": lvl*20+25, "food": lvl*10+10},
        "production": ("stone", 10), "max_level": 10, "start_level": 0, "hidden": True,
    },
    "smithy":          {
        "name": "Кузница",    "emoji": "🔨", "command": "smithy",
        "description": "Переплавляет руду в золото. Позволяет ковать снаряжение и крафтить предметы.",
        # ур.1: 220o 180s | ур.5: 620o 430s | ур.10: 1120o 780s
        "upgrade_cost": lambda lvl: {"ore": lvl*100+120, "stone": lvl*70+110},
        "production": ("gold", 7), "max_level": 10, "start_level": 0, "hidden": False,
    },
    "barracks":        {
        "name": "Казармы",    "emoji": "⚔️", "command": "barracks",
        "description": "Тренирует воинов. Вместимость = уровень × 5.",
        # ур.1: 280w 220o 140f | ур.5: 760w 420o 480f | ур.10: 1360w 750o 860f
        "upgrade_cost": lambda lvl: {"wood": lvl*120+160, "ore": lvl*65+155, "food": lvl*80+60},
        "production": None, "max_level": 10, "start_level": 0, "hidden": False,
    },
    "market_building": {
        "name": "Рынок",      "emoji": "🏪", "command": "market",
        "description": "Торговля ресурсами между игроками. Выше уровень — ниже комиссия.",
        # ур.1: 300w 390g | ур.5: 700w 950g | ур.10: 1200w 1650g
        "upgrade_cost": lambda lvl: {"wood": lvl*100+200, "gold": lvl*150+240},
        "production": None, "max_level": 10, "start_level": 0, "hidden": False,
    },
    "storage":         {
        "name": "Склад",      "emoji": "🏦", "command": "storage",
        "description": "Увеличивает вместимость хранилища. +500 к каждому ресурсу за уровень.",
        # ур.1: 180w 145s | ур.5: 500w 405s | ур.10: 900w 730s
        "upgrade_cost": lambda lvl: {"wood": lvl*80+100, "stone": lvl*65+80},
        "production": None, "max_level": 10, "start_level": 0, "hidden": False,
    },
}

BUILDING_ORDER = ["town_hall", "farm", "sawmill", "mine", "smithy", "barracks", "market_building", "storage"]
COMMAND_TO_BUILDING = {cfg["command"]: key for key, cfg in BUILDINGS_CONFIG.items()}

# ── Army ─────────────────────────────────────────────────────────────────
UNITS_CONFIG = {
    "swordsman":    {"name": "Мечник",   "emoji": "⚔️", "cost_gold": 80,  "attack": 12, "defense": 6,  "health": 100},
    "shieldbearer": {"name": "Щитовщик", "emoji": "🛡️", "cost_gold": 110, "attack": 5,  "defense": 20, "health": 180},
    "mage":         {"name": "Маг",      "emoji": "🧙", "cost_gold": 150, "attack": 28, "defense": 3,  "health": 70},
}

EQUIPMENT_TIERS = {
    0: {"name": "Нет снаряжения",  "emoji": "—",  "attack_bonus": 0.00, "defense_bonus": 0.00, "cost": {}, "min_smithy": 0},
    1: {"name": "Железное",        "emoji": "⚙️", "attack_bonus": 0.15, "defense_bonus": 0.15, "cost": {"ore": 500, "gold": 300}, "min_smithy": 1},
    2: {"name": "Стальное",        "emoji": "🔩", "attack_bonus": 0.35, "defense_bonus": 0.35, "cost": {"ore": 1500, "stone": 800, "gold": 800}, "min_smithy": 3},
    3: {"name": "Митриловое",      "emoji": "💎", "attack_bonus": 0.65, "defense_bonus": 0.65, "cost": {"ore": 1000, "stone": 1000, "gold": 2000}, "min_smithy": 5, "fragments": 30},
    4: {"name": "Легендарное",     "emoji": "🌟", "attack_bonus": 1.20, "defense_bonus": 1.20, "cost": {"gold": 6000}, "min_smithy": 7, "fragments": 150},
}

# ── Craftable Items ───────────────────────────────────────────────────────
CRAFTABLE_ITEMS = {
    # Мечи
    "iron_sword":     {"name": "Железный меч",        "emoji": "🗡️",  "slot": "weapon",  "cost": {"iron_ore": 50},              "min_smithy": 2, "attack_bonus": 0.10, "defense_bonus": 0.0},
    "silver_sword":   {"name": "Серебряный меч",      "emoji": "⚔️",  "slot": "weapon",  "cost": {"silver_ore": 35},            "min_smithy": 4, "attack_bonus": 0.25, "defense_bonus": 0.0},
    "gold_sword":     {"name": "Золотой клинок",      "emoji": "🌠",  "slot": "weapon",  "cost": {"gold_ore": 20},              "min_smithy": 6, "attack_bonus": 0.45, "defense_bonus": 0.0},
    "mithril_sword":  {"name": "Митриловый клинок",   "emoji": "💎",  "slot": "weapon",  "cost": {"mithril": 8},                "min_smithy": 8, "attack_bonus": 0.80, "defense_bonus": 0.0},
    # Посохи
    "iron_staff":     {"name": "Железный посох",      "emoji": "🪄",  "slot": "weapon",  "cost": {"iron_ore": 40, "gold": 200}, "min_smithy": 2, "attack_bonus": 0.08, "defense_bonus": 0.05},
    "silver_staff":   {"name": "Серебряный посох",    "emoji": "🔮",  "slot": "weapon",  "cost": {"silver_ore": 25, "gold": 600},"min_smithy": 4, "attack_bonus": 0.20, "defense_bonus": 0.12},
    "mithril_staff":  {"name": "Посох Митрила",       "emoji": "💠",  "slot": "weapon",  "cost": {"mithril": 6, "gold": 1500},  "min_smithy": 8, "attack_bonus": 0.60, "defense_bonus": 0.30},
    # Броня
    "iron_armor":     {"name": "Железная броня",      "emoji": "🛡️",  "slot": "armor",   "cost": {"iron_ore": 65},              "min_smithy": 2, "attack_bonus": 0.0,  "defense_bonus": 0.15},
    "silver_armor":   {"name": "Серебряная кольчуга", "emoji": "🥋",  "slot": "armor",   "cost": {"silver_ore": 40},            "min_smithy": 4, "attack_bonus": 0.0,  "defense_bonus": 0.30},
    "gold_armor":     {"name": "Золотые доспехи",     "emoji": "👑",  "slot": "armor",   "cost": {"gold_ore": 25, "gold": 400}, "min_smithy": 6, "attack_bonus": 0.05, "defense_bonus": 0.50},
    "mithril_armor":  {"name": "Митриловые доспехи",  "emoji": "🔰",  "slot": "armor",   "cost": {"mithril": 10},               "min_smithy": 8, "attack_bonus": 0.10, "defense_bonus": 0.90},
}

# ── Dungeons ──────────────────────────────────────────────────────────────
DUNGEONS = [
    {"id": "forest",    "name": "Тёмный лес",        "emoji": "🌲", "boss": "Лесной дух",       "boss_power": 100,  "min_power": 40,   "cooldown": 6*3600,  "loot_tier": 1},
    {"id": "dungeon",   "name": "Древняя темница",    "emoji": "🏚️", "boss": "Скелет-рыцарь",   "boss_power": 350,  "min_power": 150,  "cooldown": 8*3600,  "loot_tier": 2},
    {"id": "mountains", "name": "Горные пещеры",      "emoji": "🏔️", "boss": "Горный тролль",    "boss_power": 800,  "min_power": 350,  "cooldown": 12*3600, "loot_tier": 3},
    {"id": "volcano",   "name": "Огненный вулкан",    "emoji": "🌋", "boss": "Огненный великан", "boss_power": 1800, "min_power": 700,  "cooldown": 18*3600, "loot_tier": 4},
    {"id": "citadel",   "name": "Проклятая цитадель", "emoji": "🏰", "boss": "Некромант",        "boss_power": 4000, "min_power": 1500, "cooldown": 24*3600, "loot_tier": 5},
]
DUNGEON_LOOT = {
    1: {"wood": (150,400), "ore": (80,200), "gold": (50,120),   "frag_chance": 0.08},
    2: {"wood": (300,700), "ore": (200,500),"stone":(150,400),  "gold": (100,250),  "frag_chance": 0.15},
    3: {"ore": (400,900),  "stone": (300,700), "gold": (200,500),  "frag_chance": 0.28},
    4: {"stone": (700,1400),"gold": (400,1000), "frag_chance": 0.45},
    5: {"gold": (700,2000), "frag_chance": 1.00, "frag_count": (4,10)},
}

# ── Daily quests ──────────────────────────────────────────────────────────
QUEST_POOL = [
    {"type": "hire_units",       "name": "Нанять воинов",       "scale": 3,   "reward": "gold",  "reward_scale": 150},
    {"type": "upgrade_building", "name": "Улучшить здание",     "scale": 1,   "reward": "wood",  "reward_scale": 500},
    {"type": "raid_dungeon",     "name": "Совершить рейд",      "scale": 1,   "reward": "gold",  "reward_scale": 300},
    {"type": "sell_market",      "name": "Продать на рынке",    "scale": 50,  "reward": "ore",   "reward_scale": 300},
    {"type": "have_units",       "name": "Держать войско",      "scale": 5,   "reward": "food",  "reward_scale": 200},
    {"type": "collect_gold",     "name": "Накопить золото",     "scale": 300, "reward": "stone", "reward_scale": 200},
]

# ── Wandering Trader ──────────────────────────────────────────────────────
TRADER_POOL = [
    {"id": "t_buy_wood",  "give_res": "gold",  "give_amt": 60,  "get_res": "wood",  "get_amt": 250},
    {"id": "t_buy_ore",   "give_res": "gold",  "give_amt": 80,  "get_res": "ore",   "get_amt": 200},
    {"id": "t_buy_stone", "give_res": "gold",  "give_amt": 55,  "get_res": "stone", "get_amt": 230},
    {"id": "t_buy_food",  "give_res": "gold",  "give_amt": 50,  "get_res": "food",  "get_amt": 280},
    {"id": "t_sell_wood", "give_res": "wood",  "give_amt": 350, "get_res": "gold",  "get_amt": 80},
    {"id": "t_sell_ore",  "give_res": "ore",   "give_amt": 250, "get_res": "gold",  "get_amt": 100},
    {"id": "t_sell_stone","give_res": "stone", "give_amt": 300, "get_res": "gold",  "get_amt": 65},
    {"id": "t_sell_food", "give_res": "food",  "give_amt": 350, "get_res": "gold",  "get_amt": 70},
    {"id": "t_ore_wood",  "give_res": "wood",  "give_amt": 250, "get_res": "ore",   "get_amt": 150},
    {"id": "t_stone_ore", "give_res": "ore",   "give_amt": 180, "get_res": "stone", "get_amt": 250},
    {"id": "t_food_wood", "give_res": "wood",  "give_amt": 180, "get_res": "food",  "get_amt": 240},
    {"id": "t_gold_food", "give_res": "gold",  "give_amt": 150, "get_res": "food",  "get_amt": 800},
]

# ── Donate ────────────────────────────────────────────────────────────────
DONATE_PACKAGES = [
    {"id": "pack_50",  "stars": 50,  "label": "⭐ 50 звёзд",  "title": "Пакет «Помощник»", "description": "500 каждого ресурса", "resources": {"wood":500,"ore":500,"stone":500,"food":500,"gold":500}},
    {"id": "pack_100", "stars": 100, "label": "⭐ 100 звёзд", "title": "Пакет «Спонсор»",  "description": "1500 каждого + 500 золота", "resources": {"wood":1500,"ore":1500,"stone":1500,"food":1500,"gold":2000}},
    {"id": "pack_250", "stars": 250, "label": "⭐ 250 звёзд", "title": "Пакет «Легенда»",  "description": "5000 каждого + 3000 золота + 30 фрагментов", "resources": {"wood":5000,"ore":5000,"stone":5000,"food":5000,"gold":8000}, "fragments": 30},
]

# ── Bans ──────────────────────────────────────────────────────────────────
BAN_DURATIONS = {
    "1h": ("1 час", 3600), "6h": ("6 часов", 21600), "24h": ("24 часа", 86400),
    "7d": ("7 дней", 604800), "30d": ("30 дней", 2592000), "perm": ("Навсегда", -1),
}

# ── Referral rewards ─────────────────────────────────────────────────────
REFERRAL_REWARD_REFERRER = {"gold": 300, "wood": 500}
REFERRAL_REWARD_NEW_PLAYER = {"gold": 150, "food": 300}
