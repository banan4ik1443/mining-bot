import aiosqlite
import random
import time
from typing import Optional
from config import (DB_PATH, BUILDINGS_CONFIG, START_RESOURCES, BASE_STORAGE,
                    STORAGE_BONUS_PER_LEVEL, MARKET_FEE, FOOD_CONSUMPTION_SAWMILL,
                    FOOD_CONSUMPTION_MINE, FOOD_CONSUMPTION_SOLDIER,
                    CLUSTER_CHANCES_BY_LEVEL, ORE_CLUSTER_CONTENTS,
                    CRAFTABLE_ITEMS, REFERRAL_REWARD_REFERRER, REFERRAL_REWARD_NEW_PLAYER)


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                wood REAL DEFAULT 0,
                ore REAL DEFAULT 0,
                stone REAL DEFAULT 0,
                food REAL DEFAULT 0,
                gold REAL DEFAULT 0,
                last_collected INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                ban_until INTEGER DEFAULT 0,
                ban_reason TEXT DEFAULT '',
                created_at INTEGER DEFAULT 0,
                village_name TEXT DEFAULT '',
                referred_by INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS buildings (
                user_id INTEGER,
                building_key TEXT,
                level INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, building_key)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS market_listings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id INTEGER,
                seller_name TEXT,
                resource TEXT,
                amount REAL,
                price_per_unit REAL,
                created_at INTEGER,
                is_active INTEGER DEFAULT 1
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS ban_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                banned_by INTEGER,
                reason TEXT,
                ban_until INTEGER,
                banned_at INTEGER,
                unbanned_at INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS army (
                user_id INTEGER,
                unit_type TEXT,
                count INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, unit_type)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS equipment (
                user_id INTEGER PRIMARY KEY,
                tier INTEGER DEFAULT 0,
                owned_tiers TEXT DEFAULT '[]'
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS daily_quests (
                user_id INTEGER,
                quest_date TEXT,
                quest_index INTEGER,
                quest_type TEXT,
                quest_name TEXT,
                target INTEGER DEFAULT 0,
                progress INTEGER DEFAULT 0,
                completed INTEGER DEFAULT 0,
                reward_resource TEXT DEFAULT 'gold',
                reward_amount INTEGER DEFAULT 0,
                reward_claimed INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, quest_date, quest_index)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS dungeon_cooldowns (
                user_id INTEGER,
                dungeon_id TEXT,
                last_raid INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, dungeon_id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                user_id INTEGER,
                item_type TEXT,
                quantity INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, item_type)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS war_cooldowns (
                user_id INTEGER PRIMARY KEY,
                last_attack INTEGER DEFAULT 0,
                shield_until INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS trader_purchases (
                user_id INTEGER,
                trade_id TEXT,
                hour_key TEXT,
                PRIMARY KEY (user_id, trade_id, hour_key)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS smithy_cooldowns (
                user_id INTEGER PRIMARY KEY,
                last_craft INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS war_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                attacker_id INTEGER,
                defender_id INTEGER,
                attacker_power INTEGER DEFAULT 0,
                defender_power INTEGER DEFAULT 0,
                won INTEGER DEFAULT 0,
                timestamp INTEGER DEFAULT 0
            )
        """)
        # Player settings
        await db.execute("""
            CREATE TABLE IF NOT EXISTS player_settings (
                user_id INTEGER PRIMARY KEY,
                hide_profile_link INTEGER DEFAULT 0,
                profile_photo_id TEXT DEFAULT ''
            )
        """)
        # Village action logs
        await db.execute("""
            CREATE TABLE IF NOT EXISTS village_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                message TEXT,
                timestamp INTEGER
            )
        """)
        # Referrals
        await db.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                referrer_id INTEGER,
                referred_id INTEGER,
                rewarded INTEGER DEFAULT 0,
                created_at INTEGER,
                PRIMARY KEY (referrer_id, referred_id)
            )
        """)
        # Crafted items (inventory of crafted equipment)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS crafted_items (
                user_id INTEGER,
                item_key TEXT,
                quantity INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, item_key)
            )
        """)
        # Currently equipped crafted item
        await db.execute("""
            CREATE TABLE IF NOT EXISTS equipped_crafted (
                user_id INTEGER PRIMARY KEY,
                item_key TEXT DEFAULT ''
            )
        """)
        # Migrations for existing DBs
        for migration in [
            "ALTER TABLE players ADD COLUMN village_name TEXT DEFAULT ''",
            "ALTER TABLE players ADD COLUMN referred_by INTEGER DEFAULT 0",
            "ALTER TABLE equipment ADD COLUMN owned_tiers TEXT DEFAULT '[]'",
        ]:
            try:
                await db.execute(migration)
            except Exception:
                pass
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
#  Player
# ─────────────────────────────────────────────────────────────────────────────

async def register_player(user_id: int, first_name: str, username: str, ref_id: int | None = None) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        now = int(time.time())
        cur = await db.execute("""
            INSERT OR IGNORE INTO players (user_id, username, first_name, wood, ore, stone, food, gold, last_collected, created_at, referred_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id, username, first_name,
            START_RESOURCES["wood"], START_RESOURCES["ore"],
            START_RESOURCES["stone"], START_RESOURCES["food"], START_RESOURCES["gold"],
            now, now, ref_id or 0
        ))
        if cur.rowcount == 0:
            await db.execute(
                "UPDATE players SET username=?, first_name=? WHERE user_id=?",
                (username, first_name, user_id)
            )
            await db.commit()
            return False
        for key, cfg in BUILDINGS_CONFIG.items():
            if cfg.get("hidden", False):
                continue
            level = cfg.get("start_level", 0)
            await db.execute(
                "INSERT INTO buildings (user_id, building_key, level) VALUES (?, ?, ?)",
                (user_id, key, level)
            )
        await db.commit()

    # Handle referral reward
    if ref_id and ref_id != user_id:
        await _handle_referral(ref_id, user_id)

    return True


async def _handle_referral(referrer_id: int, referred_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id FROM players WHERE user_id=?", (referrer_id,))
        if not await cur.fetchone():
            return
        cur2 = await db.execute(
            "SELECT rewarded FROM referrals WHERE referrer_id=? AND referred_id=?",
            (referrer_id, referred_id)
        )
        if await cur2.fetchone():
            return
        now = int(time.time())
        await db.execute("""
            INSERT OR IGNORE INTO referrals (referrer_id, referred_id, rewarded, created_at)
            VALUES (?, ?, 1, ?)
        """, (referrer_id, referred_id, now))
        # Give referrer reward
        for res, amt in REFERRAL_REWARD_REFERRER.items():
            await db.execute(f"UPDATE players SET {res}={res}+? WHERE user_id=?", (amt, referrer_id))
        # Give new player reward
        for res, amt in REFERRAL_REWARD_NEW_PLAYER.items():
            await db.execute(f"UPDATE players SET {res}={res}+? WHERE user_id=?", (amt, referred_id))
        await db.commit()


async def get_player(user_id: int) -> Optional[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM players WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row:
            return None
        return dict(row)


async def get_buildings(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT building_key, level FROM buildings WHERE user_id=?", (user_id,))
        rows = await cur.fetchall()
        return {row[0]: row[1] for row in rows}


async def update_resources(user_id: int, **kwargs):
    async with aiosqlite.connect(DB_PATH) as db:
        for key, val in kwargs.items():
            await db.execute(f"UPDATE players SET {key}=? WHERE user_id=?", (val, user_id))
        await db.commit()


async def collect_resources(user_id: int) -> dict:
    player = await get_player(user_id)
    if not player:
        return {}
    buildings = await get_buildings(user_id)

    now = int(time.time())
    elapsed = now - player["last_collected"]
    hours = elapsed / 3600.0

    gained = {"wood": 0.0, "ore": 0.0, "stone": 0.0, "food": 0.0, "gold": 0.0}
    new_clusters: list[str] = []

    for key, cfg in BUILDINGS_CONFIG.items():
        if cfg.get("hidden", False):
            continue
        level = buildings.get(key, 0)
        if level <= 0:
            continue

        if key == "mine":
            # Stone: all levels
            stone_rate = 8 * level
            gained["stone"] += stone_rate * hours
            # Ore: level 2+
            if level >= 2:
                ore_rate = (level - 1) * 8
                gained["ore"] += ore_rate * hours
            # Ore clusters: level 4+
            if level >= 4:
                level_chances = CLUSTER_CHANCES_BY_LEVEL.get(level, {})
                for cluster_type, chance_per_hour in level_chances.items():
                    expected = chance_per_hour * hours
                    count = int(expected) + (1 if random.random() < (expected % 1) else 0)
                    for _ in range(count):
                        new_clusters.append(cluster_type)
        elif key == "farm":
            if cfg["production"]:
                res, rate = cfg["production"]
                gained[res] += rate * level * hours
        elif cfg["production"] is not None:
            res, rate = cfg["production"]
            gained[res] += rate * level * hours

    # Also collect old quarry if it exists in buildings (legacy)
    quarry_level = buildings.get("quarry", 0)
    if quarry_level > 0:
        gained["stone"] += 8 * quarry_level * hours

    # Food consumption
    army = await get_army(user_id)
    total_units = sum(army.values())
    food_consume = (
        buildings.get("sawmill", 0) * FOOD_CONSUMPTION_SAWMILL +
        buildings.get("mine", 0) * FOOD_CONSUMPTION_MINE +
        total_units * FOOD_CONSUMPTION_SOLDIER
    ) * hours
    gained["food"] -= food_consume

    storage_level = buildings.get("storage", 0)
    max_res = BASE_STORAGE + storage_level * STORAGE_BONUS_PER_LEVEL

    new_resources = {}
    for res in ["wood", "ore", "stone", "food", "gold"]:
        current = player[res]
        add = gained[res]
        new_val = max(0.0, min(current + add, max_res))
        new_resources[res] = new_val

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            UPDATE players SET wood=?, ore=?, stone=?, food=?, gold=?, last_collected=?
            WHERE user_id=?
        """, (
            new_resources["wood"], new_resources["ore"],
            new_resources["stone"], new_resources["food"],
            new_resources["gold"], now, user_id
        ))
        # Add ore clusters to inventory
        for cluster_type in new_clusters:
            await db.execute("""
                INSERT INTO inventory (user_id, item_type, quantity) VALUES (?, ?, 1)
                ON CONFLICT(user_id, item_type) DO UPDATE SET quantity=quantity+1
            """, (user_id, cluster_type))
        await db.commit()

    actually_gained = {res: new_resources[res] - player[res] for res in gained if res in new_resources}
    return actually_gained


async def upgrade_building(user_id: int, building_key: str) -> tuple[bool, str]:
    player = await get_player(user_id)
    if not player:
        return False, "Игрок не найден"

    buildings = await get_buildings(user_id)
    cfg = BUILDINGS_CONFIG.get(building_key)
    if not cfg or cfg.get("hidden", False):
        return False, "Здание не найдено"

    current_level = buildings.get(building_key, 0)
    th_level = buildings.get("town_hall", 1)

    max_level = cfg.get("max_level")
    if max_level and current_level >= max_level:
        return False, f"Максимальный уровень {max_level} уже достигнут!"

    if building_key != "town_hall":
        max_by_th = th_level * 2
        if current_level >= max_by_th:
            return False, f"Нужно улучшить Ратушу! (макс. уровень: {max_by_th})"

    next_level = current_level + 1
    cost = cfg["upgrade_cost"](next_level)

    for res, amount in cost.items():
        if player.get(res, 0) < amount:
            from config import RESOURCE_EMOJIS, RESOURCE_NAMES
            return False, f"Недостаточно {RESOURCE_EMOJIS[res]} {RESOURCE_NAMES[res]}! Нужно: {amount:.0f} (есть: {player.get(res,0):.0f})"

    new_resources = {res: player[res] for res in ["wood", "ore", "stone", "food", "gold"]}
    for res, amount in cost.items():
        new_resources[res] -= amount

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            UPDATE players SET wood=?, ore=?, stone=?, food=?, gold=? WHERE user_id=?
        """, (
            new_resources["wood"], new_resources["ore"],
            new_resources["stone"], new_resources["food"],
            new_resources["gold"], user_id
        ))
        await db.execute(
            "INSERT INTO buildings (user_id, building_key, level) VALUES (?, ?, ?) ON CONFLICT(user_id, building_key) DO UPDATE SET level=?",
            (user_id, building_key, next_level, next_level)
        )
        await db.commit()

    return True, f"{'Построено' if current_level == 0 else 'Улучшено'} до уровня {next_level}!"


async def update_village_name(user_id: int, name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE players SET village_name=? WHERE user_id=?", (name, user_id))
        await db.commit()


async def get_top_players(limit: int = 10) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT p.user_id, p.first_name, p.username, p.gold,
                   COALESCE(SUM(b.level), 0) as total_building_levels
            FROM players p
            LEFT JOIN buildings b ON p.user_id = b.user_id
            WHERE p.is_banned = 0
            GROUP BY p.user_id
            ORDER BY total_building_levels DESC, p.gold DESC
            LIMIT ?
        """, (limit,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
#  Player settings
# ─────────────────────────────────────────────────────────────────────────────

async def get_player_settings(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM player_settings WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row:
            return {"hide_profile_link": False, "profile_photo_id": ""}
        return dict(row)


async def toggle_profile_link(user_id: int, hide: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO player_settings (user_id, hide_profile_link) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET hide_profile_link=?
        """, (user_id, int(hide), int(hide)))
        await db.commit()


async def update_profile_photo(user_id: int, photo_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO player_settings (user_id, profile_photo_id) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET profile_photo_id=?
        """, (user_id, photo_id, photo_id))
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
#  Village logs
# ─────────────────────────────────────────────────────────────────────────────

async def log_action(user_id: int, message: str):
    now = int(time.time())
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO village_logs (user_id, message, timestamp) VALUES (?, ?, ?)",
            (user_id, message, now)
        )
        # Keep only last 100 logs per player
        await db.execute("""
            DELETE FROM village_logs WHERE user_id=? AND id NOT IN (
                SELECT id FROM village_logs WHERE user_id=? ORDER BY timestamp DESC LIMIT 100
            )
        """, (user_id, user_id))
        await db.commit()


async def get_village_logs(user_id: int, limit: int = 20) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT message, timestamp FROM village_logs WHERE user_id=? ORDER BY timestamp DESC LIMIT ?",
            (user_id, limit)
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
#  Referrals
# ─────────────────────────────────────────────────────────────────────────────

async def get_referrals(user_id: int) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT r.referred_id, p.first_name, r.created_at
            FROM referrals r
            LEFT JOIN players p ON r.referred_id = p.user_id
            WHERE r.referrer_id=?
            ORDER BY r.created_at DESC
        """, (user_id,))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
#  Ore Clusters
# ─────────────────────────────────────────────────────────────────────────────

async def get_inventory_clusters(user_id: int) -> list[dict]:
    cluster_types = {"iron_cluster", "silver_cluster", "gold_cluster", "mithril_cluster"}
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT item_type, quantity FROM inventory WHERE user_id=? AND quantity > 0",
            (user_id,)
        )
        rows = await cur.fetchall()
        return [{"cluster_type": r[0], "quantity": r[1]} for r in rows if r[0] in cluster_types]


async def open_ore_cluster(user_id: int, cluster_type: str) -> tuple[bool, str, dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT quantity FROM inventory WHERE user_id=? AND item_type=?",
            (user_id, cluster_type)
        )
        row = await cur.fetchone()
        if not row or row[0] <= 0:
            return False, "Кластер не найден", {}

        cfg = ORE_CLUSTER_CONTENTS.get(cluster_type)
        if not cfg:
            return False, "Неизвестный тип кластера", {}

        drops: dict = {}
        for ore_type, (lo, hi), chance in cfg["drops"]:
            if random.random() < chance:
                amount = random.randint(lo, hi)
                drops[ore_type] = drops.get(ore_type, 0) + amount

        await db.execute(
            "UPDATE inventory SET quantity=quantity-1 WHERE user_id=? AND item_type=?",
            (user_id, cluster_type)
        )
        # Give ore to player inventory (rare ores stored in inventory table)
        for ore_type, amount in drops.items():
            await db.execute("""
                INSERT INTO inventory (user_id, item_type, quantity) VALUES (?, ?, ?)
                ON CONFLICT(user_id, item_type) DO UPDATE SET quantity=quantity+?
            """, (user_id, ore_type, amount, amount))
        await db.commit()

    return True, "Кластер открыт!", drops


async def get_rare_ore_amounts(user_id: int) -> dict:
    rare_ores = {"iron_ore", "silver_ore", "gold_ore", "mithril"}
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT item_type, quantity FROM inventory WHERE user_id=? AND quantity > 0",
            (user_id,)
        )
        rows = await cur.fetchall()
        return {r[0]: r[1] for r in rows if r[0] in rare_ores}


# ─────────────────────────────────────────────────────────────────────────────
#  Crafting
# ─────────────────────────────────────────────────────────────────────────────

async def craft_item(user_id: int, item_key: str) -> tuple[bool, str]:
    cfg = CRAFTABLE_ITEMS.get(item_key)
    if not cfg:
        return False, "Предмет не найден"

    buildings = await get_buildings(user_id)
    if buildings.get("smithy", 0) < cfg["min_smithy"]:
        return False, f"Нужна Кузница ур. {cfg['min_smithy']}!"

    # Check rare ore costs from inventory
    cost = cfg.get("cost", {})
    rare_ores = await get_rare_ore_amounts(user_id)
    player = await get_player(user_id)

    for res, amount in cost.items():
        if res in {"iron_ore", "silver_ore", "gold_ore", "mithril"}:
            if rare_ores.get(res, 0) < amount:
                from config import RESOURCE_NAMES
                return False, f"Не хватает {RESOURCE_NAMES.get(res, res)}! Нужно: {amount} (есть: {rare_ores.get(res,0)})"
        elif player.get(res, 0) < amount:
            from config import RESOURCE_NAMES
            return False, f"Не хватает {RESOURCE_NAMES.get(res, res)}! Нужно: {amount}"

    async with aiosqlite.connect(DB_PATH) as db:
        for res, amount in cost.items():
            if res in {"iron_ore", "silver_ore", "gold_ore", "mithril"}:
                await db.execute(
                    "UPDATE inventory SET quantity=quantity-? WHERE user_id=? AND item_type=?",
                    (amount, user_id, res)
                )
            else:
                await db.execute(f"UPDATE players SET {res}={res}-? WHERE user_id=?", (amount, user_id))
        await db.execute("""
            INSERT INTO crafted_items (user_id, item_key, quantity) VALUES (?, ?, 1)
            ON CONFLICT(user_id, item_key) DO UPDATE SET quantity=quantity+1
        """, (user_id, item_key))
        await db.commit()

    return True, f"{cfg['emoji']} {cfg['name']} скрафчен!"


async def get_crafted_items_inventory(user_id: int) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT item_key, quantity FROM crafted_items WHERE user_id=? AND quantity > 0",
            (user_id,)
        )
        rows = await cur.fetchall()
        return [{"item_key": r[0], "quantity": r[1]} for r in rows]


async def get_crafted_equipment(user_id: int) -> str | None:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT item_key FROM equipped_crafted WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row or not row[0]:
            return None
        return row[0]


async def equip_crafted_item(user_id: int, item_key: str) -> tuple[bool, str]:
    items = await get_crafted_items_inventory(user_id)
    has_item = any(i["item_key"] == item_key for i in items)
    if not has_item:
        return False, "Этот предмет не скрафчен!"
    cfg = CRAFTABLE_ITEMS.get(item_key, {})
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO equipped_crafted (user_id, item_key) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET item_key=?
        """, (user_id, item_key, item_key))
        await db.commit()
    return True, f"{cfg.get('emoji','')} {cfg.get('name', item_key)} надет!"


# ─────────────────────────────────────────────────────────────────────────────
#  Market
# ─────────────────────────────────────────────────────────────────────────────

async def get_market_listings(exclude_user: Optional[int] = None) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        if exclude_user:
            cur = await db.execute("""
                SELECT * FROM market_listings
                WHERE is_active=1 AND seller_id != ?
                ORDER BY created_at DESC
            """, (exclude_user,))
        else:
            cur = await db.execute(
                "SELECT * FROM market_listings WHERE is_active=1 ORDER BY created_at DESC"
            )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def get_my_listings(user_id: int) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM market_listings WHERE seller_id=? AND is_active=1", (user_id,)
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def create_listing(seller_id: int, seller_name: str, resource: str, amount: float, price_per_unit: float) -> tuple[bool, str]:
    player = await get_player(seller_id)
    if not player:
        return False, "Игрок не найден"
    if player.get(resource, 0) < amount:
        return False, "Недостаточно ресурсов"
    my_listings = await get_my_listings(seller_id)
    buildings = await get_buildings(seller_id)
    market_level = buildings.get("market_building", 0)
    if market_level == 0:
        return False, "Нужно построить Рынок!"
    max_listings = market_level
    if len(my_listings) >= max_listings:
        return False, f"Максимум {max_listings} лотов (уровень Рынка: {market_level})"
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"UPDATE players SET {resource}={resource}-? WHERE user_id=?",
            (amount, seller_id)
        )
        await db.execute("""
            INSERT INTO market_listings (seller_id, seller_name, resource, amount, price_per_unit, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (seller_id, seller_name, resource, amount, price_per_unit, int(time.time())))
        await db.commit()
    return True, "Лот выставлен!"


async def buy_listing(buyer_id: int, listing_id: int) -> tuple[bool, str, Optional[dict]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM market_listings WHERE id=? AND is_active=1", (listing_id,))
        listing = await cur.fetchone()
        if not listing:
            return False, "Лот не найден или уже продан", None
        listing = dict(listing)

    if listing["seller_id"] == buyer_id:
        return False, "Нельзя купить свой лот", None

    buyer = await get_player(buyer_id)
    if not buyer:
        return False, "Покупатель не найден", None

    buildings_buyer = await get_buildings(buyer_id)
    market_level = buildings_buyer.get("market_building", 0)
    from config import get_market_fee
    fee_rate = get_market_fee(market_level)
    total_cost = listing["amount"] * listing["price_per_unit"]
    fee = total_cost * fee_rate
    if buyer["gold"] < total_cost:
        return False, f"Недостаточно золота! Нужно: 💰 {total_cost:.1f} (есть: {buyer['gold']:.1f})", None

    storage_buyer = buildings_buyer.get("storage", 0)
    max_res_buyer = BASE_STORAGE + storage_buyer * STORAGE_BONUS_PER_LEVEL
    resource = listing["resource"]
    if buyer.get(resource, 0) + listing["amount"] > max_res_buyer:
        return False, "Недостаточно места в хранилище!", None

    seller_receives = total_cost - fee
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE market_listings SET is_active=0 WHERE id=?", (listing_id,))
        await db.execute(
            f"UPDATE players SET gold=gold-?, {resource}={resource}+? WHERE user_id=?",
            (total_cost, listing["amount"], buyer_id)
        )
        await db.execute(
            "UPDATE players SET gold=gold+? WHERE user_id=?",
            (seller_receives, listing["seller_id"])
        )
        await db.commit()
    return True, f"Куплено {listing['amount']:.0f} ед. за 💰 {total_cost:.1f}!", listing


async def cancel_listing(user_id: int, listing_id: int) -> tuple[bool, str]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM market_listings WHERE id=? AND seller_id=? AND is_active=1",
            (listing_id, user_id)
        )
        listing = await cur.fetchone()
        if not listing:
            return False, "Лот не найден"
        listing = dict(listing)
        resource = listing["resource"]
        await db.execute("UPDATE market_listings SET is_active=0 WHERE id=?", (listing_id,))
        await db.execute(
            f"UPDATE players SET {resource}={resource}+? WHERE user_id=?",
            (listing["amount"], user_id)
        )
        await db.commit()
    return True, "Лот снят, ресурсы возвращены"


# ─────────────────────────────────────────────────────────────────────────────
#  Bans
# ─────────────────────────────────────────────────────────────────────────────

async def ban_player(user_id: int, banned_by: int, reason: str, duration: int) -> bool:
    now = int(time.time())
    ban_until = -1 if duration == -1 else now + duration
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE players SET is_banned=1, ban_until=?, ban_reason=? WHERE user_id=?",
            (ban_until, reason, user_id)
        )
        await db.execute("""
            INSERT INTO ban_log (user_id, banned_by, reason, ban_until, banned_at)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, banned_by, reason, ban_until, now))
        await db.commit()
    return True


async def unban_player(user_id: int) -> bool:
    now = int(time.time())
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE players SET is_banned=0, ban_until=0, ban_reason='' WHERE user_id=?",
            (user_id,)
        )
        await db.execute(
            "UPDATE ban_log SET unbanned_at=? WHERE user_id=? AND unbanned_at=0",
            (now, user_id)
        )
        await db.commit()
    return True


async def check_ban(user_id: int) -> tuple[bool, str]:
    player = await get_player(user_id)
    if not player:
        return False, ""
    if not player["is_banned"]:
        return False, ""
    ban_until = player["ban_until"]
    now = int(time.time())
    if ban_until != -1 and now >= ban_until:
        await unban_player(user_id)
        return False, ""
    if ban_until == -1:
        return True, f"Навсегда. Причина: {player['ban_reason']}"
    remaining = ban_until - now
    h = remaining // 3600
    m = (remaining % 3600) // 60
    return True, f"До: {h}ч {m}мин. Причина: {player['ban_reason']}"


async def get_all_players(limit: int = 50) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM players ORDER BY created_at DESC LIMIT ?", (limit,)
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def give_resources(user_id: int, resource: str, amount: float):
    allowed = {"wood", "ore", "stone", "food", "gold"}
    if resource not in allowed:
        return
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"UPDATE players SET {resource}={resource}+? WHERE user_id=?",
            (amount, user_id)
        )
        await db.commit()


async def reset_all_players():
    now = int(time.time())
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            UPDATE players SET
                wood=?, ore=?, stone=?, food=?, gold=?,
                last_collected=?
        """, (
            START_RESOURCES["wood"], START_RESOURCES["ore"],
            START_RESOURCES["stone"], START_RESOURCES["food"],
            START_RESOURCES["gold"], now
        ))
        for key, cfg in BUILDINGS_CONFIG.items():
            if cfg.get("hidden", False):
                continue
            start_level = cfg.get("start_level", 0)
            await db.execute(
                "UPDATE buildings SET level=? WHERE building_key=?",
                (start_level, key)
            )
        await db.commit()


async def get_stats() -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT COUNT(*) FROM players")
        total = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM players WHERE is_banned=1")
        banned = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM market_listings WHERE is_active=1")
        listings = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM referrals")
        refs = (await cur.fetchone())[0]
    return {"total_players": total, "banned": banned, "active_listings": listings, "referrals": refs}


# ─────────────────────────────────────────────────────────────────────────────
#  Army
# ─────────────────────────────────────────────────────────────────────────────

def calculate_army_power(army: dict, eq_tier: int, crafted_item: str | None = None) -> int:
    from config import UNITS_CONFIG, EQUIPMENT_TIERS, CRAFTABLE_ITEMS
    total = 0
    for unit_type, count in army.items():
        ucfg = UNITS_CONFIG.get(unit_type, {})
        total += (ucfg.get("attack", 0) + ucfg.get("defense", 0)) * count

    bonus = EQUIPMENT_TIERS.get(eq_tier, {}).get("attack_bonus", 0.0)
    result = int(total * (1 + bonus))

    # Add crafted item bonus
    if crafted_item and crafted_item in CRAFTABLE_ITEMS:
        ccfg = CRAFTABLE_ITEMS[crafted_item]
        crafted_bonus = ccfg.get("attack_bonus", 0) + ccfg.get("defense_bonus", 0) * 0.5
        result = int(result * (1 + crafted_bonus))

    return result


async def get_army(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT unit_type, count FROM army WHERE user_id=?", (user_id,))
        rows = await cur.fetchall()
        return {r[0]: r[1] for r in rows}


async def hire_units(user_id: int, unit_type: str, count: int) -> tuple[bool, str]:
    from config import UNITS_CONFIG
    ucfg = UNITS_CONFIG.get(unit_type)
    if not ucfg:
        return False, "Неизвестный тип воина"

    player = await get_player(user_id)
    if not player:
        return False, "Игрок не найден"
    buildings = await get_buildings(user_id)
    barracks_level = buildings.get("barracks", 0)
    if barracks_level == 0:
        return False, "Нужно построить Казарму!"

    max_units = barracks_level * 5
    army = await get_army(user_id)
    total_units = sum(army.values())
    if total_units + count > max_units:
        count = max_units - total_units
        if count <= 0:
            return False, f"Казармы переполнены! Максимум: {max_units}"

    cost = ucfg["cost_gold"] * count
    if player.get("gold", 0) < cost:
        return False, f"Недостаточно золота! Нужно 💰{cost:.0f} (есть {player.get('gold', 0):.0f})"

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE players SET gold=gold-? WHERE user_id=?", (cost, user_id))
        await db.execute("""
            INSERT INTO army (user_id, unit_type, count) VALUES (?, ?, ?)
            ON CONFLICT(user_id, unit_type) DO UPDATE SET count=count+?
        """, (user_id, unit_type, count, count))
        await db.commit()
    return True, f"Нанято {count} {ucfg['emoji']} {ucfg['name']} за 💰{cost:.0f}"


async def fire_units(user_id: int, unit_type: str, count: int) -> tuple[bool, str]:
    from config import UNITS_CONFIG
    ucfg = UNITS_CONFIG.get(unit_type, {})
    army = await get_army(user_id)
    have = army.get(unit_type, 0)
    if have < count:
        return False, f"Нет столько воинов! Есть: {have}"
    new_count = have - count
    async with aiosqlite.connect(DB_PATH) as db:
        if new_count == 0:
            await db.execute("DELETE FROM army WHERE user_id=? AND unit_type=?", (user_id, unit_type))
        else:
            await db.execute("UPDATE army SET count=? WHERE user_id=? AND unit_type=?", (new_count, user_id, unit_type))
        await db.commit()
    return True, f"Распущено {count} {ucfg.get('emoji','')} {ucfg.get('name', unit_type)}"


# ─────────────────────────────────────────────────────────────────────────────
#  Equipment
# ─────────────────────────────────────────────────────────────────────────────

async def get_equipment_tier(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT tier FROM equipment WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return row[0] if row else 0


async def get_owned_equipment_tiers(user_id: int) -> list[int]:
    import json
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT tier, owned_tiers FROM equipment WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row:
            return []
        current_tier = row[0]
        try:
            owned = json.loads(row[1] or "[]")
        except Exception:
            owned = []
        if current_tier not in owned:
            owned.append(current_tier)
        return sorted(set(owned))


async def equip_tier(user_id: int, tier: int) -> tuple[bool, str]:
    owned = await get_owned_equipment_tiers(user_id)
    if tier not in owned:
        return False, "Это снаряжение не создано!"
    from config import EQUIPMENT_TIERS
    eq = EQUIPMENT_TIERS.get(tier, {})
    import json
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO equipment (user_id, tier, owned_tiers) VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET tier=?
        """, (user_id, tier, json.dumps(owned), tier))
        await db.commit()
    return True, f"Надето {eq.get('emoji','')} {eq.get('name','')}!"


async def get_smithy_cooldown(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT last_craft FROM smithy_cooldowns WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return row[0] if row else 0


async def upgrade_equipment(user_id: int) -> tuple[bool, str]:
    import json
    from config import EQUIPMENT_TIERS, RESOURCE_NAMES
    current_tier = await get_equipment_tier(user_id)
    next_tier = current_tier + 1
    if next_tier not in EQUIPMENT_TIERS:
        return False, "Уже максимальное снаряжение!"
    tier_cfg = EQUIPMENT_TIERS[next_tier]

    buildings = await get_buildings(user_id)
    if buildings.get("smithy", 0) < tier_cfg.get("min_smithy", 0):
        return False, f"Нужна Кузница ур. {tier_cfg['min_smithy']}!"

    last_craft = await get_smithy_cooldown(user_id)
    now = int(time.time())
    if now - last_craft < 3600:
        remaining = 3600 - (now - last_craft)
        m, s = remaining // 60, remaining % 60
        return False, f"Кузница занята! Ждите {m} мин {s} сек."

    req_frags = tier_cfg.get("fragments", 0)
    if req_frags > 0:
        frags = await get_inventory_item(user_id, "fragment")
        if frags < req_frags:
            return False, f"Нужно фрагментов: {req_frags} (есть: {frags})"

    player = await get_player(user_id)
    cost = tier_cfg.get("cost", {})
    for res, amount in cost.items():
        if player.get(res, 0) < amount:
            return False, f"Недостаточно {RESOURCE_NAMES.get(res, res)}! Нужно: {amount:.0f}"

    owned = await get_owned_equipment_tiers(user_id)
    if next_tier not in owned:
        owned.append(next_tier)
    owned_json = json.dumps(sorted(set(owned)))

    async with aiosqlite.connect(DB_PATH) as db:
        for res, amount in cost.items():
            if res in ["wood", "ore", "stone", "food", "gold"]:
                await db.execute(f"UPDATE players SET {res}={res}-? WHERE user_id=?", (amount, user_id))
        if req_frags > 0:
            await db.execute(
                "UPDATE inventory SET quantity=quantity-? WHERE user_id=? AND item_type='fragment'",
                (req_frags, user_id)
            )
        await db.execute("""
            INSERT INTO equipment (user_id, tier, owned_tiers) VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET tier=?, owned_tiers=?
        """, (user_id, next_tier, owned_json, next_tier, owned_json))
        await db.execute("""
            INSERT INTO smithy_cooldowns (user_id, last_craft) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET last_craft=?
        """, (user_id, now, now))
        await db.commit()
    return True, f"Снаряжение улучшено до {tier_cfg['emoji']} {tier_cfg['name']}!"


# ─────────────────────────────────────────────────────────────────────────────
#  Inventory helpers
# ─────────────────────────────────────────────────────────────────────────────

async def get_inventory_item(user_id: int, item_type: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT quantity FROM inventory WHERE user_id=? AND item_type=?", (user_id, item_type)
        )
        row = await cur.fetchone()
        return row[0] if row else 0


async def add_inventory_item(user_id: int, item_type: str, amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO inventory (user_id, item_type, quantity) VALUES (?, ?, ?)
            ON CONFLICT(user_id, item_type) DO UPDATE SET quantity=quantity+?
        """, (user_id, item_type, amount, amount))
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
#  Daily Quests
# ─────────────────────────────────────────────────────────────────────────────

async def get_or_create_daily_quests(user_id: int, th_level: int) -> list[dict]:
    import hashlib
    from datetime import date
    from config import QUEST_POOL
    today = date.today().isoformat()

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM daily_quests WHERE user_id=? AND quest_date=? ORDER BY quest_index",
            (user_id, today)
        )
        rows = await cur.fetchall()
        if rows:
            return [dict(r) for r in rows]

    scale = max(1, th_level)
    seed = int(hashlib.md5(f"{user_id}{today}".encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)
    available = [
        {**q, "target": q["scale"] * scale, "reward_amount": q["reward_scale"] * scale}
        for q in QUEST_POOL
    ]
    selected = rng.sample(available, min(3, len(available)))

    result = []
    async with aiosqlite.connect(DB_PATH) as db:
        for i, q in enumerate(selected):
            await db.execute("""
                INSERT OR IGNORE INTO daily_quests
                (user_id, quest_date, quest_index, quest_type, quest_name, target, progress, completed, reward_resource, reward_amount, reward_claimed)
                VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, ?, 0)
            """, (user_id, today, i, q["type"], q["name"], q["target"], q["reward"], q["reward_amount"]))
            result.append({
                "user_id": user_id, "quest_date": today, "quest_index": i,
                "quest_type": q["type"], "quest_name": q["name"],
                "target": q["target"], "progress": 0, "completed": 0,
                "reward_resource": q["reward"], "reward_amount": q["reward_amount"],
                "reward_claimed": 0,
            })
        await db.commit()
    return result


async def update_quest_progress(user_id: int, quest_type: str, delta: int = 1):
    from datetime import date
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT quest_index, progress, target FROM daily_quests WHERE user_id=? AND quest_date=? AND quest_type=? AND completed=0",
            (user_id, today, quest_type)
        )
        row = await cur.fetchone()
        if not row:
            return
        idx, progress, target = row
        new_progress = min(progress + delta, target)
        completed = 1 if new_progress >= target else 0
        await db.execute(
            "UPDATE daily_quests SET progress=?, completed=? WHERE user_id=? AND quest_date=? AND quest_index=?",
            (new_progress, completed, user_id, today, idx)
        )
        await db.commit()


async def update_quest_progress_stat(user_id: int, quest_date: str, quest_index: int, new_progress: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT target, reward_claimed FROM daily_quests WHERE user_id=? AND quest_date=? AND quest_index=?",
            (user_id, quest_date, quest_index)
        )
        row = await cur.fetchone()
        if not row:
            return
        target, claimed = row
        completed = 1 if new_progress >= target else 0
        await db.execute(
            "UPDATE daily_quests SET progress=?, completed=? WHERE user_id=? AND quest_date=? AND quest_index=?",
            (new_progress, completed, user_id, quest_date, quest_index)
        )
        await db.commit()


async def claim_quest_reward(user_id: int, quest_index: int) -> tuple[bool, str, dict]:
    from datetime import date
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM daily_quests WHERE user_id=? AND quest_date=? AND quest_index=?",
            (user_id, today, quest_index)
        )
        row = await cur.fetchone()
        if not row:
            return False, "Задание не найдено", {}
        quest = dict(row)
    if not quest["completed"]:
        return False, "Задание ещё не выполнено", {}
    if quest.get("reward_claimed"):
        return False, "Награда уже получена", {}
    res = quest["reward_resource"]
    amount = quest["reward_amount"]
    async with aiosqlite.connect(DB_PATH) as db:
        if res in ["wood", "ore", "stone", "food", "gold"]:
            await db.execute(f"UPDATE players SET {res}={res}+? WHERE user_id=?", (amount, user_id))
        await db.execute(
            "UPDATE daily_quests SET reward_claimed=1 WHERE user_id=? AND quest_date=? AND quest_index=?",
            (user_id, today, quest_index)
        )
        await db.commit()
    return True, "Награда получена!", {"resource": res, "amount": amount}


# ─────────────────────────────────────────────────────────────────────────────
#  Dungeons
# ─────────────────────────────────────────────────────────────────────────────

async def get_dungeon_cooldown(user_id: int, dungeon_id: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT last_raid FROM dungeon_cooldowns WHERE user_id=? AND dungeon_id=?",
            (user_id, dungeon_id)
        )
        row = await cur.fetchone()
        return row[0] if row else 0


async def do_dungeon_raid(user_id: int, dungeon_id: str) -> tuple[bool, str, dict]:
    from config import DUNGEONS, DUNGEON_LOOT, UNITS_CONFIG

    dungeon = next((d for d in DUNGEONS if d["id"] == dungeon_id), None)
    if not dungeon:
        return False, "Подземелье не найдено", {}

    last_raid = await get_dungeon_cooldown(user_id, dungeon_id)
    now = int(time.time())
    if now - last_raid < dungeon["cooldown"]:
        remaining = dungeon["cooldown"] - (now - last_raid)
        h, m = remaining // 3600, (remaining % 3600) // 60
        return False, f"Рейд на кулдауне. Подождите {h}ч {m}мин", {}

    army = await get_army(user_id)
    eq_tier = await get_equipment_tier(user_id)
    crafted = await get_crafted_equipment(user_id)
    army_power = calculate_army_power(army, eq_tier, crafted)

    if army_power < dungeon["min_power"]:
        return False, f"Армия слишком слабая! Нужно силы: {dungeon['min_power']} (у вас: {army_power})", {}

    boss_power = dungeon["boss_power"]
    eff_attack = int(army_power * random.uniform(0.80, 1.30))
    eff_boss = int(boss_power * random.uniform(0.80, 1.30))
    won = eff_attack >= eff_boss

    loot: dict = {}
    loot_table = DUNGEON_LOOT[dungeon["loot_tier"]]
    mult = 1.0 if won else 0.35

    for res, val in loot_table.items():
        if res in ("frag_chance", "frag_count"):
            continue
        lo, hi = val
        amount = random.randint(int(lo * mult), max(int(hi * mult), int(lo * mult)))
        if amount > 0:
            loot[res] = amount

    frags_gained = 0
    frag_chance = loot_table.get("frag_chance", 0) * mult
    if random.random() < frag_chance:
        frag_count = loot_table.get("frag_count", (1, 3))
        frags_gained = random.randint(*frag_count)

    loss_ratio = max(0.0, min(0.25, (eff_boss / max(1, eff_attack)) * 0.25)) if won else random.uniform(0.20, 0.45)

    units_lost: dict = {}
    async with aiosqlite.connect(DB_PATH) as db:
        for unit_type, count in army.items():
            if count > 0:
                lost = max(0, int(count * loss_ratio))
                if lost > 0:
                    units_lost[unit_type] = lost
                    new_count = count - lost
                    if new_count == 0:
                        await db.execute("DELETE FROM army WHERE user_id=? AND unit_type=?", (user_id, unit_type))
                    else:
                        await db.execute("UPDATE army SET count=? WHERE user_id=? AND unit_type=?", (new_count, user_id, unit_type))
        for res, amount in loot.items():
            if res in ["wood", "ore", "stone", "food", "gold"]:
                await db.execute(f"UPDATE players SET {res}={res}+? WHERE user_id=?", (amount, user_id))
        if frags_gained > 0:
            await db.execute("""
                INSERT INTO inventory (user_id, item_type, quantity) VALUES (?, 'fragment', ?)
                ON CONFLICT(user_id, item_type) DO UPDATE SET quantity=quantity+?
            """, (user_id, frags_gained, frags_gained))
        await db.execute("""
            INSERT INTO dungeon_cooldowns (user_id, dungeon_id, last_raid) VALUES (?, ?, ?)
            ON CONFLICT(user_id, dungeon_id) DO UPDATE SET last_raid=?
        """, (user_id, dungeon_id, now, now))
        await db.commit()

    result = {
        "won": won, "loot": loot, "frags_gained": frags_gained,
        "units_lost": units_lost, "army_power": army_power, "boss_power": boss_power,
    }
    return True, "OK", result


# ─────────────────────────────────────────────────────────────────────────────
#  War
# ─────────────────────────────────────────────────────────────────────────────

async def get_war_cooldown(user_id: int) -> tuple[int, int]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT last_attack, shield_until FROM war_cooldowns WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return (row[0], row[1]) if row else (0, 0)


async def get_attack_targets(user_id: int, limit: int = 6) -> list[dict]:
    buildings = await get_buildings(user_id)
    my_total = sum(buildings.values())
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT p.user_id, p.first_name, p.username,
                   COALESCE(SUM(b.level), 0) as total_levels,
                   (p.wood + p.ore + p.stone + p.food + p.gold) as total_resources,
                   COALESCE((SELECT shield_until FROM war_cooldowns wc WHERE wc.user_id=p.user_id), 0) as shield_until
            FROM players p
            LEFT JOIN buildings b ON p.user_id = b.user_id
            WHERE p.is_banned=0 AND p.user_id != ?
            GROUP BY p.user_id
            ORDER BY ABS(COALESCE(SUM(b.level), 0) - ?) ASC
            LIMIT ?
        """, (user_id, my_total, limit))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def do_war_attack(attacker_id: int, defender_id: int) -> tuple[bool, str, dict]:
    WAR_ATCK_CD = 6 * 3600
    SHIELD_DUR = 2 * 3600

    last_atk, _ = await get_war_cooldown(attacker_id)
    now = int(time.time())
    if now - last_atk < WAR_ATCK_CD:
        remaining = WAR_ATCK_CD - (now - last_atk)
        h, m = remaining // 3600, (remaining % 3600) // 60
        return False, f"Атака на кулдауне {h}ч {m}мин", {}

    _, shield_until = await get_war_cooldown(defender_id)
    if now < shield_until:
        remaining = shield_until - now
        h, m = remaining // 3600, (remaining % 3600) // 60
        return False, f"Этот игрок под щитом ещё {h}ч {m}мин", {}

    att_army = await get_army(attacker_id)
    def_army = await get_army(defender_id)
    att_eq = await get_equipment_tier(attacker_id)
    def_eq = await get_equipment_tier(defender_id)
    att_crafted = await get_crafted_equipment(attacker_id)
    def_crafted = await get_crafted_equipment(defender_id)
    att_power = calculate_army_power(att_army, att_eq, att_crafted)
    def_power = calculate_army_power(def_army, def_eq, def_crafted)

    if att_power == 0:
        return False, "Нет армии для атаки! Нанимай воинов в Казарме.", {}

    eff_att = int(att_power * random.uniform(0.75, 1.25))
    eff_def = int(max(50, def_power) * random.uniform(0.75, 1.25))
    won = eff_att > eff_def

    stolen: dict = {}
    if won:
        defender = await get_player(defender_id)
        if defender:
            steal_ratio = random.uniform(0.05, 0.20)
            for res in ["wood", "ore", "stone", "gold"]:
                amount = int(defender.get(res, 0) * steal_ratio)
                if amount > 0:
                    stolen[res] = amount
            async with aiosqlite.connect(DB_PATH) as db:
                for res, amount in stolen.items():
                    await db.execute(f"UPDATE players SET {res}={res}-? WHERE user_id=?", (amount, defender_id))
                    await db.execute(f"UPDATE players SET {res}={res}+? WHERE user_id=?", (amount, attacker_id))
                await db.commit()

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO war_cooldowns (user_id, last_attack) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET last_attack=?
        """, (attacker_id, now, now))
        await db.execute("""
            INSERT INTO war_cooldowns (user_id, shield_until) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET shield_until=?
        """, (defender_id, now + SHIELD_DUR, now + SHIELD_DUR))
        await db.execute("""
            INSERT INTO war_log (attacker_id, defender_id, attacker_power, defender_power, won, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (attacker_id, defender_id, att_power, def_power, int(won), now))
        await db.commit()

    return True, "OK", {
        "won": won, "stolen": stolen,
        "attacker_power": att_power, "defender_power": def_power
    }


# ─────────────────────────────────────────────────────────────────────────────
#  Trader
# ─────────────────────────────────────────────────────────────────────────────

def get_active_trader_trades() -> list[dict]:
    from datetime import datetime
    from config import TRADER_POOL
    hour_key = datetime.now().strftime("%Y-%m-%d-%H")
    rng = random.Random(hash(hour_key))
    return rng.sample(TRADER_POOL, min(4, len(TRADER_POOL)))


async def has_bought_trade(user_id: int, trade_id: str) -> bool:
    from datetime import datetime
    hour_key = datetime.now().strftime("%Y-%m-%d-%H")
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT 1 FROM trader_purchases WHERE user_id=? AND trade_id=? AND hour_key=?",
            (user_id, trade_id, hour_key)
        )
        return await cur.fetchone() is not None


async def buy_from_trader(user_id: int, trade_id: str) -> tuple[bool, str]:
    from datetime import datetime
    from config import TRADER_POOL, get_trader_bonus
    hour_key = datetime.now().strftime("%Y-%m-%d-%H")

    if await has_bought_trade(user_id, trade_id):
        return False, "Эту сделку уже купили в этот час!"

    trade = next((t for t in TRADER_POOL if t["id"] == trade_id), None)
    if not trade:
        return False, "Сделка не найдена"

    player = await get_player(user_id)
    buildings = await get_buildings(user_id)
    market_level = buildings.get("market_building", 0)
    bonus = get_trader_bonus(market_level)

    give_res = trade["give_res"]
    give_amt = trade["give_amt"]
    get_res = trade["get_res"]
    get_amt = int(trade["get_amt"] * bonus)

    if player.get(give_res, 0) < give_amt:
        from config import RESOURCE_NAMES
        return False, f"Недостаточно {RESOURCE_NAMES.get(give_res, give_res)}!"

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE players SET {give_res}={give_res}-? WHERE user_id=?", (give_amt, user_id))
        await db.execute(f"UPDATE players SET {get_res}={get_res}+? WHERE user_id=?", (get_amt, user_id))
        await db.execute(
            "INSERT OR IGNORE INTO trader_purchases (user_id, trade_id, hour_key) VALUES (?, ?, ?)",
            (user_id, trade_id, hour_key)
        )
        await db.commit()

    from config import RESOURCE_EMOJIS
    return True, f"Обменяно! Получено {RESOURCE_EMOJIS.get(get_res,'')} {get_amt}"
