import time
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from database import (get_army, get_equipment_tier, get_attack_targets,
                      do_war_attack, calculate_army_power, get_war_cooldown,
                      get_crafted_equipment)
from keyboards.menus import war_menu_kb, war_targets_kb, war_confirm_kb
from config import RESOURCE_EMOJIS, RESOURCE_NAMES, UNITS_CONFIG

router = Router()

WAR_COOLDOWN = 6 * 3600
SEP = "──────────────────────"


def _war_text(army_power: int, last_attack: int, shield_until: int) -> str:
    now = int(time.time())
    attack_cd = WAR_COOLDOWN - (now - last_attack)
    shield_cd = shield_until - now

    if attack_cd > 0:
        h, m = attack_cd // 3600, (attack_cd % 3600) // 60
        atk_status = f"Атака через: {h}ч {m}мин"
    else:
        atk_status = "Атака доступна!"

    shield_line = ""
    if shield_cd > 0:
        h, m = shield_cd // 3600, (shield_cd % 3600) // 60
        shield_line = f"\n🛡️ Щит активен: {h}ч {m}мин"

    return (
        f"Битва деревень\n"
        f"{SEP}\n\n"
        f"Сила твоей армии: {army_power}\n"
        f"{atk_status}{shield_line}\n\n"
        f"<blockquote>Правила:\n"
        f"└Атака: кд 6ч\n"
        f"└Щит защиты: 2ч\n"
        f"└Победитель забирает 5-20% ресурсов</blockquote>\n\n"
        f"Выберите действие:"
    )


@router.message(Command("war"))
async def cmd_war(message: Message):
    army = await get_army(message.from_user.id)
    eq_tier = await get_equipment_tier(message.from_user.id)
    crafted = await get_crafted_equipment(message.from_user.id)
    power = calculate_army_power(army, eq_tier, crafted)
    last_atk, shield_until = await get_war_cooldown(message.from_user.id)
    await message.answer(_war_text(power, last_atk, shield_until), reply_markup=war_menu_kb())


@router.callback_query(F.data == "war")
async def cb_war(callback: CallbackQuery):
    army = await get_army(callback.from_user.id)
    eq_tier = await get_equipment_tier(callback.from_user.id)
    crafted = await get_crafted_equipment(callback.from_user.id)
    power = calculate_army_power(army, eq_tier, crafted)
    last_atk, shield_until = await get_war_cooldown(callback.from_user.id)
    text = _war_text(power, last_atk, shield_until)
    try:
        await callback.message.edit_text(text, reply_markup=war_menu_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=war_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "war_find_targets")
async def cb_war_find_targets(callback: CallbackQuery):
    last_atk, _ = await get_war_cooldown(callback.from_user.id)
    now = int(time.time())
    if now - last_atk < WAR_COOLDOWN:
        remaining = WAR_COOLDOWN - (now - last_atk)
        h, m = remaining // 3600, (remaining % 3600) // 60
        await callback.answer(f"⏳ Кулдаун: {h}ч {m}мин", show_alert=True)
        return

    army = await get_army(callback.from_user.id)
    if not any(v > 0 for v in army.values()):
        await callback.answer("❌ Нет армии! Нанимай воинов в Казарме.", show_alert=True)
        return

    targets = await get_attack_targets(callback.from_user.id)
    if not targets:
        await callback.answer("❌ Нет доступных противников", show_alert=True)
        return

    text = f"Выбери цель:\n{SEP}\n\n"
    for t in targets:
        name = t.get("first_name", "Игрок")
        lvls = t.get("total_levels", 0)
        shield = t.get("shield_until", 0)
        shield_mark = " 🛡️" if shield > now else ""
        text += f"» {name}  — ур.{lvls}{shield_mark}\n"

    try:
        await callback.message.edit_text(text, reply_markup=war_targets_kb(targets))
    except Exception:
        await callback.message.answer(text, reply_markup=war_targets_kb(targets))
    await callback.answer()


@router.callback_query(F.data.startswith("war_confirm_"))
async def cb_war_confirm(callback: CallbackQuery):
    defender_id = int(callback.data.replace("war_confirm_", ""))
    from database import get_player
    defender = await get_player(defender_id)
    if not defender:
        await callback.answer("❌ Игрок не найден", show_alert=True)
        return

    army = await get_army(callback.from_user.id)
    eq_tier = await get_equipment_tier(callback.from_user.id)
    crafted = await get_crafted_equipment(callback.from_user.id)
    att_power = calculate_army_power(army, eq_tier, crafted)
    defender_name = defender.get("first_name", "Игрок")

    text = (
        f"Подтверждение атаки\n"
        f"{SEP}\n\n"
        f"Цель: {defender_name}\n"
        f"Твоя сила: {att_power}\n\n"
        f"<blockquote>⚠️ Обе стороны понесут потери!</blockquote>\n\n"
        f"Выберите действие:"
    )
    try:
        await callback.message.edit_text(text, reply_markup=war_confirm_kb(defender_id))
    except Exception:
        await callback.message.answer(text, reply_markup=war_confirm_kb(defender_id))
    await callback.answer()


@router.callback_query(F.data.startswith("war_attack_"))
async def cb_war_attack(callback: CallbackQuery):
    defender_id = int(callback.data.replace("war_attack_", ""))
    await callback.answer("⚔️ Атака!")

    success, msg, result = await do_war_attack(callback.from_user.id, defender_id)
    if not success:
        try:
            await callback.message.edit_text(f"❌ {msg}", reply_markup=war_menu_kb())
        except Exception:
            await callback.message.answer(f"❌ {msg}", reply_markup=war_menu_kb())
        return

    won = result["won"]
    stolen = result.get("stolen", {})
    att_power = result["attacker_power"]
    def_power = result["defender_power"]

    outcome = "🏆 ПОБЕДА! Деревня разграблена!" if won else "💀 ПОРАЖЕНИЕ. Защита устояла."
    stolen_lines = [
        f"   └ {RESOURCE_EMOJIS[r]} {RESOURCE_NAMES[r]}: +{v}"
        for r, v in stolen.items()
    ]
    stolen_text = ("\n» Захвачено:\n" + "\n".join(stolen_lines)) if stolen_lines else "\nРесурсы не захвачены."

    text = (
        f"Результат битвы\n"
        f"{SEP}\n\n"
        f"{outcome}\n"
        f"Твоя сила: {att_power} vs Защита: {def_power}"
        + stolen_text
        + "\n\n⏳ Следующая атака через 6 часов"
    )

    from database import get_player, log_action
    defender = await get_player(defender_id)
    if defender:
        try:
            res_text = "\n".join(f"{RESOURCE_EMOJIS[r]} -{v}" for r, v in stolen.items()) if stolen else "Ресурсы не украдены."
            await callback.bot.send_message(
                defender_id,
                f"⚔️ <b>Ваша деревня атакована!</b>\n\n"
                f"{'Нападение отражено!' if not won else 'Нас разграбили!'}\n"
                f"{res_text}\n\n🛡️ Щит защиты активен 2 часа.",
                parse_mode="HTML"
            )
        except Exception:
            pass

    await log_action(callback.from_user.id, f"⚔️ {'Победа' if won else 'Поражение'} против {defender.get('first_name','?') if defender else '?'}")

    try:
        await callback.message.edit_text(text, reply_markup=war_menu_kb())
    except Exception:
        await callback.message.answer(text, reply_markup=war_menu_kb())
