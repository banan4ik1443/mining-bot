from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from database import (get_player, get_buildings, get_smithy_cooldown, craft_item,
                      get_crafted_items_inventory, equip_crafted_item, get_crafted_equipment,
                      get_equipment_tier)
from keyboards.menus import crafting_menu_kb, craft_item_kb, crafted_inventory_kb
from config import CRAFTABLE_ITEMS, RESOURCE_EMOJIS, RESOURCE_NAMES, EQUIPMENT_TIERS

router = Router()


def _craft_item_text(item_key: str, cfg: dict, player: dict, buildings: dict) -> tuple[str, bool]:
    smithy_level = buildings.get("smithy", 0)
    min_smithy = cfg["min_smithy"]
    can_craft = True

    cost = cfg.get("cost", {})
    parts = []
    for res, amount in cost.items():
        have = player.get(res, 0)
        ok = have >= amount
        if not ok:
            can_craft = False
        mark = "✅" if ok else "❌"
        emoji = RESOURCE_EMOJIS.get(res, "?")
        name = RESOURCE_NAMES.get(res, res)
        parts.append(f"  {mark} {emoji} {name}: {amount} (есть: {int(have)})")

    if smithy_level < min_smithy:
        can_craft = False

    slot_text = {"weapon": "⚔️ Оружие", "armor": "🛡️ Броня"}.get(cfg.get("slot", ""), "предмет")
    bonus_parts = []
    if cfg.get("attack_bonus", 0) > 0:
        bonus_parts.append(f"⚔️ +{int(cfg['attack_bonus']*100)}% к атаке")
    if cfg.get("defense_bonus", 0) > 0:
        bonus_parts.append(f"🛡️ +{int(cfg['defense_bonus']*100)}% к защите")

    text = (
        f"{cfg['emoji']} <b>{cfg['name']}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"Тип: {slot_text}\n"
        f"Бонусы: {', '.join(bonus_parts) if bonus_parts else '—'}\n"
        f"Нужна Кузница: ур. <b>{min_smithy}</b> (сейчас: {smithy_level})\n\n"
        f"💰 <b>Стоимость крафта:</b>\n"
        + "\n".join(parts)
    )

    if smithy_level < min_smithy:
        text += f"\n\n❌ Нужна Кузница ур. {min_smithy}!"
    elif not can_craft:
        text += f"\n\n❌ Не хватает ресурсов!"
    else:
        text += f"\n\n✅ Готово к крафту!"

    return text, can_craft and smithy_level >= min_smithy


@router.callback_query(F.data == "crafting_menu")
async def cb_crafting_menu(callback: CallbackQuery):
    buildings = await get_buildings(callback.from_user.id)
    smithy_level = buildings.get("smithy", 0)

    if smithy_level == 0:
        await callback.answer("❌ Нужно построить Кузницу!", show_alert=True)
        return

    available = [k for k, v in CRAFTABLE_ITEMS.items() if smithy_level >= v["min_smithy"]]
    text = (
        f"⚒️ <b>Крафт предметов</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔨 Кузница: ур. <b>{smithy_level}</b>\n"
        f"📋 Доступно рецептов: <b>{len(available)}</b>\n\n"
        f"Крафти предметы из редких руд (получаешь в Шахте).\n"
        f"Надень лучшее снаряжение — увеличь силу армии!"
    )
    try:
        await callback.message.edit_text(text, reply_markup=crafting_menu_kb(smithy_level))
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=crafting_menu_kb(smithy_level))
    await callback.answer()


@router.callback_query(F.data.startswith("craft_"))
async def cb_craft_info(callback: CallbackQuery):
    item_key = callback.data.replace("craft_", "")
    cfg = CRAFTABLE_ITEMS.get(item_key)
    if not cfg:
        await callback.answer("❌ Предмет не найден", show_alert=True)
        return

    player = await get_player(callback.from_user.id)
    buildings = await get_buildings(callback.from_user.id)
    text, can_craft = _craft_item_text(item_key, cfg, player, buildings)

    try:
        await callback.message.edit_text(text, reply_markup=craft_item_kb(item_key, can_craft))
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=craft_item_kb(item_key, can_craft))
    await callback.answer()


@router.callback_query(F.data.startswith("do_craft_"))
async def cb_do_craft(callback: CallbackQuery):
    item_key = callback.data.replace("do_craft_", "")
    success, msg = await craft_item(callback.from_user.id, item_key)
    await callback.answer(f"{'✅' if success else '❌'} {msg}", show_alert=True)
    if success:
        from database import log_action
        cfg = CRAFTABLE_ITEMS.get(item_key, {})
        await log_action(callback.from_user.id, f"⚒️ Скрафтен {cfg.get('emoji','')} {cfg.get('name', item_key)}")
        await cb_crafting_menu(callback)


@router.callback_query(F.data == "crafted_inventory")
async def cb_crafted_inventory(callback: CallbackQuery):
    items = await get_crafted_items_inventory(callback.from_user.id)
    equipped = await get_crafted_equipment(callback.from_user.id)

    if not items:
        text = (
            "🎒 <b>Моё снаряжение</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "<i>Ничего не скрафчено. Добудь редкие руды в Шахте!</i>"
        )
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        b = InlineKeyboardBuilder()
        b.button(text="🔙 Крафт", callback_data="crafting_menu")
        b.adjust(1)
        try:
            await callback.message.edit_text(text, reply_markup=b.as_markup())
        except Exception:
            pass
    else:
        text = (
            "🎒 <b>Моё снаряжение</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Нажми на предмет чтобы надеть:\n"
        )
        for item in items:
            key = item["item_key"]
            cfg = CRAFTABLE_ITEMS.get(key, {})
            is_eq = key == equipped
            mark = "✅ " if is_eq else "  "
            bonuses = []
            if cfg.get("attack_bonus", 0) > 0:
                bonuses.append(f"+{int(cfg['attack_bonus']*100)}% атк")
            if cfg.get("defense_bonus", 0) > 0:
                bonuses.append(f"+{int(cfg['defense_bonus']*100)}% защ")
            bonus_str = f" ({', '.join(bonuses)})" if bonuses else ""
            text += f"{mark}{cfg.get('emoji','')} {cfg.get('name', key)}{bonus_str}\n"
        try:
            await callback.message.edit_text(text, reply_markup=crafted_inventory_kb(items, equipped))
        except Exception:
            try:
                await callback.message.delete()
            except Exception:
                pass
            await callback.message.answer(text, reply_markup=crafted_inventory_kb(items, equipped))
    await callback.answer()


@router.callback_query(F.data.startswith("equip_crafted_"))
async def cb_equip_crafted(callback: CallbackQuery):
    item_key = callback.data.replace("equip_crafted_", "")
    cfg = CRAFTABLE_ITEMS.get(item_key)
    if not cfg:
        await callback.answer("❌ Предмет не найден", show_alert=True)
        return
    success, msg = await equip_crafted_item(callback.from_user.id, item_key)
    await callback.answer(f"{'✅' if success else '❌'} {msg}", show_alert=True)
    if success:
        await cb_crafted_inventory(callback)
