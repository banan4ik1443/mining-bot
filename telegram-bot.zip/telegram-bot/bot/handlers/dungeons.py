import time
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from database import (get_army, get_equipment_tier, get_dungeon_cooldown,
                      do_dungeon_raid, calculate_army_power, update_quest_progress,
                      get_crafted_equipment, log_action)
from keyboards.menus import dungeon_list_kb, dungeon_detail_kb, back_to_dungeons_kb
from config import DUNGEONS, RESOURCE_EMOJIS, RESOURCE_NAMES, UNITS_CONFIG

router = Router()

SEP = "──────────────────────"


def _dungeon_list_text(army_power: int) -> str:
    return (
        f"Подземелья и рейды\n"
        f"{SEP}\n\n"
        f"<blockquote>Объединяйтесь в армию и отправляйтесь в захватывающие походы за ресурсами и редкими предметами!</blockquote>\n\n"
        f"Твоя сила: {army_power}\n\n"
        f"Выбери куда пойдешь:"
    )


def _dungeon_detail_text(dungeon: dict, army_power: int, last_raid: int) -> str:
    now = int(time.time())
    remaining = dungeon["cooldown"] - (now - last_raid)
    on_cooldown = remaining > 0
    can_raid = army_power >= dungeon["min_power"] and not on_cooldown

    cd_line = ""
    if on_cooldown:
        h, m = remaining // 3600, (remaining % 3600) // 60
        cd_line = f"   └ КД:  {h}ч {m}мин\n"
    else:
        cd_line = f"   └ КД:  готово ✅\n"

    status = ""
    if can_raid:
        status = "\nАрмия готова к рейду!"
    elif on_cooldown:
        status = f"\n⏳ Подожди немного..."
    else:
        status = f"\n❌ Нужно силы: {dungeon['min_power']}"

    return (
        f"{dungeon['name']}:\n"
        f"{SEP}\n"
        f"Босс: {dungeon['boss']}\n"
        f"   └ Сила: {dungeon['boss_power']}\n"
        f"Нужно силы: {dungeon['min_power']}\n"
        f"Твоя сила: {army_power}\n"
        f"{cd_line}"
        f"{status}\n\n"
        f"Выберите действие:"
    )


@router.message(Command("dungeons"))
async def cmd_dungeons(message: Message):
    army = await get_army(message.from_user.id)
    eq_tier = await get_equipment_tier(message.from_user.id)
    crafted = await get_crafted_equipment(message.from_user.id)
    army_power = calculate_army_power(army, eq_tier, crafted)
    cooldowns = {d["id"]: await get_dungeon_cooldown(message.from_user.id, d["id"]) for d in DUNGEONS}
    await message.answer(
        _dungeon_list_text(army_power),
        reply_markup=dungeon_list_kb(army_power, cooldowns)
    )


@router.callback_query(F.data == "dungeons")
async def cb_dungeons(callback: CallbackQuery):
    army = await get_army(callback.from_user.id)
    eq_tier = await get_equipment_tier(callback.from_user.id)
    crafted = await get_crafted_equipment(callback.from_user.id)
    army_power = calculate_army_power(army, eq_tier, crafted)
    cooldowns = {d["id"]: await get_dungeon_cooldown(callback.from_user.id, d["id"]) for d in DUNGEONS}
    text = _dungeon_list_text(army_power)
    try:
        await callback.message.edit_text(text, reply_markup=dungeon_list_kb(army_power, cooldowns))
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=dungeon_list_kb(army_power, cooldowns))
    await callback.answer()


@router.callback_query(F.data.startswith("dungeon_info_"))
async def cb_dungeon_info(callback: CallbackQuery):
    dungeon_id = callback.data.replace("dungeon_info_", "")
    dungeon = next((d for d in DUNGEONS if d["id"] == dungeon_id), None)
    if not dungeon:
        await callback.answer("❌ Не найдено", show_alert=True)
        return

    army = await get_army(callback.from_user.id)
    eq_tier = await get_equipment_tier(callback.from_user.id)
    crafted = await get_crafted_equipment(callback.from_user.id)
    army_power = calculate_army_power(army, eq_tier, crafted)
    last_raid = await get_dungeon_cooldown(callback.from_user.id, dungeon_id)
    now = int(time.time())
    remaining = dungeon["cooldown"] - (now - last_raid)
    on_cooldown = remaining > 0
    can_raid = army_power >= dungeon["min_power"] and not on_cooldown
    has_army = sum(army.values()) > 0

    text = _dungeon_detail_text(dungeon, army_power, last_raid)
    try:
        await callback.message.edit_text(text, reply_markup=dungeon_detail_kb(dungeon_id, can_raid and has_army))
    except Exception:
        await callback.message.answer(text, reply_markup=dungeon_detail_kb(dungeon_id, can_raid and has_army))
    await callback.answer()


@router.callback_query(F.data.startswith("dungeon_raid_"))
async def cb_dungeon_raid(callback: CallbackQuery):
    dungeon_id = callback.data.replace("dungeon_raid_", "")
    dungeon = next((d for d in DUNGEONS if d["id"] == dungeon_id), None)
    if not dungeon:
        await callback.answer("❌ Не найдено", show_alert=True)
        return

    await callback.answer("⚔️ Рейд начался...")
    success, msg, result = await do_dungeon_raid(callback.from_user.id, dungeon_id)

    if not success:
        try:
            await callback.message.edit_text(f"❌ {msg}", reply_markup=dungeon_detail_kb(dungeon_id, False))
        except Exception:
            await callback.message.answer(f"❌ {msg}")
        return

    won = result["won"]
    loot = result.get("loot", {})
    frags = result.get("frags_gained", 0)
    lost = result.get("units_lost", {})
    army_power = result.get("army_power", 0)
    boss_power = result.get("boss_power", 0)

    outcome = (
        f"🎉 ПОБЕДА!\n{dungeon['emoji']} {dungeon['boss']} побеждён!"
        if won else
        f"💀 ПОРАЖЕНИЕ!\n{dungeon['emoji']} {dungeon['boss']} оказался сильнее."
    )

    loot_lines = [f"   └ {RESOURCE_EMOJIS.get(r, '?')} {RESOURCE_NAMES.get(r, r)}: +{v}" for r, v in loot.items()]
    if frags:
        loot_lines.append(f"   └ 💎 Фрагменты: +{frags}")

    lost_lines = [
        f"   └ {UNITS_CONFIG[u]['emoji']} {UNITS_CONFIG[u]['name']}: -{c}"
        for u, c in lost.items() if u in UNITS_CONFIG
    ]

    text = (
        f"Результат рейда\n"
        f"{SEP}\n\n"
        f"{outcome}\n"
        f"Сила: {army_power} vs Босс: {boss_power}\n"
        f"{SEP}\n"
    )
    if loot_lines:
        text += "» Добыча:\n" + "\n".join(loot_lines) + "\n"
    if lost_lines:
        text += "» Потери:\n" + "\n".join(lost_lines) + "\n"
    else:
        text += "💪 Армия без потерь!\n"

    await update_quest_progress(callback.from_user.id, "raid_dungeon", 1)
    await log_action(callback.from_user.id, f"🏚️ Рейд {dungeon['name']}: {'победа' if won else 'поражение'}")

    try:
        await callback.message.edit_text(text, reply_markup=back_to_dungeons_kb())
    except Exception:
        await callback.message.answer(text, reply_markup=back_to_dungeons_kb())
