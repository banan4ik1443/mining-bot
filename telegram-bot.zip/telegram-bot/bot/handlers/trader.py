from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile
from database import get_active_trader_trades, has_bought_trade, buy_from_trader, get_buildings
from keyboards.menus import trader_kb
from config import RESOURCE_EMOJIS, RESOURCE_NAMES, get_trader_bonus

router = Router()


def _trader_text(trades: list[dict], bought_ids: set, market_level: int) -> str:
    from datetime import datetime
    now = datetime.now()
    mins_left = 60 - now.minute
    bonus = get_trader_bonus(market_level)
    bonus_pct = int((bonus - 1.0) * 100)

    lines = []
    for t in trades:
        bought = t["id"] in bought_ids
        give_name = RESOURCE_NAMES.get(t["give_res"], t["give_res"])
        get_name  = RESOURCE_NAMES.get(t["get_res"], t["get_res"])
        give_e = RESOURCE_EMOJIS.get(t["give_res"], "?")
        get_e  = RESOURCE_EMOJIS.get(t["get_res"], "?")
        arrow = f"{give_e} <b>{t['give_amt']}</b> {give_name} → {get_e} <b>{t['get_amt']}</b> {get_name}"
        status = "✅ Куплено" if bought else "🛒 Доступно"
        lines.append(f"{arrow}\n   {status}")

    bonus_line = f"\n🏪 Бонус рынка ур.{market_level}: <b>+{bonus_pct}%</b> к получаемому" if bonus_pct > 0 else ""

    return (
        f"🧙 <b>Торговец</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⏱️ Обновление через: <b>{mins_left} мин</b>{bonus_line}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n\n".join(lines) + "\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>Каждую сделку можно купить 1 раз в час</i>"
    )


async def _show_trader(target, user_id: int, edit: bool):
    from image_gen import generate_trader_image
    buildings = await get_buildings(user_id)
    market_level = buildings.get("market_building", 0)
    trades = get_active_trader_trades()
    bought_ids = {t["id"] for t in trades if await has_bought_trade(user_id, t["id"])}
    text = _trader_text(trades, bought_ids, market_level)
    kb = trader_kb(trades, bought_ids)

    if edit:
        try:
            await target.message.edit_text(text, reply_markup=kb)
        except Exception:
            try:
                await target.message.delete()
            except Exception:
                pass
            img_buf = generate_trader_image(market_level)
            photo = BufferedInputFile(img_buf.read(), filename="trader.png")
            await target.message.answer_photo(photo=photo, caption=text, reply_markup=kb)
    else:
        img_buf = generate_trader_image(market_level)
        photo = BufferedInputFile(img_buf.read(), filename="trader.png")
        await target.answer_photo(photo=photo, caption=text, reply_markup=kb)


@router.message(Command("trader"))
async def cmd_trader(message: Message):
    await _show_trader(message, message.from_user.id, edit=False)


@router.callback_query(F.data == "trader")
async def cb_trader(callback: CallbackQuery):
    await _show_trader(callback, callback.from_user.id, edit=True)
    await callback.answer()


@router.callback_query(F.data.startswith("trader_buy_"))
async def cb_trader_buy(callback: CallbackQuery):
    trade_id = callback.data.replace("trader_buy_", "")
    success, msg = await buy_from_trader(callback.from_user.id, trade_id)
    await callback.answer(f"{'✅' if success else '❌'} {msg}", show_alert=True)
    if success:
        await _show_trader(callback, callback.from_user.id, edit=True)
