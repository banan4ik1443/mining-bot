from aiogram import Router, F
from aiogram.types import CallbackQuery
from database import get_referrals, get_player
from keyboards.menus import referral_kb, referral_back_kb
from config import REFERRAL_REWARD_REFERRER, REFERRAL_REWARD_NEW_PLAYER, RESOURCE_EMOJIS
import os

router = Router()

BOT_USERNAME = os.getenv("BOT_USERNAME", "village_bot")


def _ref_rewards_text() -> str:
    ref_parts = [f"{RESOURCE_EMOJIS.get(k,'?')} {v} {k}" for k, v in REFERRAL_REWARD_REFERRER.items()]
    new_parts = [f"{RESOURCE_EMOJIS.get(k,'?')} {v} {k}" for k, v in REFERRAL_REWARD_NEW_PLAYER.items()]
    return (
        f"<b>Ты получаешь:</b> {', '.join(ref_parts)}\n"
        f"<b>Новый игрок получает:</b> {', '.join(new_parts)}"
    )


@router.callback_query(F.data == "referral")
async def cb_referral(callback: CallbackQuery):
    user_id = callback.from_user.id
    refs = await get_referrals(user_id)
    ref_count = len(refs)
    ref_link = f"https://t.me/{BOT_USERNAME}?start=ref{user_id}"

    text = (
        f"👥 <b>Реферальная программа</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"🔗 <b>Твоя ссылка:</b>\n"
        f"<code>{ref_link}</code>\n\n"
        f"📊 Приглашено игроков: <b>{ref_count}</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎁 <b>Награды за каждого приглашённого:</b>\n"
        f"{_ref_rewards_text()}\n\n"
        f"💡 <i>Поделись ссылкой — и когда новый игрок\n"
        f"запустит бота, вы оба получите ресурсы!</i>"
    )
    try:
        await callback.message.edit_text(text, reply_markup=referral_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=referral_kb())
    await callback.answer()


@router.callback_query(F.data == "referral_share")
async def cb_referral_share(callback: CallbackQuery):
    user_id = callback.from_user.id
    ref_link = f"https://t.me/{BOT_USERNAME}?start=ref{user_id}"
    player = await get_player(user_id)
    vname = player.get("village_name") or player.get("first_name", "Деревня")

    share_text = (
        f"⚔️ Строю деревню в Village Bot!\n\n"
        f"🏘️ Моя деревня: {vname}\n"
        f"Присоединяйся — получишь бонусные ресурсы!\n\n"
        f"🔗 {ref_link}"
    )
    await callback.answer(
        f"📤 Ссылка для репоста:\n{ref_link}",
        show_alert=True
    )
    try:
        await callback.message.answer(
            f"📤 <b>Поделись этим сообщением:</b>\n\n{share_text}",
            reply_markup=referral_back_kb()
        )
    except Exception:
        pass


@router.callback_query(F.data == "referral_list")
async def cb_referral_list(callback: CallbackQuery):
    refs = await get_referrals(callback.from_user.id)
    if not refs:
        text = (
            "👥 <b>Мои рефералы</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "<i>Пока никого нет. Поделись своей ссылкой!</i>"
        )
    else:
        lines = []
        for i, r in enumerate(refs[:20], 1):
            name = r.get("first_name", "Игрок")
            lines.append(f"{i}. 🏷️ {name}")
        text = (
            f"👥 <b>Мои рефералы</b> ({len(refs)} чел.)\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            + "\n".join(lines)
        )
    try:
        await callback.message.edit_text(text, reply_markup=referral_back_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=referral_back_kb())
    await callback.answer()
