import time
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database import (get_player, get_all_players, ban_player, unban_player,
                      get_stats, give_resources, reset_all_players)
from keyboards.menus import (admin_main_kb, ban_duration_kb, back_to_admin_kb,
                              admin_give_resource_kb, admin_reset_confirm_kb)
from config import ADMIN_IDS, BAN_DURATIONS, RESOURCE_NAMES, RESOURCE_EMOJIS

router = Router()


class AdminBanStates(StatesGroup):
    entering_user_id = State()
    entering_reason = State()


class AdminUnbanStates(StatesGroup):
    entering_user_id = State()


class AdminBroadcastStates(StatesGroup):
    entering_message = State()


class AdminGiveStates(StatesGroup):
    entering_user_id = State()
    choosing_resource = State()
    entering_amount = State()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer("🚫 Нет доступа")
        return
    await state.clear()
    await message.answer("🔧 <b>Панель администратора</b>\n\nВыбери действие:", reply_markup=admin_main_kb())


@router.callback_query(F.data == "admin_menu")
async def cb_admin_menu(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.clear()
    try:
        await callback.message.edit_text("🔧 <b>Панель администратора</b>", reply_markup=admin_main_kb())
    except Exception:
        await callback.message.answer("🔧 <b>Панель администратора</b>", reply_markup=admin_main_kb())
    await callback.answer()


@router.callback_query(F.data == "admin_stats")
async def cb_admin_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    stats = await get_stats()
    text = (
        f"📊 <b>Статистика бота</b>\n\n"
        f"👥 Всего игроков: <b>{stats['total_players']}</b>\n"
        f"🚫 Заблокировано: <b>{stats['banned']}</b>\n"
        f"🏪 Активных лотов: <b>{stats['active_listings']}</b>\n"
        f"👥 Рефералов: <b>{stats['referrals']}</b>"
    )
    await callback.answer()
    try:
        await callback.message.edit_text(text, reply_markup=back_to_admin_kb())
    except Exception:
        await callback.message.answer(text, reply_markup=back_to_admin_kb())


@router.callback_query(F.data == "admin_players")
async def cb_admin_players(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    players = await get_all_players(20)
    lines = []
    for p in players:
        ban_mark = "🚫" if p["is_banned"] else "✅"
        name = p.get("first_name", "?")
        uname = f"@{p['username']}" if p.get("username") else ""
        lines.append(f"{ban_mark} <b>{name}</b> {uname} (ID: <code>{p['user_id']}</code>)")
    text = f"👥 <b>Последние 20 игроков</b>\n\n" + ("\n".join(lines) if lines else "Нет игроков")
    await callback.answer()
    try:
        await callback.message.edit_text(text, reply_markup=back_to_admin_kb())
    except Exception:
        await callback.message.answer(text, reply_markup=back_to_admin_kb())


@router.callback_query(F.data == "admin_give_start")
async def cb_admin_give_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(AdminGiveStates.entering_user_id)
    await callback.answer()
    await callback.message.edit_text(
        "💎 <b>Выдать ресурсы</b>\n\nВведи <b>Telegram ID</b> игрока:",
        reply_markup=back_to_admin_kb()
    )


@router.message(AdminGiveStates.entering_user_id)
async def msg_give_user_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        target_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Введи числовой ID")
        return
    player = await get_player(target_id)
    if not player:
        await message.answer("❌ Игрок не найден")
        return
    name = player.get("first_name", "?")
    await state.update_data(target_id=target_id, target_name=name)
    await state.set_state(AdminGiveStates.choosing_resource)
    await message.answer(
        f"👤 Игрок: <b>{name}</b> (ID: <code>{target_id}</code>)\n\nВыбери ресурс:",
        reply_markup=admin_give_resource_kb()
    )


@router.callback_query(AdminGiveStates.choosing_resource, F.data.startswith("admin_give_res_"))
async def cb_give_resource_chosen(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫", show_alert=True)
        return
    resource = callback.data.replace("admin_give_res_", "")
    await state.update_data(resource=resource)
    await state.set_state(AdminGiveStates.entering_amount)
    data = await state.get_data()
    await callback.answer()
    await callback.message.edit_text(
        f"💎 Выдача: <b>{RESOURCE_EMOJIS.get(resource,'?')} {RESOURCE_NAMES.get(resource, resource)}</b>\n"
        f"Игрок: <b>{data['target_name']}</b>\n\nВведи количество:",
        reply_markup=None
    )


@router.message(AdminGiveStates.entering_amount)
async def msg_give_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = float(message.text.strip())
        if amount <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Введи положительное число")
        return
    data = await state.get_data()
    target_id = data["target_id"]
    resource = data["resource"]
    await give_resources(target_id, resource, amount)
    await state.clear()
    await message.answer(
        f"✅ <b>Ресурсы выданы!</b>\n\n"
        f"👤 ID <code>{target_id}</code>\n"
        f"{RESOURCE_EMOJIS.get(resource,'?')} {RESOURCE_NAMES.get(resource, resource)}: <b>+{amount:.0f}</b>",
        reply_markup=admin_main_kb()
    )
    try:
        await message.bot.send_message(
            target_id,
            f"🎁 <b>Подарок от администратора!</b>\n\n"
            f"{RESOURCE_EMOJIS.get(resource,'?')} {RESOURCE_NAMES.get(resource, resource)}: <b>+{amount:.0f}</b>"
        )
    except Exception:
        pass


@router.callback_query(F.data == "admin_reset_confirm")
async def cb_admin_reset_confirm(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await callback.answer()
    await callback.message.edit_text(
        "⚠️ <b>СБРОС ПРОГРЕССА ВСЕХ ИГРОКОВ</b>\n\n"
        "Это действие <b>необратимо</b>!\n\nТы уверен?",
        reply_markup=admin_reset_confirm_kb()
    )


@router.callback_query(F.data == "admin_reset_do")
async def cb_admin_reset_do(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await callback.answer("⏳ Сбрасываю...", show_alert=False)
    await reset_all_players()
    await callback.message.edit_text(
        "✅ <b>Прогресс всех игроков сброшен!</b>",
        reply_markup=admin_main_kb()
    )


@router.callback_query(F.data == "admin_ban_start")
async def cb_admin_ban_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(AdminBanStates.entering_user_id)
    await callback.answer()
    await callback.message.edit_text(
        "🔨 <b>Бан игрока</b>\n\nВведи <b>Telegram ID</b>:",
        reply_markup=back_to_admin_kb()
    )


@router.message(AdminBanStates.entering_user_id)
async def msg_ban_user_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        target_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Введи числовой ID")
        return
    player = await get_player(target_id)
    if not player:
        await message.answer("❌ Игрок не найден")
        return
    if player["is_banned"]:
        await message.answer("⚠️ Игрок уже заблокирован.")
        return
    name = player.get("first_name", "?")
    uname = f"@{player['username']}" if player.get("username") else ""
    await state.update_data(target_id=target_id, target_name=name)
    await message.answer(
        f"👤 <b>{name}</b> {uname} (ID: <code>{target_id}</code>)\n\nВыбери срок бана:",
        reply_markup=ban_duration_kb(target_id)
    )


@router.callback_query(F.data.startswith("ban_dur_"))
async def cb_ban_duration(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    parts = callback.data.split("_")
    target_id = int(parts[2])
    duration_key = parts[3]
    duration_label, duration_secs = BAN_DURATIONS[duration_key]
    await state.update_data(target_id=target_id, duration_key=duration_key,
                            duration_label=duration_label, duration_secs=duration_secs)
    await state.set_state(AdminBanStates.entering_reason)
    await callback.answer()
    await callback.message.edit_text(
        f"🔨 Бан (ID: <code>{target_id}</code>)  ·  ⏱️ {duration_label}\n\nВведи причину:",
        reply_markup=back_to_admin_kb()
    )


@router.message(AdminBanStates.entering_reason)
async def msg_ban_reason(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    target_id, duration_secs, duration_label = data["target_id"], data["duration_secs"], data["duration_label"]
    reason = message.text.strip()
    await ban_player(target_id, message.from_user.id, reason, duration_secs)
    await state.clear()
    import datetime
    until_text = "навсегда" if duration_secs == -1 else datetime.datetime.fromtimestamp(
        int(time.time()) + duration_secs).strftime("%d.%m.%Y %H:%M")
    await message.answer(
        f"✅ <b>Игрок заблокирован!</b>\n\nID: <code>{target_id}</code>\n"
        f"Срок: <b>{duration_label}</b>  ·  До: <b>{until_text}</b>\n"
        f"Причина: <b>{reason}</b>",
        reply_markup=admin_main_kb()
    )
    try:
        await message.bot.send_message(
            target_id,
            f"🚫 <b>Ваш аккаунт заблокирован</b>\n\n"
            f"⏱️ Срок: <b>{duration_label}</b>  ·  До: <b>{until_text}</b>\n"
            f"📋 Причина: <b>{reason}</b>"
        )
    except Exception:
        pass


@router.callback_query(F.data == "admin_unban_start")
async def cb_admin_unban_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(AdminUnbanStates.entering_user_id)
    await callback.answer()
    await callback.message.edit_text("✅ <b>Разбан</b>\n\nВведи Telegram ID:", reply_markup=back_to_admin_kb())


@router.message(AdminUnbanStates.entering_user_id)
async def msg_unban_user_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        target_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Введи числовой ID")
        return
    player = await get_player(target_id)
    if not player:
        await message.answer("❌ Игрок не найден")
        await state.clear()
        return
    if not player["is_banned"]:
        await message.answer("⚠️ Игрок не заблокирован")
        await state.clear()
        return
    ban_reason = player.get("ban_reason", "")
    await unban_player(target_id)
    await state.clear()
    name = player.get("first_name", "?")
    await message.answer(
        f"✅ <b>Игрок разблокирован!</b>\n\n👤 <b>{name}</b> (ID: <code>{target_id}</code>)",
        reply_markup=admin_main_kb()
    )
    try:
        await message.bot.send_message(
            target_id,
            f"✅ <b>Ваш аккаунт разблокирован!</b>\n\nПричина предыдущего бана: <b>{ban_reason or 'не указана'}</b>"
        )
    except Exception:
        pass


@router.callback_query(F.data == "admin_broadcast_start")
async def cb_admin_broadcast_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("🚫 Нет доступа", show_alert=True)
        return
    await state.set_state(AdminBroadcastStates.entering_message)
    await callback.answer()
    await callback.message.edit_text("📢 <b>Рассылка</b>\n\nВведи текст:", reply_markup=back_to_admin_kb())


@router.message(AdminBroadcastStates.entering_message)
async def msg_broadcast(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    text = message.text.strip()
    players = await get_all_players(10000)
    await state.clear()
    sent, failed = 0, 0
    for player in players:
        if player["user_id"] == message.from_user.id:
            continue
        try:
            await message.bot.send_message(
                player["user_id"],
                f"📢 <b>Сообщение от администратора</b>\n\n{text}"
            )
            sent += 1
        except Exception:
            failed += 1
    await message.answer(
        f"📢 <b>Рассылка завершена</b>\n\n✅ Отправлено: <b>{sent}</b>\n❌ Ошибок: <b>{failed}</b>",
        reply_markup=admin_main_kb()
    )
