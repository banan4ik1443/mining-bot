from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message
from database import get_top_players, get_army, get_equipment_tier, get_crafted_equipment, calculate_army_power
from keyboards.menus import top_kb, top_back_kb

router = Router()

SEP = "──────────────────────"

TOP_DESC = "Здесь вы найдёте список самых талантливых игроков вашего мира."


def _top_main_text() -> str:
    return (
        f"Топ\n"
        f"{SEP}\n\n"
        f"<blockquote>{TOP_DESC}</blockquote>\n\n"
        f"Выберите топ:"
    )


def _top_power_text(players: list[dict]) -> str:
    medals = ["🥇", "🥈", "🥉"]
    lines = []
    for i, p in enumerate(players):
        medal = medals[i] if i < 3 else f"  #{i + 1}"
        name = p.get("first_name") or p.get("username") or "Игрок"
        power = p.get("army_power", 0)
        lines.append(f"{medal} {name}\n     ⚡ Сила: {power}")
    body = "\n\n".join(lines) if lines else "Пока нет игроков в топе"
    return f"Топ по силе\n{SEP}\n\n{body}"


def _top_balance_text(players: list[dict]) -> str:
    medals = ["🥇", "🥈", "🥉"]
    lines = []
    for i, p in enumerate(players):
        medal = medals[i] if i < 3 else f"  #{i + 1}"
        name = p.get("first_name") or p.get("username") or "Игрок"
        gold = p.get("gold", 0)
        lines.append(f"{medal} {name}\n     💰 Золото: {gold:.0f}")
    body = "\n\n".join(lines) if lines else "Пока нет игроков в топе"
    return f"Топ по балансу\n{SEP}\n\n{body}"


def _top_th_text(players: list[dict]) -> str:
    medals = ["🥇", "🥈", "🥉"]
    lines = []
    for i, p in enumerate(players):
        medal = medals[i] if i < 3 else f"  #{i + 1}"
        name = p.get("first_name") or p.get("username") or "Игрок"
        th = p.get("town_hall_level", 1)
        total = p.get("total_building_levels", 0)
        lines.append(f"{medal} {name}\n     🏛️ Ратуша: ур. {th}  ·  Всего: {total}")
    body = "\n\n".join(lines) if lines else "Пока нет игроков в топе"
    return f"Топ по уровню ратуши\n{SEP}\n\n{body}"


@router.message(Command("top"))
async def cmd_top(message: Message):
    await message.answer(_top_main_text(), reply_markup=top_kb())


@router.callback_query(F.data == "top")
async def cb_top(callback: CallbackQuery):
    try:
        await callback.message.edit_text(_top_main_text(), reply_markup=top_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(_top_main_text(), reply_markup=top_kb())
    await callback.answer()


@router.callback_query(F.data == "top_power")
async def cb_top_power(callback: CallbackQuery):
    players = await get_top_players(10)
    # Calculate army power for each player
    enriched = []
    for p in players:
        uid = p.get("user_id")
        try:
            army = await get_army(uid)
            eq_tier = await get_equipment_tier(uid)
            crafted = await get_crafted_equipment(uid)
            power = calculate_army_power(army, eq_tier, crafted)
        except Exception:
            power = 0
        enriched.append({**p, "army_power": power})
    enriched.sort(key=lambda x: x["army_power"], reverse=True)
    try:
        await callback.message.edit_text(_top_power_text(enriched), reply_markup=top_back_kb())
    except Exception:
        await callback.message.answer(_top_power_text(enriched), reply_markup=top_back_kb())
    await callback.answer()


@router.callback_query(F.data == "top_balance")
async def cb_top_balance(callback: CallbackQuery):
    players = await get_top_players(10)
    players.sort(key=lambda x: x.get("gold", 0), reverse=True)
    try:
        await callback.message.edit_text(_top_balance_text(players), reply_markup=top_back_kb())
    except Exception:
        await callback.message.answer(_top_balance_text(players), reply_markup=top_back_kb())
    await callback.answer()


@router.callback_query(F.data == "top_th")
async def cb_top_th(callback: CallbackQuery):
    players = await get_top_players(10)

    enriched = []
    for p in players:
        from database import get_buildings
        uid = p.get("user_id")
        try:
            buildings = await get_buildings(uid)
            th_level = buildings.get("town_hall", 1)
            total_lvls = sum(buildings.values())
        except Exception:
            th_level = 1
            total_lvls = 0
        enriched.append({**p, "town_hall_level": th_level, "total_building_levels": total_lvls})
    enriched.sort(key=lambda x: (x["town_hall_level"], x["total_building_levels"]), reverse=True)
    try:
        await callback.message.edit_text(_top_th_text(enriched), reply_markup=top_back_kb())
    except Exception:
        await callback.message.answer(_top_th_text(enriched), reply_markup=top_back_kb())
    await callback.answer()
