from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message, BufferedInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database import (get_player, get_buildings, get_market_listings,
                      get_my_listings, create_listing, buy_listing, cancel_listing)
from keyboards.menus import (market_main_kb, market_listings_kb, market_sell_resource_kb,
                              my_listings_kb, confirm_purchase_kb)
from config import RESOURCE_EMOJIS, RESOURCE_NAMES, get_market_fee

router = Router()

SEP = "──────────────────────"

MARKET_DESC = "Здесь вы можете приобрести ресурсы у других игроков или выставить свои товары на продажу."


class SellStates(StatesGroup):
    choosing_resource = State()
    entering_amount = State()
    entering_price = State()


def _listings_text(listings: list[dict]) -> str:
    if not listings:
        return "📭 Лотов пока нет\n\nБудь первым, кто выставит товар!"
    lines = []
    for l in listings[:10]:
        res = l["resource"]
        total = l["amount"] * l["price_per_unit"]
        lines.append(
            f"#{l['id']} {RESOURCE_EMOJIS.get(res, '')} {RESOURCE_NAMES.get(res, res)}  "
            f"{l['amount']:.0f} ед. · 💰{l['price_per_unit']:.1f}/ед. = 💰{total:.1f}\n"
            f"   └ {l['seller_name']}"
        )
    return "\n\n".join(lines)


@router.message(Command("market"))
async def cmd_market(message: Message, state: FSMContext):
    await state.clear()
    await _show_market_msg(message, message.from_user.id)


@router.callback_query(F.data == "market")
async def cb_market(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    try:
        await callback.message.delete()
    except Exception:
        pass
    await _show_market_msg(callback.message, callback.from_user.id)
    await callback.answer()


async def _show_market_msg(msg, user_id: int):
    buildings = await get_buildings(user_id)
    player = await get_player(user_id)
    market_level = buildings.get("market_building", 0)
    gold = player.get("gold", 0) if player else 0
    fee = get_market_fee(market_level)
    fee_pct = int(fee * 100)

    if market_level == 0:
        text = (
            f"Рынок\n"
            f"{SEP}\n\n"
            f"<blockquote>{MARKET_DESC}</blockquote>\n\n"
            f"🔴 Рынок не построен!\n\n"
            f"Постройте Рынок (/shop), чтобы торговать."
        )
    else:
        text = (
            f"Рынок\n"
            f"{SEP}\n\n"
            f"<blockquote>{MARKET_DESC}</blockquote>\n\n"
            f"Ваш баланс: {gold:.0f}\n\n"
            f"Выберите действие:"
        )

    from image_gen import generate_building_image
    img_buf = generate_building_image("market_building", market_level)
    photo = BufferedInputFile(img_buf.read(), filename="market.png")
    await msg.answer_photo(photo=photo, caption=text, reply_markup=market_main_kb())


@router.callback_query(F.data == "market_buy")
async def cb_market_buy(callback: CallbackQuery):
    listings = await get_market_listings(exclude_user=callback.from_user.id)
    text = (
        f"Рынок — Покупка\n"
        f"{SEP}\n\n"
        f"Лотов: {len(listings)}\n\n"
        + _listings_text(listings)
    )
    try:
        await callback.message.edit_caption(
            caption=text, reply_markup=market_listings_kb(listings, callback.from_user.id)
        )
    except Exception:
        try:
            await callback.message.edit_text(
                text, reply_markup=market_listings_kb(listings, callback.from_user.id)
            )
        except Exception:
            pass
    await callback.answer()


@router.callback_query(F.data.startswith("buy_listing_"))
async def cb_buy_listing_confirm(callback: CallbackQuery):
    listing_id = int(callback.data.replace("buy_listing_", ""))
    all_listings = await get_market_listings()
    listing = next((l for l in all_listings if l["id"] == listing_id), None)
    if not listing:
        await callback.answer("❌ Лот не найден или уже продан", show_alert=True)
        return

    res = listing["resource"]
    total = listing["amount"] * listing["price_per_unit"]
    player = await get_player(callback.from_user.id)
    can_afford = player.get("gold", 0) >= total
    afford = "✅ Достаточно золота" if can_afford else f"❌ Недостаточно (есть: 💰{player.get('gold', 0):.1f})"

    text = (
        f"Подтверждение покупки\n"
        f"{SEP}\n\n"
        f"{RESOURCE_EMOJIS.get(res, '')} {RESOURCE_NAMES.get(res, res)}\n"
        f"   └ Количество: {listing['amount']:.0f} ед.\n"
        f"   └ Цена/ед.: 💰{listing['price_per_unit']:.1f}\n"
        f"   └ Итого: 💰{total:.1f}\n"
        f"   └ Продавец: {listing['seller_name']}\n\n"
        f"{afford}"
    )
    try:
        await callback.message.edit_caption(caption=text, reply_markup=confirm_purchase_kb(listing_id))
    except Exception:
        try:
            await callback.message.edit_text(text, reply_markup=confirm_purchase_kb(listing_id))
        except Exception:
            pass
    await callback.answer()


@router.callback_query(F.data.startswith("confirm_buy_"))
async def cb_confirm_buy(callback: CallbackQuery):
    listing_id = int(callback.data.replace("confirm_buy_", ""))
    success, msg, listing = await buy_listing(callback.from_user.id, listing_id)

    if not success:
        await callback.answer(f"❌ {msg}", show_alert=True)
        return

    await callback.answer(f"✅ {msg}", show_alert=True)
    listings = await get_market_listings(exclude_user=callback.from_user.id)
    text = (
        f"✅ Покупка совершена!\n"
        f"{SEP}\n\n"
        f"Доступные лоты ({len(listings)}):\n\n"
        + _listings_text(listings)
    )
    try:
        await callback.message.edit_caption(
            caption=text, reply_markup=market_listings_kb(listings, callback.from_user.id)
        )
    except Exception:
        try:
            await callback.message.edit_text(
                text, reply_markup=market_listings_kb(listings, callback.from_user.id)
            )
        except Exception:
            pass

    if listing:
        try:
            res = listing["resource"]
            buildings = await get_buildings(listing["seller_id"])
            market_lvl = buildings.get("market_building", 0)
            fee = get_market_fee(market_lvl)
            seller_gets = listing["amount"] * listing["price_per_unit"] * (1 - fee)
            fee_pct = int(fee * 100)
            await callback.bot.send_message(
                listing["seller_id"],
                f"💰 <b>Ваш лот продан!</b>\n\n"
                f"{RESOURCE_EMOJIS.get(res, '')} {listing['amount']:.0f} ед. {RESOURCE_NAMES.get(res, res)}\n"
                f"Получено: 💰 <b>{seller_gets:.1f}</b> (комиссия {fee_pct}%)",
                parse_mode="HTML"
            )
        except Exception:
            pass


@router.callback_query(F.data == "market_sell_start")
async def cb_market_sell_start(callback: CallbackQuery, state: FSMContext):
    buildings = await get_buildings(callback.from_user.id)
    market_level = buildings.get("market_building", 0)
    if market_level == 0:
        await callback.answer("❌ Нужно сначала построить Рынок!", show_alert=True)
        return
    my_listings = await get_my_listings(callback.from_user.id)
    if len(my_listings) >= market_level:
        await callback.answer(f"❌ Лимит лотов ({market_level}). Улучши Рынок!", show_alert=True)
        return
    await state.set_state(SellStates.choosing_resource)
    text = "Продажа ресурсов\n\nВыбери ресурс:"
    try:
        await callback.message.edit_caption(caption=text, reply_markup=market_sell_resource_kb())
    except Exception:
        try:
            await callback.message.edit_text(text, reply_markup=market_sell_resource_kb())
        except Exception:
            pass
    await callback.answer()


@router.callback_query(SellStates.choosing_resource, F.data.startswith("sell_resource_"))
async def cb_sell_resource_chosen(callback: CallbackQuery, state: FSMContext):
    resource = callback.data.replace("sell_resource_", "")
    player = await get_player(callback.from_user.id)
    have = player.get(resource, 0)
    if have < 1:
        await callback.answer(f"❌ У тебя нет {RESOURCE_NAMES.get(resource, resource)}!", show_alert=True)
        return
    await state.update_data(resource=resource, have=have)
    await state.set_state(SellStates.entering_amount)
    text = (
        f"Продажа: {RESOURCE_EMOJIS[resource]} {RESOURCE_NAMES[resource]}\n\n"
        f"Введи количество (есть {have:.0f} ед.):"
    )
    try:
        await callback.message.edit_caption(caption=text, reply_markup=None)
    except Exception:
        try:
            await callback.message.edit_text(text, reply_markup=None)
        except Exception:
            pass
    await callback.answer()


@router.message(SellStates.entering_amount)
async def msg_sell_amount(message: Message, state: FSMContext):
    try:
        amount = float(message.text.strip())
        if amount <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Введи корректное число больше 0")
        return
    data = await state.get_data()
    if amount > data["have"]:
        await message.answer(f"❌ У тебя только {data['have']:.0f} ед.")
        return
    await state.update_data(amount=amount)
    await state.set_state(SellStates.entering_price)
    await message.answer(
        f"💰 Введи цену за 1 единицу в золоте:\n"
        f"({amount:.0f} ед. {RESOURCE_EMOJIS[data['resource']]} {RESOURCE_NAMES[data['resource']]})"
    )


@router.message(SellStates.entering_price)
async def msg_sell_price(message: Message, state: FSMContext):
    try:
        price = float(message.text.strip())
        if price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Введи корректную цену больше 0")
        return
    data = await state.get_data()
    resource, amount = data["resource"], data["amount"]
    buildings = await get_buildings(message.from_user.id)
    market_level = buildings.get("market_building", 0)
    fee = get_market_fee(market_level)
    fee_pct = int(fee * 100)
    net = amount * price * (1 - fee)
    name = message.from_user.first_name or "Игрок"
    success, msg = await create_listing(message.from_user.id, name, resource, amount, price)
    await state.clear()
    if success:
        from database import update_quest_progress
        await update_quest_progress(message.from_user.id, "sell_market", int(amount))
        await message.answer(
            f"✅ Лот выставлен!\n\n"
            f"{RESOURCE_EMOJIS[resource]} {RESOURCE_NAMES[resource]}: {amount:.0f} ед.\n"
            f"   └ Цена: 💰{price:.1f}/ед.  ·  Итого: 💰{amount * price:.1f}\n"
            f"   └ Комиссия: {fee_pct}%  ·  Получишь: 💰{net:.1f}",
            reply_markup=market_main_kb()
        )
    else:
        await message.answer(f"❌ {msg}")


@router.callback_query(F.data == "market_my_listings")
async def cb_my_listings(callback: CallbackQuery):
    listings = await get_my_listings(callback.from_user.id)
    if not listings:
        text = f"Мои лоты\n\n📭 У тебя нет активных лотов."
    else:
        lines = [
            f"#{l['id']} {RESOURCE_EMOJIS.get(l['resource'], '')} {RESOURCE_NAMES.get(l['resource'], l['resource'])}: "
            f"{l['amount']:.0f} ед. · 💰{l['price_per_unit']:.1f}/ед."
            for l in listings
        ]
        text = f"Мои лоты ({len(listings)})\n{SEP}\n" + "\n".join(lines)
    try:
        await callback.message.edit_caption(caption=text, reply_markup=my_listings_kb(listings))
    except Exception:
        try:
            await callback.message.edit_text(text, reply_markup=my_listings_kb(listings))
        except Exception:
            pass
    await callback.answer()


@router.callback_query(F.data.startswith("cancel_listing_"))
async def cb_cancel_listing(callback: CallbackQuery):
    listing_id = int(callback.data.replace("cancel_listing_", ""))
    success, msg = await cancel_listing(callback.from_user.id, listing_id)
    await callback.answer(f"{'✅' if success else '❌'} {msg}", show_alert=True)
    if success:
        listings = await get_my_listings(callback.from_user.id)
        text = f"Мои лоты\n\n📭 Лотов нет." if not listings else (
            f"Мои лоты ({len(listings)})\n" +
            "\n".join(f"#{l['id']} {RESOURCE_EMOJIS.get(l['resource'], '')} {l['amount']:.0f} ед." for l in listings)
        )
        try:
            await callback.message.edit_caption(caption=text, reply_markup=my_listings_kb(listings))
        except Exception:
            try:
                await callback.message.edit_text(text, reply_markup=my_listings_kb(listings))
            except Exception:
                pass
