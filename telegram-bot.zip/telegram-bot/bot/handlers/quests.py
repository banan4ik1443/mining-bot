from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from database import (get_player, get_buildings, get_army, get_or_create_daily_quests,
                      claim_quest_reward, update_quest_progress_stat)
from keyboards.menus import quests_kb
from config import RESOURCE_EMOJIS, RESOURCE_NAMES

router = Router()


def _quest_status(q: dict) -> str:
    progress = q.get("progress", 0)
    target = q.get("target", 1)
    completed = q.get("completed", 0)
    claimed = q.get("reward_claimed", 0)
    pct = min(100, int(progress / max(1, target) * 100))
    bar_len = 8
    filled = int(bar_len * pct / 100)
    bar = "█" * filled + "░" * (bar_len - filled)

    reward_res = q.get("reward_resource", "gold")
    reward_amt = q.get("reward_amount", 0)
    reward_emoji = RESOURCE_EMOJIS.get(reward_res, "💰")

    if claimed:
        status = "✅ Получено"
    elif completed:
        status = "🎁 Нажми чтобы забрать!"
    else:
        status = f"[{bar}] {progress}/{target}"

    return (
        f"📜 <b>{q['quest_name']}</b>\n"
        f"   {status}\n"
        f"   Награда: {reward_emoji} {reward_amt} {RESOURCE_NAMES.get(reward_res, reward_res)}"
    )


async def _get_quests_with_stats(user_id: int) -> list[dict]:
    buildings = await get_buildings(user_id)
    th_level = buildings.get("town_hall", 1)
    quests = await get_or_create_daily_quests(user_id, th_level)

    army = await get_army(user_id)
    player = await get_player(user_id)
    total_units = sum(army.values())

    for q in quests:
        if q["quest_type"] == "have_units":
            new_prog = min(int(total_units), int(q["target"]))
            await update_quest_progress_stat(user_id, q["quest_date"], q["quest_index"], new_prog)
            q["progress"] = new_prog
            q["completed"] = 1 if new_prog >= q["target"] else 0
        elif q["quest_type"] == "collect_gold":
            new_prog = min(int(player.get("gold", 0)), int(q["target"]))
            await update_quest_progress_stat(user_id, q["quest_date"], q["quest_index"], new_prog)
            q["progress"] = new_prog
            q["completed"] = 1 if new_prog >= q["target"] else 0

    return quests


async def _show_quests(target, user_id: int, edit: bool):
    quests = await _get_quests_with_stats(user_id)
    from datetime import date
    today = date.today().strftime("%d.%m.%Y")
    lines = [_quest_status(q) for q in quests]
    text = (
        f"📜 <b>Ежедневные задания</b>\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"📅 {today}  ·  Обновление в 00:00\n"
        f"━━━━━━━━━━━━━━━━━\n"
        + "\n\n".join(lines)
    )
    kb = quests_kb(quests)
    if edit:
        try:
            await target.message.edit_text(text, reply_markup=kb)
        except Exception:
            try:
                await target.message.delete()
            except Exception:
                pass
            await target.message.answer(text, reply_markup=kb)
    else:
        await target.answer(text, reply_markup=kb)


@router.message(Command("quests"))
async def cmd_quests(message: Message):
    await _show_quests(message, message.from_user.id, edit=False)


@router.callback_query(F.data == "quests")
async def cb_quests(callback: CallbackQuery):
    await _show_quests(callback, callback.from_user.id, edit=True)
    await callback.answer()


@router.callback_query(F.data.startswith("quest_claim_"))
async def cb_quest_claim(callback: CallbackQuery):
    quest_index = int(callback.data.replace("quest_claim_", ""))
    success, msg, reward = await claim_quest_reward(callback.from_user.id, quest_index)
    if not success:
        await callback.answer(f"❌ {msg}", show_alert=True)
        return
    res = reward.get("resource", "gold")
    amt = reward.get("amount", 0)
    await callback.answer(
        f"🎁 {msg} {RESOURCE_EMOJIS.get(res, '')} +{amt} {RESOURCE_NAMES.get(res, res)}",
        show_alert=True
    )
    await _show_quests(callback, callback.from_user.id, edit=True)
