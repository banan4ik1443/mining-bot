from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database import (get_player, get_buildings, get_army, get_equipment_tier,
                      hire_units, fire_units, upgrade_equipment, get_inventory_item,
                      calculate_army_power, update_quest_progress, get_owned_equipment_tiers,
                      equip_tier, get_crafted_equipment)
from keyboards.menus import army_main_kb, hire_type_kb, equipment_kb
from config import UNITS_CONFIG, EQUIPMENT_TIERS

router = Router()

SEP = "──────────────────────"


class ArmyStates(StatesGroup):
    hire_choosing_type = State()
    hire_entering_count = State()
    fire_choosing_type = State()
    fire_entering_count = State()


def _army_text(army: dict, eq_tier: int, barracks_level: int, fragments: int, crafted_item: str | None) -> str:
    from config import CRAFTABLE_ITEMS
    power = calculate_army_power(army, eq_tier, crafted_item)
    max_units = barracks_level * 5
    total_units = sum(army.values())
    eq = EQUIPMENT_TIERS[eq_tier]

    unit_lines = []
    for ut, cfg in UNITS_CONFIG.items():
        count = army.get(ut, 0)
        unit_lines.append(f"   └ {cfg['emoji']} {cfg['name']}: {count}  (Ат:{cfg['attack']} Защ:{cfg['defense']})")

    crafted_line = ""
    if crafted_item and crafted_item in CRAFTABLE_ITEMS:
        ci = CRAFTABLE_ITEMS[crafted_item]
        bonuses = []
        if ci.get("attack_bonus", 0) > 0:
            bonuses.append(f"+{int(ci['attack_bonus']*100)}% атк")
        if ci.get("defense_bonus", 0) > 0:
            bonuses.append(f"+{int(ci['defense_bonus']*100)}% защ")
        crafted_line = f"\n   └ {ci['emoji']} {ci['name']}  ({', '.join(bonuses)})"

    if barracks_level == 0:
        barracks_info = "Казармы не построены"
    else:
        barracks_info = f"Ур. {barracks_level}  ·  Вместимость: {total_units}/{max_units}"

    return (
        f"Армия деревни\n"
        f"{SEP}\n\n"
        f"<blockquote>Здесь вы можете управлять армией, нанимать воинов и улучшать снаряжение.</blockquote>\n\n"
        f"» Казармы:  {barracks_info}\n"
        f"   └ Сила армии:  {power}\n"
        f"» Состав:\n"
        + "\n".join(unit_lines) + "\n"
        f"» Снаряжение:  {eq['emoji']} {eq['name']}\n"
        f"   └ +{int(eq['attack_bonus']*100)}% атака  ·  +{int(eq['defense_bonus']*100)}% защита{crafted_line}\n"
        f"   └ 💎 Фрагменты: {fragments}\n\n"
        f"Выберите действие:"
    )


async def _show_army(target, user_id: int, edit: bool):
    buildings = await get_buildings(user_id)
    barracks_level = buildings.get("barracks", 0)
    army = await get_army(user_id)
    eq_tier = await get_equipment_tier(user_id)
    fragments = await get_inventory_item(user_id, "fragment")
    crafted = await get_crafted_equipment(user_id)
    text = _army_text(army, eq_tier, barracks_level, fragments, crafted)
    kb = army_main_kb(barracks_level)
    if edit:
        try:
            await target.message.edit_text(text, reply_markup=kb)
        except Exception:
            try:
                await target.message.delete()
            except Exception:
                pass
            await target.message.answer(text, reply_markup=kb)
    else:
        await target.answer(text, reply_markup=kb)


@router.message(Command("army"))
async def cmd_army(message: Message, state: FSMContext):
    await state.clear()
    await _show_army(message, message.from_user.id, edit=False)


@router.callback_query(F.data == "army")
async def cb_army(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await _show_army(callback, callback.from_user.id, edit=True)
    await callback.answer()


@router.callback_query(F.data == "army_hire")
async def cb_army_hire(callback: CallbackQuery, state: FSMContext):
    buildings = await get_buildings(callback.from_user.id)
    if buildings.get("barracks", 0) == 0:
        await callback.answer("❌ Сначала постройте Казарму!", show_alert=True)
        return
    await state.set_state(ArmyStates.hire_choosing_type)
    try:
        await callback.message.edit_text(
            f"Нанять воинов\n\nВыбери тип воина:",
            reply_markup=hire_type_kb()
        )
    except Exception:
        await callback.message.answer(f"Нанять воинов\n\nВыбери тип воина:", reply_markup=hire_type_kb())
    await callback.answer()


@router.callback_query(ArmyStates.hire_choosing_type, F.data.startswith("hire_type_"))
async def cb_hire_type(callback: CallbackQuery, state: FSMContext):
    unit_type = callback.data.replace("hire_type_", "")
    cfg = UNITS_CONFIG.get(unit_type)
    if not cfg:
        await callback.answer("❌ Неизвестный тип", show_alert=True)
        return
    buildings = await get_buildings(callback.from_user.id)
    army = await get_army(callback.from_user.id)
    barracks_level = buildings.get("barracks", 0)
    max_units = barracks_level * 5
    total_units = sum(army.values())
    available_slots = max_units - total_units
    await state.update_data(unit_type=unit_type)
    await state.set_state(ArmyStates.hire_entering_count)
    player = await get_player(callback.from_user.id)
    max_can_buy = int(player.get("gold", 0) // cfg["cost_gold"])
    await callback.message.edit_text(
        f"{cfg['emoji']} Нанять {cfg['name']}ов\n\n"
        f"   └ Цена: 💰{cfg['cost_gold']}/ед.\n"
        f"   └ Твоё золото: 💰{player.get('gold', 0):.0f}\n"
        f"   └ Свободных мест: {available_slots}\n"
        f"   └ Максимум нанять: {min(max_can_buy, available_slots)}\n\n"
        f"Введи количество (или /start для отмены):",
        reply_markup=None
    )
    await callback.answer()


@router.message(ArmyStates.hire_entering_count)
async def msg_hire_count(message: Message, state: FSMContext):
    try:
        count = int(message.text.strip())
        if count <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Введи целое положительное число")
        return
    data = await state.get_data()
    unit_type = data.get("unit_type", "swordsman")
    success, msg = await hire_units(message.from_user.id, unit_type, count)
    await state.clear()
    if success:
        await update_quest_progress(message.from_user.id, "hire_units", count)
        from database import log_action
        await log_action(message.from_user.id, f"⚔️ Нанято {count} {UNITS_CONFIG.get(unit_type,{}).get('name','воинов')}")
    await message.answer(f"{'✅' if success else '❌'} {msg}")


@router.callback_query(F.data == "army_fire")
async def cb_army_fire(callback: CallbackQuery, state: FSMContext):
    army = await get_army(callback.from_user.id)
    if not any(v > 0 for v in army.values()):
        await callback.answer("❌ Нет воинов для увольнения", show_alert=True)
        return
    await state.set_state(ArmyStates.fire_choosing_type)
    try:
        await callback.message.edit_text(
            "Уволить воинов\n\nВыбери тип:", reply_markup=hire_type_kb(fire_mode=True)
        )
    except Exception:
        await callback.message.answer("Уволить воинов\n\nВыбери тип:", reply_markup=hire_type_kb(fire_mode=True))
    await callback.answer()


@router.callback_query(ArmyStates.fire_choosing_type, F.data.startswith("hire_type_"))
async def cb_fire_type(callback: CallbackQuery, state: FSMContext):
    unit_type = callback.data.replace("hire_type_", "")
    cfg = UNITS_CONFIG.get(unit_type)
    army = await get_army(callback.from_user.id)
    count = army.get(unit_type, 0)
    await state.update_data(unit_type=unit_type)
    await state.set_state(ArmyStates.fire_entering_count)
    await callback.message.edit_text(
        f"{cfg['emoji']} Уволить {cfg['name']}ов\n\nВ строю: {count}\n\nСколько уволить?",
        reply_markup=None
    )
    await callback.answer()


@router.message(ArmyStates.fire_entering_count)
async def msg_fire_count(message: Message, state: FSMContext):
    try:
        count = int(message.text.strip())
        if count <= 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Введи целое положительное число")
        return
    data = await state.get_data()
    success, msg = await fire_units(message.from_user.id, data.get("unit_type"), count)
    await state.clear()
    await message.answer(f"{'✅' if success else '❌'} {msg}")


@router.callback_query(F.data == "army_equipment")
async def cb_army_equipment(callback: CallbackQuery):
    buildings = await get_buildings(callback.from_user.id)
    smithy_level = buildings.get("smithy", 0)
    eq_tier = await get_equipment_tier(callback.from_user.id)
    owned_tiers = await get_owned_equipment_tiers(callback.from_user.id)
    fragments = await get_inventory_item(callback.from_user.id, "fragment")
    player = await get_player(callback.from_user.id)

    eq = EQUIPMENT_TIERS[eq_tier]
    next_tier = eq_tier + 1
    next_eq = EQUIPMENT_TIERS.get(next_tier)

    text = (
        f"Снаряжение армии\n"
        f"{SEP}\n\n"
        f"» Надето:  {eq['emoji']} {eq['name']}\n"
        f"   └ +{int(eq['attack_bonus']*100)}% атака  ·  +{int(eq['defense_bonus']*100)}% защита\n"
        f"{SEP}\n"
    )

    can_upgrade = False
    if next_eq:
        req_smithy = next_eq.get("min_smithy", 0)
        req_frags = next_eq.get("fragments", 0)
        cost = next_eq.get("cost", {})
        from config import RESOURCE_EMOJIS, RESOURCE_NAMES
        cost_lines = [
            f"   └ {RESOURCE_EMOJIS[r]} {RESOURCE_NAMES[r]}: {a} (есть: {player.get(r, 0):.0f})"
            for r, a in cost.items()
        ]
        if req_frags:
            cost_lines.append(f"   └ 💎 Фрагменты: {req_frags} (есть: {fragments})")
        text += (
            f"» Следующий ур.:  {next_eq['emoji']} {next_eq['name']}\n"
            f"   └ +{int(next_eq['attack_bonus']*100)}% атака  ·  +{int(next_eq['defense_bonus']*100)}% защита\n"
            f"   └ 🔨 Кузница ур. {req_smithy}\n\n"
            f"» Стоимость:\n" + "\n".join(cost_lines)
        )
        can_upgrade = smithy_level >= req_smithy
    else:
        text += "✅ Максимальное снаряжение!"

    if len(owned_tiers) > 1:
        text += "\n\n» Сохранённые (можно надеть):\n"
        for tier in owned_tiers:
            mark = "✅ " if tier == eq_tier else "   "
            t_cfg = EQUIPMENT_TIERS[tier]
            text += f"{mark}{t_cfg['emoji']} {t_cfg['name']}\n"

    try:
        await callback.message.edit_text(text, reply_markup=equipment_kb(can_upgrade, eq_tier, owned_tiers))
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=equipment_kb(can_upgrade, eq_tier, owned_tiers))
    await callback.answer()


@router.callback_query(F.data == "equipment_upgrade_do")
async def cb_equipment_upgrade(callback: CallbackQuery):
    success, msg = await upgrade_equipment(callback.from_user.id)
    await callback.answer(f"{'✅' if success else '❌'} {msg}", show_alert=True)
    if success:
        from database import log_action
        await log_action(callback.from_user.id, f"⚙️ Снаряжение улучшено")
        await cb_army_equipment(callback)


@router.callback_query(F.data.startswith("equip_tier_"))
async def cb_equip_tier(callback: CallbackQuery):
    tier = int(callback.data.replace("equip_tier_", ""))
    success, msg = await equip_tier(callback.from_user.id, tier)
    await callback.answer(f"{'✅' if success else '❌'} {msg}", show_alert=True)
    if success:
        await cb_army_equipment(callback)
