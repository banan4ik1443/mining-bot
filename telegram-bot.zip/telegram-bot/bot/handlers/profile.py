import time
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database import (get_player, get_buildings, get_top_players, update_village_name,
                      collect_resources, get_army, get_equipment_tier, get_village_logs,
                      toggle_profile_link, get_player_settings, get_inventory_clusters,
                      get_crafted_equipment, get_referrals)
from keyboards.menus import profile_kb, profile_settings_kb
from config import BASE_STORAGE, STORAGE_BONUS_PER_LEVEL, EQUIPMENT_TIERS, CRAFTABLE_ITEMS

router = Router()

SEP = "──────────────────────"


class ProfileSettingsStates(StatesGroup):
    entering_village_name = State()
    entering_profile_photo = State()


def _calc_power(buildings: dict, army: dict) -> int:
    total_lvls = sum(buildings.values())
    barracks = buildings.get("barracks", 0)
    return total_lvls * 10 + barracks * 50


def _profile_text(player: dict, buildings: dict, rank: int, army: dict,
                  eq_tier: int, settings: dict, crafted_item: str | None,
                  referral_count: int) -> str:
    th = buildings.get("town_hall", 1)
    total_lvls = sum(buildings.values())
    power = _calc_power(buildings, army)
    vname = player.get("village_name") or player.get("first_name", "Деревня")
    created = player.get("created_at", int(time.time()))
    days = max(0, (int(time.time()) - created) // 86400)
    rank_text = f"#{rank}" if rank else "—"
    total_units = sum(army.values())
    eq = EQUIPMENT_TIERS[eq_tier]

    crafted_line = ""
    if crafted_item and crafted_item in CRAFTABLE_ITEMS:
        ci = CRAFTABLE_ITEMS[crafted_item]
        crafted_line = f"\n   └ Предмет:  {ci['emoji']} {ci['name']}"

    show_link = not settings.get("hide_profile_link", False)
    link_line = ""
    if show_link and player.get("username"):
        link_line = f"   └ Ник:  @{player['username']}\n"
    else:
        link_line = f"   └ Ник:  {player.get('first_name', 'Игрок')}\n"

    return (
        f"ПРОФИЛЬ ИГРОКА:\n\n"
        f"» Деревня:  {vname}\n"
        f"{link_line}"
        f"   └ В игре:  {days} дн.\n"
        f"{SEP}\n"
        f"» Характеристики:\n"
        f"   └ Ратуша:  ур. {th}\n"
        f"   └ Всего уровней:  {total_lvls}\n"
        f"   └ Сила:  {power}\n"
        f"   └ Рейтинг:  {rank_text}\n"
        f"» Армия:  {total_units} бойцов\n"
        f"   └ Снаряжение:  {eq['emoji']} {eq['name']}{crafted_line}\n"
        f"» Рефералов:  {referral_count}"
    )


async def _get_rank(user_id: int) -> int:
    top = await get_top_players(200)
    for i, p in enumerate(top):
        if p["user_id"] == user_id:
            return i + 1
    return 0


async def _show_profile(target, user_id: int, edit: bool):
    await collect_resources(user_id)
    player = await get_player(user_id)
    buildings = await get_buildings(user_id)
    rank = await _get_rank(user_id)
    army = await get_army(user_id)
    eq_tier = await get_equipment_tier(user_id)
    settings = await get_player_settings(user_id)
    clusters = await get_inventory_clusters(user_id)
    crafted_item = await get_crafted_equipment(user_id)
    refs = await get_referrals(user_id)
    referral_count = len(refs) if refs else 0
    has_clusters = len(clusters) > 0
    text = _profile_text(player, buildings, rank, army, eq_tier, settings, crafted_item, referral_count)
    kb = profile_kb(has_clusters=has_clusters)
    if edit:
        try:
            await target.message.edit_text(text, reply_markup=kb)
        except Exception:
            try:
                await target.message.delete()
            except Exception:
                pass
            await target.message.answer(text, reply_markup=kb)
    else:
        await target.answer(text, reply_markup=kb)


@router.message(Command("profile"))
async def cmd_profile(message: Message):
    await _show_profile(message, message.from_user.id, edit=False)


@router.callback_query(F.data == "profile")
async def cb_profile(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await _show_profile(callback, callback.from_user.id, edit=True)
    await callback.answer()


@router.callback_query(F.data == "profile_settings")
async def cb_profile_settings(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    player = await get_player(callback.from_user.id)
    settings = await get_player_settings(callback.from_user.id)
    vname = player.get("village_name") or player.get("first_name", "Деревня")
    created = player.get("created_at", int(time.time()))
    reg_date = datetime.fromtimestamp(created).strftime("%d.%m.%Y")
    link_status = "скрыта 🔒" if settings.get("hide_profile_link") else "видна 👁️"
    text = (
        f"Настройки профиля\n"
        f"{SEP}\n\n"
        f"» Деревня:  {vname}\n"
        f"   └ Имя:  {player.get('first_name', '?')}\n"
        f"   └ ID:  {player['user_id']}\n"
        f"   └ Зарег.:  {reg_date}\n"
        f"   └ Ссылка:  {link_status}"
    )
    try:
        await callback.message.edit_text(text, reply_markup=profile_settings_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=profile_settings_kb())
    await callback.answer()


@router.callback_query(F.data == "change_village_name")
async def cb_change_village_name(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ProfileSettingsStates.entering_village_name)
    try:
        await callback.message.edit_text(
            "✏️ Введи новое название деревни (2–24 символа):\n<i>Для отмены — /start</i>",
            reply_markup=None
        )
    except Exception:
        await callback.message.answer(
            "✏️ Введи новое название деревни (2–24 символа):\n<i>Для отмены — /start</i>"
        )
    await callback.answer()


@router.message(ProfileSettingsStates.entering_village_name)
async def msg_village_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 2 or len(name) > 24:
        await message.answer("❌ Название должно быть от 2 до 24 символов. Попробуй ещё раз:")
        return
    await update_village_name(message.from_user.id, name)
    await state.clear()
    await message.answer(
        f"✅ Название деревни изменено!\n\n🏘️ Теперь твоя деревня: <b>{name}</b>",
        reply_markup=profile_settings_kb()
    )


@router.callback_query(F.data == "change_profile_photo")
async def cb_change_profile_photo(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ProfileSettingsStates.entering_profile_photo)
    try:
        await callback.message.edit_text(
            "🖼️ Отправь фото для профиля деревни.\n<i>Для отмены — /start</i>",
            reply_markup=None
        )
    except Exception:
        await callback.message.answer(
            "🖼️ Отправь фото для профиля деревни.\n<i>Для отмены — /start</i>"
        )
    await callback.answer()


@router.message(ProfileSettingsStates.entering_profile_photo, F.photo)
async def msg_profile_photo(message: Message, state: FSMContext):
    from database import update_profile_photo
    photo = message.photo[-1]
    await update_profile_photo(message.from_user.id, photo.file_id)
    await state.clear()
    await message.answer("✅ Фото профиля обновлено!", reply_markup=profile_settings_kb())


@router.callback_query(F.data == "toggle_profile_link")
async def cb_toggle_profile_link(callback: CallbackQuery):
    settings = await get_player_settings(callback.from_user.id)
    current = settings.get("hide_profile_link", False)
    await toggle_profile_link(callback.from_user.id, not current)
    status = "скрыта 🔒" if not current else "видна 👁️"
    await callback.answer(f"✅ Ссылка теперь {status}", show_alert=True)
    player = await get_player(callback.from_user.id)
    settings = await get_player_settings(callback.from_user.id)
    vname = player.get("village_name") or player.get("first_name", "Деревня")
    created = player.get("created_at", int(time.time()))
    reg_date = datetime.fromtimestamp(created).strftime("%d.%m.%Y")
    link_status = "скрыта 🔒" if settings.get("hide_profile_link") else "видна 👁️"
    text = (
        f"Настройки профиля\n"
        f"{SEP}\n\n"
        f"» Деревня:  {vname}\n"
        f"   └ Имя:  {player.get('first_name', '?')}\n"
        f"   └ ID:  {player['user_id']}\n"
        f"   └ Зарег.:  {reg_date}\n"
        f"   └ Ссылка:  {link_status}"
    )
    try:
        await callback.message.edit_text(text, reply_markup=profile_settings_kb())
    except Exception:
        pass


@router.callback_query(F.data == "village_logs")
async def cb_village_logs(callback: CallbackQuery):
    logs = await get_village_logs(callback.from_user.id, limit=20)
    if not logs:
        text = (
            f"Логи деревни\n"
            f"{SEP}\n\n"
            f"<i>Пока нет записей. Начни строить!</i>"
        )
    else:
        lines = []
        for log in logs:
            ts = datetime.fromtimestamp(log["timestamp"]).strftime("%d.%m %H:%M")
            lines.append(f"<code>{ts}</code>  {log['message']}")
        text = f"Логи деревни\n{SEP}\n\n" + "\n".join(lines)
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    b = InlineKeyboardBuilder()
    b.button(text="🔙 Настройки", callback_data="profile_settings")
    b.adjust(1)
    try:
        await callback.message.edit_text(text, reply_markup=b.as_markup())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=b.as_markup())
    await callback.answer()


@router.callback_query(F.data == "storage_info")
async def cb_storage_info(callback: CallbackQuery):
    player = await get_player(callback.from_user.id)
    buildings = await get_buildings(callback.from_user.id)
    storage_level = buildings.get("storage", 0)
    max_res = BASE_STORAGE + storage_level * STORAGE_BONUS_PER_LEVEL

    def pct(v): return int(v / max_res * 100) if max_res > 0 else 0

    wood  = player.get("wood",  0)
    ore   = player.get("ore",   0)
    stone = player.get("stone", 0)
    food  = player.get("food",  0)
    gold  = player.get("gold",  0)

    text = (
        f"Склад\n"
        f"{SEP}\n\n"
        f"» Уровень:  {storage_level}\n"
        f"   └ Вместимость:  {max_res:.0f} ед.\n"
        f"{SEP}\n"
        f"» Запасы:\n"
        f"   └ 🪵 Дерево:  {wood:.0f}/{max_res:.0f}  ({pct(wood)}%)\n"
        f"   └ ⛏️ Руда:  {ore:.0f}/{max_res:.0f}  ({pct(ore)}%)\n"
        f"   └ 🪨 Камень:  {stone:.0f}/{max_res:.0f}  ({pct(stone)}%)\n"
        f"   └ 🌾 Еда:  {food:.0f}/{max_res:.0f}  ({pct(food)}%)\n"
        f"   └ 💰 Золото:  {gold:.0f}"
    )
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    b = InlineKeyboardBuilder()
    b.button(text="⬆️ Улучшить склад", callback_data="do_upgrade_storage")
    b.button(text="🔙 Настройки",       callback_data="profile_settings")
    b.adjust(1)
    try:
        await callback.message.edit_text(text, reply_markup=b.as_markup())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=b.as_markup())
    await callback.answer()
