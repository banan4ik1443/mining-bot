from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from database import get_player, register_player, get_buildings
from keyboards.menus import main_menu_kb, help_sections_kb, help_back_kb
from config import BOT_VERSION

router = Router()

SEP = "──────────────────────"

WELCOME_DESC = (
    "Строй и развивай свою деревню, "
    "добывай ресурсы, торгуй с другими игроками "
    "и соревнуйся в таблице лидеров!"
)


def _main_menu_text(village: str, th: int, power: int) -> str:
    return (
        f"Добро пожаловать!\n"
        f"{SEP}\n\n"
        f"<blockquote>{WELCOME_DESC}</blockquote>\n\n"
        f"» Деревня:  {village}\n"
        f"   └ Ратуша:  ур. {th}  ·  Сила: {power}\n\n"
        f"Выберите действие:"
    )


@router.message(CommandStart())
async def cmd_start(message: Message):
    is_new = await register_player(
        message.from_user.id,
        message.from_user.first_name or "Игрок",
        message.from_user.username,
        ref_id=_extract_ref(message.text),
    )
    name = message.from_user.first_name or "Игрок"

    if is_new:
        text = (
            f"Добро пожаловать!\n"
            f"{SEP}\n\n"
            f"<blockquote>{WELCOME_DESC}</blockquote>\n\n"
            f"» Привет, {name}! Начни с постройки Ратуши.\n"
            f"   └ Ратуша → Лесопилка → Ферма → Шахта\n\n"
            f"Выберите действие:"
        )
    else:
        buildings = await get_buildings(message.from_user.id)
        player = await get_player(message.from_user.id)
        th = buildings.get("town_hall", 1)
        total_lvls = sum(buildings.values())
        power = total_lvls * 10 + buildings.get("barracks", 0) * 50
        village = (player.get("village_name") or name) if player else name
        text = _main_menu_text(village, th, power)

    await message.answer(text, reply_markup=main_menu_kb())


def _extract_ref(text: str | None) -> int | None:
    if not text:
        return None
    parts = text.strip().split()
    if len(parts) >= 2 and parts[1].startswith("ref"):
        try:
            return int(parts[1][3:])
        except ValueError:
            pass
    return None


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery):
    buildings = await get_buildings(callback.from_user.id)
    player = await get_player(callback.from_user.id)
    name = player.get("first_name", "Игрок") if player else "Игрок"
    th = buildings.get("town_hall", 1)
    total_lvls = sum(buildings.values())
    power = total_lvls * 10 + buildings.get("barracks", 0) * 50
    village = (player.get("village_name") or name) if player else name
    text = _main_menu_text(village, th, power)
    try:
        await callback.message.edit_text(text, reply_markup=main_menu_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=main_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    text = (
        f"Помощь\n"
        f"{SEP}\n\n"
        f"<blockquote>Здесь ты найдёшь ответы на вопросы об игровой механике и подсказки для новичков.</blockquote>\n\n"
        f"Выберите раздел:"
    )
    try:
        await callback.message.edit_text(text, reply_markup=help_sections_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=help_sections_kb())
    await callback.answer()


@router.callback_query(F.data == "help_about")
async def cb_help_about(callback: CallbackQuery):
    text = (
        f"О игре\n"
        f"{SEP}\n\n"
        f"<blockquote>Village Bot — RPG про строительство деревни. Развивай своё поселение и стань сильнейшим!</blockquote>\n\n"
        f"» Что можно делать:\n"
        f"   └ Строить деревню (8 зданий, до 10 уровней)\n"
        f"   └ Нанимать армию и ковать снаряжение\n"
        f"   └ Добывать редкие руды и крафтить оружие\n"
        f"   └ Воевать с другими игроками\n"
        f"   └ Рейдить подземелья за лутом\n"
        f"   └ Торговать на рынке\n"
        f"   └ Выполнять ежедневные задания\n\n"
        f"» Прогрессия:\n"
        f"   └ Дни 1-7: базовая инфраструктура\n"
        f"   └ Дни 8-14: армия и снаряжение\n"
        f"   └ Дни 15-21: подземелья и торговля\n"
        f"   └ Дни 22-30: легендарное снаряжение"
    )
    try:
        await callback.message.edit_text(text, reply_markup=help_back_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=help_back_kb())
    await callback.answer()


@router.callback_query(F.data == "help_buildings")
async def cb_help_buildings(callback: CallbackQuery):
    text = (
        f"Здания\n"
        f"{SEP}\n\n"
        f"<blockquote>Все здания прокачиваются до 10 уровня. Максимальный уровень здания = уровень Ратуши × 2.</blockquote>\n\n"
        f"🏛️ Ратуша  — задаёт лимит всех зданий\n"
        f"🌾 Ферма  — еда для шахты, лесопилки, воинов\n"
        f"🪵 Лесопилка  — дерево, тратит 2 еды/ч·ур\n"
        f"⛏️ Шахта  — камень + руда (ур.2+) + кластеры (ур.4+)\n"
        f"🔨 Кузница  — золото + снаряжение + крафт\n"
        f"⚔️ Казармы  — воины, вместимость = ур×5\n"
        f"🏪 Рынок  — торговля, ниже комиссия с уровнем\n"
        f"🏦 Склад  — +500 к каждому ресурсу за уровень"
    )
    try:
        await callback.message.edit_text(text, reply_markup=help_back_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=help_back_kb())
    await callback.answer()


@router.callback_query(F.data == "help_combat")
async def cb_help_combat(callback: CallbackQuery):
    text = (
        f"Боевая система\n"
        f"{SEP}\n\n"
        f"<blockquote>Тренируй армию в Казармах, кови снаряжение в Кузнице и завоёвывай новые территории!</blockquote>\n\n"
        f"» Армия:\n"
        f"   └ ⚔️ Мечник (80💰) — сбалансированный\n"
        f"   └ 🛡️ Щитовщик (110💰) — высокая защита\n"
        f"   └ 🧙 Маг (150💰) — высокая атака\n\n"
        f"» Снаряжение:\n"
        f"   └ ⚙️ Железное → 🔩 Стальное\n"
        f"   └ 💎 Митриловое → 🌟 Легендарное\n\n"
        f"» Война деревень:\n"
        f"   └ Атака: кд 6ч\n"
        f"   └ Щит защиты: 2ч\n"
        f"   └ Победитель забирает 5-20% ресурсов"
    )
    try:
        await callback.message.edit_text(text, reply_markup=help_back_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=help_back_kb())
    await callback.answer()


@router.callback_query(F.data == "help_mine")
async def cb_help_mine(callback: CallbackQuery):
    text = (
        f"Шахта и редкие руды\n"
        f"{SEP}\n\n"
        f"<blockquote>Здесь добывают камень и руду, и есть небольшой шанс получить кластер руды.</blockquote>\n\n"
        f"» Добыча по уровням:\n"
        f"   └ Ур.1: камень\n"
        f"   └ Ур.2+: камень + руда\n"
        f"   └ Ур.4+: шанс на кластеры!\n\n"
        f"» Кластеры руды:\n"
        f"   └ 📦 Железный — железная руда\n"
        f"   └ 🌟 Серебряный — серебро + золото\n"
        f"   └ ✨ Золотой — золотая руда + митрил\n"
        f"   └ 💠 Митриловый — редчайший!\n\n"
        f"» Из редких руд крафтится:\n"
        f"   └ Мечи · Посохи · Броня (в Кузнице)"
    )
    try:
        await callback.message.edit_text(text, reply_markup=help_back_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=help_back_kb())
    await callback.answer()


@router.callback_query(F.data == "help_tips")
async def cb_help_tips(callback: CallbackQuery):
    text = (
        f"Советы новичку\n"
        f"{SEP}\n\n"
        f"<blockquote>Следуй этим советам, чтобы быстрее развить свою деревню!</blockquote>\n\n"
        f"» Порядок постройки:\n"
        f"   └ Ратуша → Лесопилка → Ферма → Шахта\n\n"
        f"» Еда: лесопилка и шахта тратят 2/ч·ур\n"
        f"» Шахта до ур.4 = кластеры редких руд\n"
        f"» Митрил = самое мощное снаряжение\n"
        f"» Улучшай Склад — ресурсы не переполнятся\n"
        f"» Торговец обновляется каждый час\n"
        f"» Задания = бесплатные ресурсы каждый день"
    )
    try:
        await callback.message.edit_text(text, reply_markup=help_back_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=help_back_kb())
    await callback.answer()


@router.callback_query(F.data == "to_chat")
async def cb_to_chat(callback: CallbackQuery):
    await callback.answer("💬 Общение с другими игроками в чате!", show_alert=True)
