from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.types import BufferedInputFile
from database import get_player, get_buildings, upgrade_building, collect_resources, log_action, get_inventory_clusters
from keyboards.menus import building_detail_kb, clusters_kb, buildings_menu_kb
from config import (BUILDINGS_CONFIG, BUILDING_ORDER, RESOURCE_EMOJIS, RESOURCE_NAMES,
                    COMMAND_TO_BUILDING, CLUSTER_CHANCES_BY_LEVEL, ORE_CLUSTER_CONTENTS,
                    CLUSTER_EMOJIS, BASE_STORAGE, STORAGE_BONUS_PER_LEVEL, get_market_fee)
from image_gen import generate_building_image

router = Router()

SEP = "──────────────────────"


def _building_detail_text(building_key: str, cfg: dict, buildings: dict, player: dict) -> tuple[str, bool, bool]:
    th_level = buildings.get("town_hall", 1)
    current_level = buildings.get(building_key, 0)
    max_level = cfg.get("max_level") or th_level * 2
    if cfg.get("max_level"):
        max_level = cfg["max_level"]

    can_upgrade = current_level < max_level
    can_afford = True

    if current_level == 0:
        # Not built — show cost
        cost = cfg["upgrade_cost"](1)
        cost_lines = []
        for res, amount in cost.items():
            have = player.get(res, 0)
            ok = have >= amount
            if not ok:
                can_afford = False
            mark = "✅" if ok else "❌"
            cost_lines.append(f"{mark} {RESOURCE_EMOJIS[res]} {RESOURCE_NAMES[res]}: {amount:.0f}")

        text = (
            f"Вы еще не построили {cfg['name']}!\n"
            f"Необходимо ресурсов:\n"
            f"{SEP}\n"
            + "\n".join(cost_lines)
            + f"\n\nВыберите действие:"
        )
        return text, can_upgrade, can_afford

    # Built — show stats
    stats = [f"Уровень: {current_level}/{max_level}"]

    if building_key == "mine":
        stone_rate = 10 * current_level
        ore_rate = max(0, current_level - 1) * 8 if current_level >= 2 else 0
        stats.append(f"Камень: {stone_rate} ед/час")
        stats.append(f"Руда: {ore_rate} ед/час")
        if current_level >= 4:
            level_chances = CLUSTER_CHANCES_BY_LEVEL.get(current_level, {})
            total_chance = sum(level_chances.values()) * 100
            stats.append(f"Шанс кластеров: ~{total_chance:.0f}%/ч")
    elif building_key == "smithy":
        gold_rate = 7 * current_level
        stats.append(f"Золото: {gold_rate} ед/час")
    elif cfg["production"]:
        res, rate = cfg["production"]
        stats.append(f"{RESOURCE_NAMES[res]}: {rate * current_level:.0f} ед/час")

    if building_key == "storage":
        max_r = BASE_STORAGE + current_level * STORAGE_BONUS_PER_LEVEL
        stats.append(f"Вместимость: {max_r:.0f}")
    elif building_key == "barracks":
        stats.append(f"Вместимость: {current_level * 5}")
    elif building_key == "market_building":
        fee = get_market_fee(current_level)
        stats.append(f"Комиссия: {fee * 100:.1f}%")

    # Check if can afford upgrade
    if can_upgrade:
        next_level = current_level + 1
        cost = cfg["upgrade_cost"](next_level)
        for res, amount in cost.items():
            if player.get(res, 0) < amount:
                can_afford = False
                break

    text = (
        f"{cfg['name']}\n"
        f"{SEP}\n\n"
        f"<blockquote>{cfg['description']}</blockquote>\n\n"
        + "\n".join(stats)
        + "\n\nВыберите действие:"
    )
    return text, can_upgrade, can_afford


async def _show_building(target, building_key: str, user_id: int, edit: bool = False):
    cfg = BUILDINGS_CONFIG.get(building_key)
    if not cfg or cfg.get("hidden", False):
        if edit:
            await target.answer("❌ Здание не найдено", show_alert=True)
        else:
            await target.answer("❌ Здание не найдено")
        return

    await collect_resources(user_id)
    buildings = await get_buildings(user_id)
    player = await get_player(user_id)
    current_level = buildings.get(building_key, 0)
    th_level = buildings.get("town_hall", 1)
    max_level = cfg.get("max_level") or th_level * 2
    if cfg.get("max_level"):
        max_level = cfg["max_level"]

    text, can_upgrade, can_afford = _building_detail_text(building_key, cfg, buildings, player)
    kb = building_detail_kb(building_key, can_upgrade and can_afford, current_level, max_level)

    img_buf = generate_building_image(building_key, current_level)
    photo = BufferedInputFile(img_buf.read(), filename=f"{building_key}_lv{current_level}.png")

    if edit:
        try:
            await target.message.delete()
        except Exception:
            pass
        await target.message.answer_photo(photo=photo, caption=text, reply_markup=kb)
    else:
        await target.answer_photo(photo=photo, caption=text, reply_markup=kb)


async def _cmd_building(message: Message, building_key: str):
    await _show_building(message, building_key, message.from_user.id, edit=False)


# ── Buildings menu ────────────────────────────────────────────────────────
@router.callback_query(F.data == "buildings_menu")
async def cb_buildings_menu(callback: CallbackQuery):
    await collect_resources(callback.from_user.id)
    buildings = await get_buildings(callback.from_user.id)
    player = await get_player(callback.from_user.id)

    th = buildings.get("town_hall", 1)
    total_lvls = sum(buildings.values())
    max_res = BASE_STORAGE + buildings.get("storage", 0) * STORAGE_BONUS_PER_LEVEL

    res_parts = []
    for res in ["wood", "ore", "stone", "food"]:
        val = player.get(res, 0)
        res_parts.append(f"{RESOURCE_EMOJIS[res]} {val:.0f}")
    gold = player.get("gold", 0)

    text = (
        f"Моя деревня\n"
        f"{SEP}\n\n"
        f"<blockquote>Ратуша ур. {th}  ·  Всего уровней: {total_lvls}\n"
        f"Склад: {max_res:.0f} · 💰 {gold:.0f}</blockquote>\n\n"
        f"{'  '.join(res_parts)}\n\n"
        f"Выберите здание:"
    )
    try:
        await callback.message.edit_text(text, reply_markup=buildings_menu_kb(buildings))
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=buildings_menu_kb(buildings))
    await callback.answer()


# ── Building commands ─────────────────────────────────────────────────────
@router.message(Command("townhall"))
async def cmd_townhall(message: Message):
    await _cmd_building(message, "town_hall")

@router.message(Command("farm"))
async def cmd_farm(message: Message):
    await _cmd_building(message, "farm")

@router.message(Command("sawmill"))
async def cmd_sawmill(message: Message):
    await _cmd_building(message, "sawmill")

@router.message(Command("mine"))
async def cmd_mine(message: Message):
    await _cmd_building(message, "mine")

@router.message(Command("smithy"))
async def cmd_smithy(message: Message):
    await _cmd_building(message, "smithy")

@router.message(Command("barracks"))
async def cmd_barracks(message: Message):
    await _cmd_building(message, "barracks")

@router.message(Command("shop"))
async def cmd_shop(message: Message):
    await _cmd_building(message, "market_building")

@router.message(Command("storage"))
async def cmd_storage(message: Message):
    await _cmd_building(message, "storage")


# ── Upgrade callbacks ─────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("upgrade_"))
async def cb_upgrade_info(callback: CallbackQuery):
    building_key = callback.data.replace("upgrade_", "")
    cfg = BUILDINGS_CONFIG.get(building_key)
    if not cfg or cfg.get("hidden", False):
        await callback.answer("❌ Здание не найдено", show_alert=True)
        return
    await _show_building(callback, building_key, callback.from_user.id, edit=True)
    await callback.answer()


@router.callback_query(F.data.startswith("do_upgrade_"))
async def cb_do_upgrade(callback: CallbackQuery):
    building_key = callback.data.replace("do_upgrade_", "")
    cfg = BUILDINGS_CONFIG.get(building_key)
    if not cfg or cfg.get("hidden", False):
        await callback.answer("❌ Здание не найдено", show_alert=True)
        return

    success, msg = await upgrade_building(callback.from_user.id, building_key)
    if not success:
        await callback.answer(f"❌ {msg}", show_alert=True)
        return

    buildings = await get_buildings(callback.from_user.id)
    player = await get_player(callback.from_user.id)
    new_level = buildings.get(building_key, 0)
    th_level = buildings.get("town_hall", 1)
    max_level = cfg.get("max_level") or th_level * 2

    await log_action(callback.from_user.id, f"⬆️ {cfg['emoji']} {cfg['name']} улучшена до ур. {new_level}")

    text, can_upgrade, can_afford = _building_detail_text(building_key, cfg, buildings, player)
    text = f"✅ {cfg['name']} улучшено до ур. {new_level}!\n\n" + text
    kb = building_detail_kb(building_key, can_upgrade and can_afford, new_level, max_level)

    img_buf = generate_building_image(building_key, new_level)
    photo = BufferedInputFile(img_buf.read(), filename=f"{building_key}_lv{new_level}.png")

    await callback.answer(f"✅ {cfg['name']} → ур. {new_level}!", show_alert=False)
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.message.answer_photo(photo=photo, caption=text, reply_markup=kb)


# ── Clusters ──────────────────────────────────────────────────────────────
@router.callback_query(F.data == "clusters_menu")
async def cb_clusters_menu(callback: CallbackQuery):
    clusters = await get_inventory_clusters(callback.from_user.id)
    if not clusters:
        await callback.answer("📭 Нет кластеров руды. Улучши Шахту до 4+ ур.!", show_alert=True)
        return
    text = (
        f"Кластеры руды\n"
        f"{SEP}\n\n"
        f"<blockquote>Открой кластер, чтобы получить редкие руды!</blockquote>\n\n"
    )
    for c in clusters:
        emoji = CLUSTER_EMOJIS.get(c["cluster_type"], "📦")
        cfg_c = ORE_CLUSTER_CONTENTS.get(c["cluster_type"], {})
        name = cfg_c.get("name", c["cluster_type"])
        text += f"{emoji} {name}: x{c['quantity']}\n"
    try:
        await callback.message.edit_text(text, reply_markup=clusters_kb(clusters))
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(text, reply_markup=clusters_kb(clusters))
    await callback.answer()


@router.callback_query(F.data.startswith("open_cluster_"))
async def cb_open_cluster(callback: CallbackQuery):
    cluster_type = callback.data.replace("open_cluster_", "")
    from database import open_ore_cluster
    success, msg, drops = await open_ore_cluster(callback.from_user.id, cluster_type)
    if not success:
        await callback.answer(f"❌ {msg}", show_alert=True)
        return

    drop_lines = []
    for res, amt in drops.items():
        drop_lines.append(f"  {RESOURCE_EMOJIS.get(res, '🔩')} {RESOURCE_NAMES.get(res, res)}: +{amt}")

    result_text = f"✨ Кластер открыт!\n\nПолучено:\n" + "\n".join(drop_lines)
    await callback.answer(result_text, show_alert=True)

    await log_action(callback.from_user.id, f"💠 Открыт {cluster_type}: {', '.join(f'+{v} {k}' for k, v in drops.items())}")
    await cb_clusters_menu(callback)
