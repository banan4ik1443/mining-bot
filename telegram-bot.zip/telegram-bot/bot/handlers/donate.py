from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import (
    Message, CallbackQuery, LabeledPrice,
    PreCheckoutQuery, SuccessfulPayment
)
from database import get_player, give_resources, add_inventory_item
from keyboards.menus import donate_kb
from config import DONATE_PACKAGES, RESOURCE_EMOJIS, RESOURCE_NAMES

router = Router()


def _find_package(pkg_id: str) -> dict | None:
    return next((p for p in DONATE_PACKAGES if p["id"] == pkg_id), None)


def _donate_text() -> str:
    lines = []
    for pkg in DONATE_PACKAGES:
        res_parts = [
            f"{RESOURCE_EMOJIS.get(r, '?')} {RESOURCE_NAMES.get(r, r)} ×{v}"
            for r, v in pkg["resources"].items()
        ]
        frag_line = f"\n💎 Фрагменты легенды ×{pkg['fragments']}" if pkg.get("fragments") else ""
        lines.append(
            f"{'─' * 20}\n"
            f"<b>{pkg['label']}</b> — {pkg['title']}\n"
            f"📦 {', '.join(res_parts)}{frag_line}\n"
            f"📝 {pkg['description']}"
        )
    return (
        f"💎 <b>Поддержи Village Bot!</b>\n\n"
        f"Все средства идут на развитие бота.\n"
        f"Оплата через <b>Telegram Stars ⭐</b>\n\n"
        + "\n\n".join(lines)
    )


@router.message(Command("donate"))
async def cmd_donate(message: Message):
    await message.answer(_donate_text(), reply_markup=donate_kb())


@router.callback_query(F.data == "donate")
async def cb_donate(callback: CallbackQuery):
    try:
        await callback.message.edit_text(_donate_text(), reply_markup=donate_kb())
    except Exception:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(_donate_text(), reply_markup=donate_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("donate_"))
async def cb_donate_package(callback: CallbackQuery):
    pkg_id = callback.data.replace("donate_", "")
    pkg = _find_package(pkg_id)
    if not pkg:
        await callback.answer("❌ Пакет не найден", show_alert=True)
        return
    await callback.answer()
    await callback.bot.send_invoice(
        chat_id=callback.from_user.id,
        title=pkg["title"],
        description=pkg["description"],
        payload=pkg["id"],
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice(label=pkg["title"], amount=pkg["stars"])],
    )


@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def on_successful_payment(message: Message):
    payment: SuccessfulPayment = message.successful_payment
    pkg_id = payment.invoice_payload
    pkg = _find_package(pkg_id)
    if not pkg:
        await message.answer("✅ Оплата получена! Спасибо за поддержку!")
        return

    for resource, amount in pkg["resources"].items():
        await give_resources(message.from_user.id, resource, amount)

    if pkg.get("fragments"):
        await add_inventory_item(message.from_user.id, "fragment", pkg["fragments"])

    res_lines = "\n".join(
        f"  {RESOURCE_EMOJIS.get(r,'?')} {RESOURCE_NAMES.get(r,r)}: <b>+{v}</b>"
        for r, v in pkg["resources"].items()
    )
    frag_line = f"\n  💎 Фрагменты легенды: <b>+{pkg['fragments']}</b>" if pkg.get("fragments") else ""

    await message.answer(
        f"💎 <b>Спасибо! ⭐ {pkg['stars']} Stars</b>\n\n"
        f"Пакет: <b>{pkg['title']}</b>\n\n"
        f"<b>Начислено:</b>\n{res_lines}{frag_line}\n\n"
        f"🏘️ Удачи в развитии деревни!"
    )
