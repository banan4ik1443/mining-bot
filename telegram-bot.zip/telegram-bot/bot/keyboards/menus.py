import time
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import (BUILDINGS_CONFIG, BUILDING_ORDER, BAN_DURATIONS,
                    RESOURCE_EMOJIS, RESOURCE_NAMES, DONATE_PACKAGES,
                    UNITS_CONFIG, EQUIPMENT_TIERS, DUNGEONS, CRAFTABLE_ITEMS,
                    ORE_CLUSTER_CONTENTS, CLUSTER_EMOJIS)


# ── Main Menu ─────────────────────────────────────────────────────────────
def main_menu_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🏘️ Моя деревня",      callback_data="buildings_menu")
    b.button(text="👤 Профиль",           callback_data="profile")
    b.button(text="💎 Донат",             callback_data="donate")
    b.button(text="❓ Помощь",            callback_data="help")
    b.button(text="🏆 Топ",               callback_data="top")
    b.button(text="🏪 Рынок",             callback_data="market")
    b.button(text="🏚️ Подземелье",        callback_data="dungeons")
    b.button(text="⚔️ Армия",             callback_data="army")
    b.button(text="⚔️ Война",             callback_data="war")
    b.button(text="📋 Задания",           callback_data="quests")
    b.adjust(1, 3, 3, 3)
    return b.as_markup()


# ── Buildings Menu ────────────────────────────────────────────────────────
def buildings_menu_kb(buildings: dict) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for key in BUILDING_ORDER:
        cfg = BUILDINGS_CONFIG.get(key)
        if not cfg or cfg.get("hidden", False):
            continue
        lvl = buildings.get(key, 0)
        lvl_text = f"ур. {lvl}" if lvl > 0 else "не построено"
        b.button(
            text=f"{cfg['emoji']} {cfg['name']}  —  {lvl_text}",
            callback_data=f"upgrade_{key}"
        )
    b.button(text="🔙 Главное меню", callback_data="main_menu")
    b.adjust(1)
    return b.as_markup()


# ── Building detail ────────────────────────────────────────────────────────
def building_detail_kb(building_key: str, can_upgrade: bool, level: int, max_level: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    action = "Построить" if level == 0 else "Улучшить"
    if level < max_level and can_upgrade:
        b.button(text=f"⬆️ {action}", callback_data=f"do_upgrade_{building_key}")

    # Special action buttons for built buildings
    if level > 0:
        if building_key == "barracks":
            b.button(text="⚔️ Тренировать войск", callback_data="army")
        elif building_key == "smithy":
            b.button(text="⚒️ Ковка", callback_data="crafting_menu")
        elif building_key == "mine":
            b.button(text="💠 Открывать кластеры", callback_data="clusters_menu")
        elif building_key == "market_building":
            b.button(text="🛒 Рынок", callback_data="market")

    b.button(text="🏘️ Деревня", callback_data="buildings_menu")
    b.button(text="🔙 Меню",    callback_data="main_menu")
    b.adjust(1, 2)
    return b.as_markup()


# ── Army ─────────────────────────────────────────────────────────────────
def army_main_kb(barracks_level: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if barracks_level > 0:
        b.button(text="⚔️ Нанять воинов",  callback_data="army_hire")
        b.button(text="🔫 Уволить воинов",  callback_data="army_fire")
    b.button(text="🛡️ Снаряжение",         callback_data="army_equipment")
    b.button(text="⚒️ Крафт предметов",    callback_data="crafting_menu")
    b.button(text="🔙 Главное меню",        callback_data="main_menu")
    if barracks_level > 0:
        b.adjust(2, 2, 1)
    else:
        b.adjust(2, 1)
    return b.as_markup()


def hire_type_kb(fire_mode: bool = False) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    prefix = "Уволить" if fire_mode else "Нанять"
    for ut, cfg in UNITS_CONFIG.items():
        cost_text = "" if fire_mode else f" ({cfg['cost_gold']}💰)"
        b.button(text=f"{cfg['emoji']} {prefix} {cfg['name']}{cost_text}", callback_data=f"hire_type_{ut}")
    b.button(text="🔙 Армия", callback_data="army")
    b.adjust(1)
    return b.as_markup()


def equipment_kb(can_upgrade: bool, current_tier: int, owned_tiers: list[int]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if can_upgrade and current_tier < 4:
        next_eq = EQUIPMENT_TIERS.get(current_tier + 1, {})
        b.button(text=f"⬆️ Улучшить до {next_eq.get('emoji','')} {next_eq.get('name','')}", callback_data="equipment_upgrade_do")
    for tier in owned_tiers:
        if tier != current_tier and tier > 0:
            eq = EQUIPMENT_TIERS[tier]
            b.button(text=f"🔄 Надеть {eq['emoji']} {eq['name']}", callback_data=f"equip_tier_{tier}")
    b.button(text="🔙 Армия", callback_data="army")
    b.adjust(1)
    return b.as_markup()


# ── Crafting ──────────────────────────────────────────────────────────────
def crafting_menu_kb(smithy_level: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for key, cfg in CRAFTABLE_ITEMS.items():
        if smithy_level >= cfg["min_smithy"]:
            b.button(text=f"{cfg['emoji']} {cfg['name']}", callback_data=f"craft_{key}")
    b.button(text="🎒 Моё снаряжение", callback_data="crafted_inventory")
    b.button(text="🔙 Армия",          callback_data="army")
    b.adjust(2, 1, 1)
    return b.as_markup()


def craft_item_kb(item_key: str, can_craft: bool) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if can_craft:
        b.button(text="⚒️ Скрафтить!", callback_data=f"do_craft_{item_key}")
    b.button(text="🔙 Крафт", callback_data="crafting_menu")
    b.adjust(1)
    return b.as_markup()


def crafted_inventory_kb(items: list[dict], equipped_item: str | None) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for item in items:
        key = item["item_key"]
        cfg = CRAFTABLE_ITEMS.get(key, {})
        is_eq = key == equipped_item
        mark = "✅ " if is_eq else ""
        b.button(text=f"{mark}{cfg.get('emoji','')} {cfg.get('name', key)}", callback_data=f"equip_crafted_{key}")
    b.button(text="🔙 Крафт", callback_data="crafting_menu")
    b.adjust(1)
    return b.as_markup()


# ── Ore Clusters ─────────────────────────────────────────────────────────
def clusters_kb(clusters: list[dict]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for c in clusters:
        emoji = CLUSTER_EMOJIS.get(c["cluster_type"], "📦")
        cfg = ORE_CLUSTER_CONTENTS.get(c["cluster_type"], {})
        name = cfg.get("name", c["cluster_type"])
        b.button(text=f"{emoji} Открыть: {name} (x{c['quantity']})", callback_data=f"open_cluster_{c['cluster_type']}")
    b.button(text="🔙 Профиль", callback_data="profile")
    b.adjust(1)
    return b.as_markup()


# ── Dungeons ──────────────────────────────────────────────────────────────
def dungeon_list_kb(army_power: int, cooldowns: dict) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    now = int(time.time())
    for d in DUNGEONS:
        last = cooldowns.get(d["id"], 0)
        remaining = d["cooldown"] - (now - last)
        accessible = army_power >= d["min_power"] and remaining <= 0
        status = "⚔️" if accessible else ("⏳" if remaining > 0 else "🔒")
        b.button(text=f"{status} {d['emoji']} {d['name']}", callback_data=f"dungeon_info_{d['id']}")
    b.button(text="🔙 Главное меню", callback_data="main_menu")
    b.adjust(1)
    return b.as_markup()


def dungeon_detail_kb(dungeon_id: str, can_raid: bool) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if can_raid:
        b.button(text="⚔️ Атаковать", callback_data=f"dungeon_raid_{dungeon_id}")
    b.button(text="🔙 Назад", callback_data="dungeons")
    b.adjust(1)
    return b.as_markup()


def back_to_dungeons_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🏚️ Подземелья", callback_data="dungeons")
    b.button(text="🔙 Главное меню", callback_data="main_menu")
    b.adjust(2)
    return b.as_markup()


# ── Quests ────────────────────────────────────────────────────────────────
def quests_kb(quests: list[dict]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for q in quests:
        idx = q.get("quest_index", 0)
        completed = q.get("completed", 0)
        claimed = q.get("reward_claimed", 0)
        if completed and not claimed:
            b.button(text=f"🎁 Забрать: {q['quest_name']}", callback_data=f"quest_claim_{idx}")
    b.button(text="🔙 Главное меню", callback_data="main_menu")
    b.adjust(1)
    return b.as_markup()


# ── Trader ────────────────────────────────────────────────────────────────
def trader_kb(trades: list[dict], bought_ids: set) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for t in trades:
        bought = t["id"] in bought_ids
        if not bought:
            give_emoji = RESOURCE_EMOJIS.get(t["give_res"], "?")
            get_emoji  = RESOURCE_EMOJIS.get(t["get_res"], "?")
            b.button(
                text=f"🛒 {give_emoji}{t['give_amt']} → {get_emoji}{t['get_amt']}",
                callback_data=f"trader_buy_{t['id']}"
            )
    b.button(text="🔙 Рынок", callback_data="market")
    b.adjust(1)
    return b.as_markup()


# ── War ───────────────────────────────────────────────────────────────────
def war_menu_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🎯 Найти соперника", callback_data="war_find_targets")
    b.button(text="🔙 Назад",           callback_data="main_menu")
    b.adjust(1)
    return b.as_markup()


def war_targets_kb(targets: list[dict]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    now = int(time.time())
    for t in targets:
        name = t.get("first_name", "Игрок")[:16]
        shield = t.get("shield_until", 0)
        shield_mark = " 🛡️" if shield > now else ""
        lvls = t.get("total_levels", 0)
        b.button(text=f"⚔️ {name} (ур.{lvls}){shield_mark}", callback_data=f"war_confirm_{t['user_id']}")
    b.button(text="🔙 Битва деревень", callback_data="war")
    b.adjust(1)
    return b.as_markup()


def war_confirm_kb(defender_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⚔️ АТАКОВАТЬ!", callback_data=f"war_attack_{defender_id}")
    b.button(text="❌ Отмена",      callback_data="war")
    b.adjust(1)
    return b.as_markup()


# ── Market ────────────────────────────────────────────────────────────────
def market_main_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🛒 Купить",       callback_data="market_buy")
    b.button(text="💼 Продать",      callback_data="market_sell_start")
    b.button(text="📋 Мои лоты",     callback_data="market_my_listings")
    b.button(text="🧙 Торговец",     callback_data="trader")
    b.button(text="🔙 Главное меню", callback_data="main_menu")
    b.adjust(2, 2, 1)
    return b.as_markup()


def market_listings_kb(listings: list[dict], buyer_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for listing in listings[:10]:
        res = listing["resource"]
        total = listing["amount"] * listing["price_per_unit"]
        b.button(text=f"{RESOURCE_EMOJIS.get(res,'')} {listing['amount']:.0f} = 💰{total:.1f}", callback_data=f"buy_listing_{listing['id']}")
    b.button(text="🔙 Рынок", callback_data="market")
    b.adjust(1)
    return b.as_markup()


def market_sell_resource_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for key in ["wood", "ore", "stone", "food"]:
        b.button(text=f"{RESOURCE_EMOJIS[key]} {RESOURCE_NAMES[key]}", callback_data=f"sell_resource_{key}")
    b.button(text="❌ Отмена", callback_data="market")
    b.adjust(2, 2, 1)
    return b.as_markup()


def my_listings_kb(listings: list[dict]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for listing in listings:
        res = listing["resource"]
        b.button(text=f"❌ #{listing['id']}: {RESOURCE_EMOJIS.get(res,'')} {listing['amount']:.0f}", callback_data=f"cancel_listing_{listing['id']}")
    b.button(text="🔙 Рынок", callback_data="market")
    b.adjust(1)
    return b.as_markup()


def confirm_purchase_kb(listing_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Подтвердить", callback_data=f"confirm_buy_{listing_id}")
    b.button(text="❌ Отмена",      callback_data="market_buy")
    b.adjust(1)
    return b.as_markup()


# ── Top ───────────────────────────────────────────────────────────────────
def top_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⚡ Сила",           callback_data="top_power")
    b.button(text="💰 Баланс",         callback_data="top_balance")
    b.button(text="🏛️ Уровень ратуши", callback_data="top_th")
    b.button(text="🔙 Главное меню",   callback_data="main_menu")
    b.adjust(3, 1)
    return b.as_markup()


def top_back_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🔙 Назад", callback_data="top")
    b.adjust(1)
    return b.as_markup()


# ── Profile ───────────────────────────────────────────────────────────────
def profile_kb(has_clusters: bool = False) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⚙️ Настройки",    callback_data="profile_settings")
    b.button(text="🏛️ Ратуша",       callback_data="upgrade_town_hall")
    b.button(text="🏘️ Моя деревня",  callback_data="buildings_menu")
    b.button(text="📋 Квесты",        callback_data="quests")
    if has_clusters:
        b.button(text="💠 Кластеры руды!", callback_data="clusters_menu")
    b.button(text="🔙 Главное меню",  callback_data="main_menu")
    b.adjust(2, 2, 1, 1)
    return b.as_markup()


def profile_settings_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✏️ Изменить ник",  callback_data="change_village_name")
    b.button(text="🖼️ Фото профиля",  callback_data="change_profile_photo")
    b.button(text="🔗 Ссылка",        callback_data="toggle_profile_link")
    b.button(text="📋 Логи деревни",  callback_data="village_logs")
    b.button(text="🏦 Склад",         callback_data="storage_info")
    b.button(text="🔙 Профиль",       callback_data="profile")
    b.adjust(2, 2, 1, 1)
    return b.as_markup()


# ── Referral ──────────────────────────────────────────────────────────────
def referral_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="📤 Поделиться ссылкой", callback_data="referral_share")
    b.button(text="👥 Мои рефералы",       callback_data="referral_list")
    b.button(text="🔙 Профиль",            callback_data="profile")
    b.adjust(2, 1)
    return b.as_markup()


def referral_back_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🔙 Реферальная программа", callback_data="referral")
    b.adjust(1)
    return b.as_markup()


# ── Donate ────────────────────────────────────────────────────────────────
def donate_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for pkg in DONATE_PACKAGES:
        b.button(text=f"{pkg['label']}  —  {pkg['title']}", callback_data=f"donate_{pkg['id']}")
    b.button(text="🔙 Главное меню", callback_data="main_menu")
    b.adjust(1)
    return b.as_markup()


# ── Help ──────────────────────────────────────────────────────────────────
def help_sections_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="❓ О игре",         callback_data="help_about")
    b.button(text="🏗️ Здания",         callback_data="help_buildings")
    b.button(text="⚔️ Боевая система", callback_data="help_combat")
    b.button(text="⛏️ Шахта и руды",   callback_data="help_mine")
    b.button(text="💡 Советы",         callback_data="help_tips")
    b.button(text="🔙 Главное меню",   callback_data="main_menu")
    b.adjust(2, 2, 1, 1)
    return b.as_markup()


def help_back_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🔙 Назад к помощи", callback_data="help")
    b.adjust(1)
    return b.as_markup()


# ── Admin ─────────────────────────────────────────────────────────────────
def admin_main_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="👥 Игроки",         callback_data="admin_players")
    b.button(text="📊 Статистика",     callback_data="admin_stats")
    b.button(text="💎 Выдать ресурсы", callback_data="admin_give_start")
    b.button(text="🔨 Забанить",       callback_data="admin_ban_start")
    b.button(text="✅ Разбанить",      callback_data="admin_unban_start")
    b.button(text="📢 Рассылка",       callback_data="admin_broadcast_start")
    b.button(text="🔄 Сбросить всех",  callback_data="admin_reset_confirm")
    b.button(text="🔙 Главное меню",   callback_data="main_menu")
    b.adjust(2, 2, 2, 1, 1)
    return b.as_markup()


def admin_give_resource_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for key, name in RESOURCE_NAMES.items():
        b.button(text=f"{RESOURCE_EMOJIS[key]} {name}", callback_data=f"admin_give_res_{key}")
    b.button(text="❌ Отмена", callback_data="admin_menu")
    b.adjust(2, 2, 1, 1)
    return b.as_markup()


def admin_reset_confirm_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⚠️ ДА, сбросить!", callback_data="admin_reset_do")
    b.button(text="❌ Отмена",         callback_data="admin_menu")
    b.adjust(1)
    return b.as_markup()


def ban_duration_kb(user_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for key, (label, _) in BAN_DURATIONS.items():
        b.button(text=label, callback_data=f"ban_dur_{user_id}_{key}")
    b.button(text="❌ Отмена", callback_data="admin_menu")
    b.adjust(3, 2, 1)
    return b.as_markup()


def back_to_admin_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🔙 Админ-панель", callback_data="admin_menu")
    return b.as_markup()
